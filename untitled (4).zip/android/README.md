# LOOI AI – Personal AI Assistant & Robot Companion (Native Android)

A complete native Kotlin + XML Android Studio project (`com.looi.ai`, Android 10–14+) featuring:
- **Interactive LOOI Robot Face (`RobotFaceCanvasView`)**: Two separate glowing eyes positioned wide apart, natural random blinking, synchronized pupil tracking, smooth emotion transitions, sleeping/waking states, and real-time `Visualizer` / syllable-cadence `LipSyncController`.
- **CameraX + Simultaneous ML Kit Vision (`CompositeVisionAnalyzer`)**: Real-time front camera tracking + face/expression detection + object detection with sequence-ordered updates and safe ordered detector teardown.
- **Natural Hindi / Hinglish / English Two-Way Voice (`VoiceSessionManager`)**: Female-prioritized TTS, continuous conversation loop, and instant barge-in speech interruption.
- **Background AI Assistant Service (`LooiAssistantService`)**: Persistent notification with Pause/Resume/Stop Task controls, configurable wake-word (`"Hey LOOI"`), and clean microphone handoff with foreground UI.
- **Complete Mobile Control (`LooiAccessibilityService`)**: Voice-driven clicks, text entry, scrolling, swiping, Back/Home/Recents, and app launching with automatic protection blocking password fields, OTPs, UPI/banking apps, and system permission dialogs.
- **YouTube Voice Control (`YouTubeAutomationEngine`)**: Open YouTube, search and play videos/channels, pause, resume, next, previous, scroll, open channel, read titles/descriptions, and subscribe only after explicit user confirmation.
- **Live Screen Reading & Understanding (`ScreenIntelligenceEngine` + `ScreenCaptureManager`)**: Reads visible UI structure via Accessibility and optional one-tap consented `MediaProjection` + on-device ML Kit OCR.
- **AI Code Editor Control (`HtmlEditorAutomationEngine`)**: Generates complete HTML5+CSS+JS apps/games, inserts into installed editors (Acode, TrebEdit, Spck, QuickEdit, AnWriter) or launches local `.html` files via `FileProvider`, saves, runs, and fixes visible errors.
- **Action Planner & Persistent Room Memory v2 (`ActionPlanner`, `TaskExecutionEngine`, `AppDatabase`)**: Multi-step plan execution, `"LOOI, ruk jao"` immediate cancellation, conversation memory, user preferences, app usage stats, and `ActionHistoryActivity`.

## 1. Android Studio Setup
1. Extract the ZIP and open the `looi-ai-android/` folder in **Android Studio** (Jellyfish / Koala / Ladybug or newer).
2. Let Gradle sync using `gradle/libs.versions.toml` (AGP `8.5.2`, Gradle `8.7`, Kotlin `1.9.24`, JDK `17`, `compileSdk 34`).
3. Connect a physical Android device (Android 10+ / API 29+) with USB Debugging enabled (recommended for front camera, microphone, Accessibility Service, and YouTube/HTML editor automation).

## 2. Security & API Configuration (No Hardcoded Keys)
1. Open **Settings** inside LOOI AI and verify the **Android Keystore Encrypted Storage** status banner at the top.
2. Enter your **Groq API Key** (`console.groq.com`) and/or **Gemini API Key** (`aistudio.google.com`).
   - Keys are stored strictly inside `EncryptedSharedPreferences` backed by Android Keystore (`AES256_GCM`). There is **zero plain-text fallback**; if Keystore is unavailable on a device, an explicit error is shown and you can route requests through an **HTTPS Companion Backend Proxy** instead.
3. For a Companion Backend Proxy:
   - **Physical Android devices**: Configure an `https://` URL (cleartext `http://` to remote hosts is blocked by `res/xml/network_security_config.xml`).
   - **Android Emulator**: `http://10.0.2.2:3000` is explicitly permitted for local testing.

## 3. Permissions Setup on Device
1. Grant **Camera**, **Microphone**, and **Notifications** permissions when prompted.
2. Open **Settings -> Open Accessibility Settings** and enable **LOOI AI Mobile Control** for screen reading, YouTube playback/selection, and HTML editor automation.
3. Tap **Allow Unrestricted Background Battery** if you enable **Background Wake-Word Service** (`"Hey LOOI"`).
4. Optionally tap **Grant One-Tap Screen Capture Consent** for OCR fallback on non-accessible screens.

## 4. Build & Install APK
From `looi-ai-android/` (with Android SDK & JDK 17 installed):
```bash
# Ensure wrapper is executable (macOS / Linux)
chmod +x gradlew

# Build Debug APK (macOS / Linux)
./gradlew assembleDebug

# Build Debug APK (Windows)
gradlew.bat assembleDebug

# Install to connected device
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
For a release APK, use **Build > Generate Signed Bundle / APK** in Android Studio.
