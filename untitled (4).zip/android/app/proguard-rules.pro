# Proguard rules for LOOI AI
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
-keep class com.looi.ai.memory.database.** { *; }
-keep class com.looi.ai.ai.** { *; }
-keep class com.looi.ai.planner.** { *; }
-keep class com.looi.ai.automation.** { *; }
