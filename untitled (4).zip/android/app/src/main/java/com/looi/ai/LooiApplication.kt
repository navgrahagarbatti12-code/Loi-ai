package com.looi.ai

import android.app.Application
import com.looi.ai.ai.gemini.GeminiLiveClient
import com.looi.ai.ai.groq.GroqManager
import com.looi.ai.automation.HtmlEditorAutomationEngine
import com.looi.ai.automation.YouTubeAutomationEngine
import com.looi.ai.memory.MemoryRepository
import com.looi.ai.memory.database.AppDatabase
import com.looi.ai.planner.ActionPlanner
import com.looi.ai.planner.TaskExecutionEngine
import com.looi.ai.settings.SettingsManager
import com.looi.ai.vision.ScreenIntelligenceEngine

class LooiApplication : Application() {

    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val memoryRepository: MemoryRepository by lazy { MemoryRepository(database.conversationDao()) }
    val settingsManager: SettingsManager by lazy { SettingsManager(this) }

    val groqManager: GroqManager by lazy { GroqManager(settingsManager) }
    val geminiClient: GeminiLiveClient by lazy { GeminiLiveClient(settingsManager) }
    val youTubeEngine: YouTubeAutomationEngine by lazy { YouTubeAutomationEngine(this) }
    val htmlEditorEngine: HtmlEditorAutomationEngine by lazy {
        HtmlEditorAutomationEngine(this, settingsManager, groqManager, geminiClient)
    }
    val screenIntelligenceEngine: ScreenIntelligenceEngine by lazy {
        ScreenIntelligenceEngine(this, settingsManager, groqManager, geminiClient)
    }
    val actionPlanner: ActionPlanner by lazy {
        ActionPlanner(this, settingsManager, groqManager, geminiClient)
    }
    val taskExecutionEngine: TaskExecutionEngine by lazy {
        TaskExecutionEngine(
            context = this,
            settings = settingsManager,
            memoryRepository = memoryRepository,
            groqManager = groqManager,
            geminiClient = geminiClient,
            actionPlanner = actionPlanner,
            youTubeEngine = youTubeEngine,
            htmlEditorEngine = htmlEditorEngine,
            screenIntelligenceEngine = screenIntelligenceEngine
        )
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: LooiApplication
            private set
    }
}
