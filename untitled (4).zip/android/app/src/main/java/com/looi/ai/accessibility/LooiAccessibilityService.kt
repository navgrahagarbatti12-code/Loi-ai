package com.looi.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ScreenElement(
    val text: String,
    val contentDescription: String,
    val viewId: String,
    val className: String,
    val clickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val isPassword: Boolean,
    val isSelected: Boolean,
    val bounds: Rect
)

data class ScreenSnapshot(
    val packageName: String,
    val appLabel: String,
    val visibleTexts: List<String>,
    val clickableLabels: List<String>,
    val editableHints: List<String>,
    val selectedTabs: List<String>,
    val hasLoadingIndicator: Boolean,
    val detectedErrorText: String?,
    val isSensitiveScreen: Boolean,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toPromptSummary(): String = buildString {
        appendLine("Active App: $appLabel ($packageName)")
        if (isSensitiveScreen) {
            appendLine("SECURITY NOTICE: Sensitive screen (password/OTP/payment/permission dialog) detected. Automation restricted.")
        }
        if (selectedTabs.isNotEmpty()) {
            appendLine("Selected Tabs: ${selectedTabs.joinToString(", ")}")
        }
        if (clickableLabels.isNotEmpty()) {
            appendLine("Clickable Buttons/Items: ${clickableLabels.take(18).joinToString(" | ")}")
        }
        if (editableHints.isNotEmpty()) {
            appendLine("Text Fields: ${editableHints.take(6).joinToString(" | ")}")
        }
        if (hasLoadingIndicator) {
            appendLine("Status: Screen appears to be loading.")
        }
        if (!detectedErrorText.isNullOrBlank()) {
            appendLine("Visible Error/Alert: $detectedErrorText")
        }
        if (visibleTexts.isNotEmpty()) {
            appendLine("Visible Screen Text:\n${visibleTexts.take(35).joinToString("\n")}")
        }
    }.trim()
}

/**
 * Android AccessibilityService-based screen reading and safe UI automation engine.
 * Strictly blocks password fields, OTPs, banking/payment confirmations, and system permission dialogs.
 */
class LooiAccessibilityService : AccessibilityService() {

    private val tag = "LooiAccessibilitySvc"

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
        updateCurrentAppLabel(rootInActiveWindow?.packageName?.toString().orEmpty())
        Log.i(tag, "LOOI AccessibilityService connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: rootInActiveWindow?.packageName?.toString()
        if (!pkg.isNullOrBlank() && pkg != packageName) {
            updateCurrentAppLabel(pkg)
        }
    }

    override fun onInterrupt() {
        Log.w(tag, "LOOI AccessibilityService interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
        _isServiceConnected.value = false
    }

    private fun updateCurrentAppLabel(pkg: String) {
        if (pkg.isBlank()) return
        val label = resolveAppLabel(pkg)
        _activeAppPackage.value = pkg
        _activeAppLabel.value = label
    }

    fun resolveAppLabel(pkg: String): String {
        if (pkg.isBlank()) return "Unknown"
        return try {
            val appInfo = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (_: Exception) {
            pkg
        }
    }

    fun captureScreenSnapshot(): ScreenSnapshot? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString().orEmpty()
        val appLabel = resolveAppLabel(pkg)

        val visibleTexts = mutableListOf<String>()
        val clickableLabels = mutableListOf<String>()
        val editableHints = mutableListOf<String>()
        val selectedTabs = mutableListOf<String>()
        var hasLoading = false
        var errorText: String? = null
        var sensitive = isSensitivePackageOrContext(pkg)

        traverseTree(root) { node ->
            if (node.isPassword) {
                sensitive = true
                return@traverseTree
            }

            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val hint = node.hintText?.toString()?.trim().orEmpty()
            val cls = node.className?.toString().orEmpty()
            val combined = text.ifBlank { desc }

            if (cls.contains("ProgressBar", ignoreCase = true)) {
                hasLoading = true
            }

            if (combined.isNotBlank()) {
                if (looksLikeSensitivePrompt(combined)) {
                    sensitive = true
                } else {
                    if (!visibleTexts.contains(combined)) {
                        visibleTexts.add(combined)
                    }
                    if (node.isSelected) {
                        selectedTabs.add(combined)
                    }
                    if (node.isClickable && !clickableLabels.contains(combined)) {
                        clickableLabels.add(combined)
                    }
                    if (looksLikeErrorMessage(combined) && errorText == null) {
                        errorText = combined
                    }
                }
            }

            if (node.isEditable && !node.isPassword) {
                val fieldDesc = hint.ifBlank { text.ifBlank { node.viewIdResourceName ?: "Text input" } }
                if (!editableHints.contains(fieldDesc)) {
                    editableHints.add(fieldDesc)
                }
            }
        }

        return ScreenSnapshot(
            packageName = pkg,
            appLabel = appLabel,
            visibleTexts = visibleTexts,
            clickableLabels = clickableLabels,
            editableHints = editableHints,
            selectedTabs = selectedTabs,
            hasLoadingIndicator = hasLoading,
            detectedErrorText = errorText,
            isSensitiveScreen = sensitive
        )
    }

    fun clickByTextOrDescription(query: String, exactMatch: Boolean = false): Boolean {
        val root = rootInActiveWindow ?: return false
        if (isScreenRestricted(root)) return false

        val normalized = query.trim().lowercase()
        if (normalized.isBlank()) return false

        var targetNode: AccessibilityNodeInfo? = null
        traverseTree(root) { node ->
            if (targetNode != null || node.isPassword) return@traverseTree
            val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
            val desc = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
            val idName = node.viewIdResourceName?.substringAfterLast('/')?.lowercase().orEmpty()

            val matches = if (exactMatch) {
                text == normalized || desc == normalized || idName == normalized
            } else {
                text.contains(normalized) || desc.contains(normalized) || idName.contains(normalized)
            }

            if (matches && !looksLikeSensitivePrompt(text) && !looksLikeSensitivePrompt(desc)) {
                targetNode = findClickableAncestor(node) ?: node
            }
        }

        val found = targetNode ?: return false
        if (found.isClickable && found.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return true
        }
        // Gesture tap fallback on node bounds
        val rect = Rect()
        found.getBoundsInScreen(rect)
        if (!rect.isEmpty) {
            return tapAt(rect.centerX().toFloat(), rect.centerY().toFloat())
        }
        return false
    }

    fun clickByViewIdSuffix(vararg suffixes: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (isScreenRestricted(root)) return false

        var clicked = false
        traverseTree(root) { node ->
            if (clicked || node.isPassword) return@traverseTree
            val id = node.viewIdResourceName?.lowercase().orEmpty()
            if (suffixes.any { id.endsWith(it.lowercase()) || id.contains(it.lowercase()) }) {
                val target = findClickableAncestor(node) ?: node
                if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    clicked = true
                }
            }
        }
        return clicked
    }

    fun inputTextIntoField(textToEnter: String, fieldHintOrId: String? = null, replaceExisting: Boolean = true): Boolean {
        val root = rootInActiveWindow ?: return false
        if (isScreenRestricted(root)) return false

        val hintFilter = fieldHintOrId?.trim()?.lowercase().orEmpty()
        var bestEditable: AccessibilityNodeInfo? = null
        var firstEditable: AccessibilityNodeInfo? = null

        traverseTree(root) { node ->
            if (node.isEditable && !node.isPassword) {
                if (firstEditable == null) firstEditable = node
                if (hintFilter.isNotBlank()) {
                    val hint = node.hintText?.toString()?.lowercase().orEmpty()
                    val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
                    val text = node.text?.toString()?.lowercase().orEmpty()
                    val id = node.viewIdResourceName?.lowercase().orEmpty()
                    if (hint.contains(hintFilter) || desc.contains(hintFilter) ||
                        text.contains(hintFilter) || id.contains(hintFilter)
                    ) {
                        bestEditable = node
                    }
                }
            }
        }

        val target = bestEditable ?: firstEditable ?: return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        target.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        if (replaceExisting && !target.text.isNullOrEmpty()) {
            val selectArgs = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, target.text.length)
            }
            target.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selectArgs)
        }

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToEnter)
        }
        if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            return true
        }

        // Clipboard paste fallback for custom editors that reject ACTION_SET_TEXT
        return try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("LOOI Code", textToEnter))
            target.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        } catch (e: Exception) {
            Log.w(tag, "Clipboard paste fallback failed: ${e.message}")
            false
        }
    }

    fun getAllEditableText(): String? {
        val root = rootInActiveWindow ?: return null
        if (isScreenRestricted(root)) return null

        val sb = StringBuilder()
        traverseTree(root) { node ->
            if (node.isEditable && !node.isPassword) {
                val txt = node.text?.toString()
                if (!txt.isNullOrBlank()) {
                    if (sb.isNotEmpty()) sb.append("\n")
                    sb.append(txt)
                }
            }
        }
        return sb.toString().ifBlank { null }
    }

    fun scrollScreen(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        var scrollableNode: AccessibilityNodeInfo? = null
        traverseTree(root) { node ->
            if (scrollableNode == null && node.isScrollable) {
                scrollableNode = node
            }
        }
        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        if (scrollableNode?.performAction(action) == true) {
            return true
        }
        // Gesture scroll fallback
        val dm = resources.displayMetrics
        val cx = dm.widthPixels * 0.5f
        val startY = if (forward) dm.heightPixels * 0.72f else dm.heightPixels * 0.28f
        val endY = if (forward) dm.heightPixels * 0.28f else dm.heightPixels * 0.72f
        return swipe(cx, startY, cx, endY, 320L)
    }

    fun swipeHorizontal(swipeLeft: Boolean): Boolean {
        val dm = resources.displayMetrics
        val cy = dm.heightPixels * 0.5f
        val startX = if (swipeLeft) dm.widthPixels * 0.82f else dm.widthPixels * 0.18f
        val endX = if (swipeLeft) dm.widthPixels * 0.18f else dm.widthPixels * 0.82f
        return swipe(startX, cy, endX, cy, 280L)
    }

    fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun swipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300L): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun navigateBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun navigateHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    private fun findClickableAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var curr: AccessibilityNodeInfo? = node
        var depth = 0
        while (curr != null && depth < 6) {
            if (curr.isClickable) return curr
            curr = curr.parent
            depth++
        }
        return null
    }

    private fun traverseTree(node: AccessibilityNodeInfo?, visitor: (AccessibilityNodeInfo) -> Unit) {
        if (node == null) return
        visitor(node)
        for (i in 0 until node.childCount) {
            traverseTree(node.getChild(i), visitor)
        }
    }

    private fun isScreenRestricted(root: AccessibilityNodeInfo): Boolean {
        val pkg = root.packageName?.toString().orEmpty()
        if (isSensitivePackageOrContext(pkg)) return true
        var restricted = false
        traverseTree(root) { node ->
            if (restricted) return@traverseTree
            if (node.isPassword) {
                restricted = true
                return@traverseTree
            }
            val text = node.text?.toString().orEmpty()
            if (looksLikeSensitivePrompt(text)) {
                restricted = true
            }
        }
        return restricted
    }

    private fun isSensitivePackageOrContext(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower.contains("permissioncontroller") ||
            lower.contains("packageinstaller") ||
            lower.contains("biometric") ||
            lower.contains("keyguard") ||
            lower.contains("upi") ||
            lower.contains("gpay") ||
            lower.contains("phonepe") ||
            lower.contains("paytm") ||
            lower.contains("bank")
    }

    private fun looksLikeSensitivePrompt(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("enter otp") ||
            lower.contains("one time password") ||
            lower.contains("enter pin") ||
            lower.contains("upi pin") ||
            lower.contains("confirm payment") ||
            lower.contains("fingerprint") ||
            lower.contains("biometric") ||
            lower.contains("allow ") && lower.contains(" to access")
    }

    private fun looksLikeErrorMessage(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("syntax error") ||
            lower.contains("uncaught") ||
            lower.contains("exception") ||
            lower.contains("failed to") ||
            lower.contains("something went wrong") ||
            lower.contains("no internet") ||
            lower.contains("network error") ||
            lower.contains("error:")
    }

    companion object {
        @Volatile
        var instance: LooiAccessibilityService? = null
            private set

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        private val _activeAppPackage = MutableStateFlow("")
        val activeAppPackage: StateFlow<String> = _activeAppPackage.asStateFlow()

        private val _activeAppLabel = MutableStateFlow("Home")
        val activeAppLabel: StateFlow<String> = _activeAppLabel.asStateFlow()

        fun isAccessibilityEnabled(context: Context): Boolean {
            if (instance != null) return true
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ).orEmpty()
            val expectedName = "${context.packageName}/${LooiAccessibilityService::class.java.name}"
            val shortName = "${context.packageName}/.accessibility.LooiAccessibilityService"
            return enabledServices.contains(expectedName) || enabledServices.contains(shortName)
        }

        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
