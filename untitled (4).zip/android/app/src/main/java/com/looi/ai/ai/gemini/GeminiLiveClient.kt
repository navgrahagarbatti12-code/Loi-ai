package com.looi.ai.ai.gemini

import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * Gemini Companion & Direct API Client.
 * Supports:
 * 1) Direct Gemini API calls (including multimodal screenshot vision analysis) using a user-configured Keystore-encrypted API key.
 * 2) User-configured HTTPS companion backend proxy (/api/looi/chat).
 * Reports clear actionable errors whenever keys are missing or servers are unreachable.
 */
class GeminiLiveClient(
    private val settingsManager: SettingsManager
) {
    private val tag = "GeminiLiveClient"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun sendConversationTurn(
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String,
        screenshotJpeg: ByteArray? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val geminiKey = settingsManager.geminiApiKey
        val forceBackend = settingsManager.aiProvider == SettingsManager.PROVIDER_BACKEND

        if (!forceBackend && geminiKey.isNotBlank()) {
            return@withContext callGeminiDirect(
                apiKey = geminiKey,
                userMessage = userMessage,
                detectedEmotion = detectedEmotion,
                detectedObjects = detectedObjects,
                historyContext = historyContext,
                screenshotJpeg = screenshotJpeg
            )
        }

        val baseUrl = settingsManager.backendUrl
        if (baseUrl.isBlank()) {
            val keystoreErr = settingsManager.secureStorageErrorMessage
            val msg = keystoreErr
                ?: "Neither a Gemini/Groq API key nor a Backend URL is configured. Open Settings to configure an AI provider."
            return@withContext Result.failure(IllegalStateException(msg))
        }

        try {
            val payload = JsonObject().apply {
                addProperty("message", userMessage)
                addProperty("language", settingsManager.languageCode)
                addProperty("detectedEmotion", detectedEmotion)
                addProperty("historyContext", historyContext)
                add("detectedObjects", gson.toJsonTree(detectedObjects))
            }

            val requestBody = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$baseUrl/api/looi/chat")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = "Backend at $baseUrl returned HTTP ${response.code}. Check your server or add a Groq/Gemini API key in Settings."
                    return@withContext Result.failure(IOException(detail))
                }

                val json = gson.fromJson(responseStr, JsonObject::class.java)
                val replyText = json?.get("reply")?.asString
                if (replyText.isNullOrBlank()) {
                    return@withContext Result.failure(
                        IOException("Invalid or empty JSON reply from backend at $baseUrl.")
                    )
                }
                Result.success(replyText)
            }
        } catch (e: ConnectException) {
            Log.e(tag, "Backend unreachable at $baseUrl", e)
            Result.failure(
                IOException("Cannot connect to backend at $baseUrl. If using a physical phone, enter an https:// URL or add a Groq/Gemini API key in Settings.", e)
            )
        } catch (e: UnknownHostException) {
            Log.e(tag, "Invalid backend host at $baseUrl", e)
            Result.failure(
                IOException("Cannot resolve backend host ($baseUrl). Check Settings.", e)
            )
        } catch (e: SocketTimeoutException) {
            Log.e(tag, "Backend timed out at $baseUrl", e)
            Result.failure(
                IOException("Backend at $baseUrl timed out. Check your connection or switch to Direct API in Settings.", e)
            )
        } catch (e: Exception) {
            Log.e(tag, "Companion backend communication error", e)
            Result.failure(
                IOException("Backend error (${e.localizedMessage ?: "Unknown"}). Check Settings.", e)
            )
        }
    }

    suspend fun generateDirectText(
        systemPrompt: String,
        userPrompt: String,
        screenshotJpeg: ByteArray? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = settingsManager.geminiApiKey
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not configured in Settings.")
            )
        }
        callGeminiDirectRaw(apiKey, systemPrompt, userPrompt, screenshotJpeg)
    }

    private fun callGeminiDirect(
        apiKey: String,
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String,
        screenshotJpeg: ByteArray?
    ): Result<String> {
        val languageInstruction = when (settingsManager.languageCode) {
            "hi-IN" -> "Reply in warm, expressive female Hindi or Hinglish (Roman Hindi + English) in 1 to 3 short spoken sentences."
            "en-IN" -> "Reply in warm, friendly female Indian English in 1 to 3 short spoken sentences."
            else -> "Reply in warm, friendly female English in 1 to 3 short spoken sentences."
        }
        val visionLine = if (detectedObjects.isNotEmpty()) {
            "Objects seen near user: ${detectedObjects.joinToString(", ")}."
        } else ""

        val systemPrompt = """
            You are LOOI AI, an intelligent, caring female desktop robot & Android personal assistant.
            $languageInstruction
            Detected user emotion: $detectedEmotion. $visionLine
            Memory context:
            $historyContext
        """.trimIndent()

        return callGeminiDirectRaw(apiKey, systemPrompt, userMessage, screenshotJpeg)
    }

    private fun callGeminiDirectRaw(
        apiKey: String,
        systemPrompt: String,
        userPrompt: String,
        screenshotJpeg: ByteArray?
    ): Result<String> {
        val model = settingsManager.geminiModel
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val parts = JsonArray().apply {
            add(JsonObject().apply { addProperty("text", userPrompt) })
            if (screenshotJpeg != null && screenshotJpeg.isNotEmpty()) {
                add(JsonObject().apply {
                    add("inlineData", JsonObject().apply {
                        addProperty("mimeType", "image/jpeg")
                        addProperty("data", Base64.encodeToString(screenshotJpeg, Base64.NO_WRAP))
                    })
                })
            }
        }

        val payload = JsonObject().apply {
            add("systemInstruction", JsonObject().apply {
                add("parts", JsonArray().apply {
                    add(JsonObject().apply { addProperty("text", systemPrompt) })
                })
            })
            add("contents", JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("role", "user")
                    add("parts", parts)
                })
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val msg = when (response.code) {
                        400, 403 -> "Invalid Gemini API key or permission error (HTTP ${response.code}). Check Settings."
                        429 -> "Gemini API rate limit reached. Try again shortly."
                        else -> "Gemini API error (HTTP ${response.code})."
                    }
                    return Result.failure(IOException(msg))
                }
                val json = gson.fromJson(raw, JsonObject::class.java)
                val text = json?.getAsJsonArray("candidates")
                    ?.firstOrNull()?.asJsonObject
                    ?.getAsJsonObject("content")
                    ?.getAsJsonArray("parts")
                    ?.firstOrNull()?.asJsonObject
                    ?.get("text")?.asString
                    ?.trim()

                if (text.isNullOrBlank()) {
                    Result.failure(IOException("Empty text returned from Gemini API"))
                } else {
                    Result.success(text)
                }
            }
        } catch (e: UnknownHostException) {
            Result.failure(IOException("No internet connection. Cannot reach Gemini API.", e))
        } catch (e: SocketTimeoutException) {
            Result.failure(IOException("Gemini API request timed out.", e))
        } catch (e: Exception) {
            Result.failure(IOException("Gemini request failed: ${e.localizedMessage ?: "Unknown"}", e))
        }
    }
}
