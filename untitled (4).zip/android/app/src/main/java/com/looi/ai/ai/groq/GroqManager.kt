package com.looi.ai.ai.groq

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * Modular Groq AI Manager.
 * Calls Groq's OpenAI-compatible Chat Completions API directly when a user-configured
 * Keystore-encrypted API key is present in SettingsManager, or routes through the configured
 * HTTPS companion backend proxy when appropriate. Never hardcodes any API key.
 */
class GroqManager(
    private val settingsManager: SettingsManager
) {
    private val tag = "GroqManager"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun chatCompletion(
        userMessage: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val languageInstruction = when (settingsManager.languageCode) {
            "hi-IN" -> "Reply naturally in warm, expressive, confident female Hindi or Hinglish (Roman Hindi + English mix) in 1 to 3 short spoken sentences."
            "en-IN" -> "Reply in warm, expressive, friendly female Indian English in 1 to 3 short spoken sentences."
            else -> "Reply in warm, expressive, friendly female English in 1 to 3 short spoken sentences."
        }

        val visionContext = buildString {
            append("User emotion: $detectedEmotion. ")
            if (detectedObjects.isNotEmpty()) {
                append("Visible objects around user: ${detectedObjects.joinToString(", ")}.")
            }
        }

        val systemPrompt = """
            You are LOOI AI, a playful, intelligent, caring female personal AI robot assistant.
            $languageInstruction
            Keep responses natural for voice output—no markdown symbols, bullet lists, or robotic phrasing.
            $visionContext
        """.trimIndent()

        generateText(
            systemPrompt = systemPrompt,
            userPrompt = userMessage,
            historyContext = historyContext,
            maxTokens = 260,
            temperature = 0.7
        )
    }

    suspend fun generateText(
        systemPrompt: String,
        userPrompt: String,
        historyContext: String = "",
        maxTokens: Int = 1400,
        temperature: Double = 0.4
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = settingsManager.groqApiKey
        if (apiKey.isBlank()) {
            val keystoreIssue = settingsManager.secureStorageErrorMessage
            val msg = if (!keystoreIssue.isNullOrBlank()) {
                keystoreIssue
            } else {
                "Groq API key not configured. Open Settings to enter your Groq API key."
            }
            return@withContext Result.failure(IllegalStateException(msg))
        }

        val messages = JsonArray().apply {
            add(JsonObject().apply {
                addProperty("role", "system")
                addProperty("content", systemPrompt)
            })
            if (historyContext.isNotBlank() && historyContext != "No prior chat history.") {
                add(JsonObject().apply {
                    addProperty("role", "system")
                    addProperty("content", "Memory context:\n$historyContext")
                })
            }
            add(JsonObject().apply {
                addProperty("role", "user")
                addProperty("content", userPrompt)
            })
        }

        val payload = JsonObject().apply {
            addProperty("model", settingsManager.groqModel)
            add("messages", messages)
            addProperty("temperature", temperature)
            addProperty("max_tokens", maxTokens)
        }

        val requestBody = payload.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(GROQ_CHAT_URL)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val parsedError = extractGroqErrorMessage(responseStr)
                    val errorMsg = when (response.code) {
                        401 -> "Invalid Groq API key. Please update it in Settings."
                        404 -> "Groq model '${settingsManager.groqModel}' unavailable. Choose another model in Settings."
                        429 -> "Groq rate limit reached. Please try again in a few seconds."
                        else -> parsedError ?: "Groq API error (HTTP ${response.code})."
                    }
                    Log.e(tag, "$errorMsg ($responseStr)")
                    return@withContext Result.failure(IOException(errorMsg))
                }

                val json = gson.fromJson(responseStr, JsonObject::class.java)
                val choices = json?.getAsJsonArray("choices")
                val reply = choices?.firstOrNull()
                    ?.asJsonObject
                    ?.getAsJsonObject("message")
                    ?.get("content")
                    ?.asString
                    ?.trim()

                if (reply.isNullOrBlank()) {
                    return@withContext Result.failure(IOException("Empty response from Groq API"))
                }
                Result.success(reply)
            }
        } catch (e: UnknownHostException) {
            Result.failure(IOException("No internet connection. Cannot reach api.groq.com.", e))
        } catch (e: SocketTimeoutException) {
            Result.failure(IOException("Groq API request timed out. Check your internet connection.", e))
        } catch (e: Exception) {
            Log.e(tag, "Groq network error", e)
            Result.failure(IOException("Network error: ${e.localizedMessage ?: "Unable to reach Groq"}", e))
        }
    }

    suspend fun describeDetectedObject(
        objectName: String,
        userQuery: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val prompt = userQuery
            ?: "I see a $objectName in front of me. React to it warmly as LOOI in 1-2 short spoken sentences."
        val apiKey = settingsManager.groqApiKey

        if (apiKey.isNotBlank()) {
            return@withContext chatCompletion(
                userMessage = prompt,
                detectedEmotion = "CURIOUS",
                detectedObjects = listOf(objectName),
                historyContext = ""
            )
        }

        val backendUrl = settingsManager.backendUrl
        if (backendUrl.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Configure a Groq API key, Gemini API key, or Backend URL in Settings.")
            )
        }

        try {
            val payload = JsonObject().apply {
                addProperty("objectName", objectName)
                addProperty("query", prompt)
                addProperty("engine", "groq-llama3")
            }

            val body = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$backendUrl/api/looi/groq")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IOException("Backend at $backendUrl returned HTTP ${response.code}.")
                    )
                }
                val json = gson.fromJson(responseStr, JsonObject::class.java)
                val text = json?.get("description")?.asString
                    ?: return@withContext Result.failure(IOException("Empty description from backend"))
                Result.success(text)
            }
        } catch (e: Exception) {
            Log.w(tag, "Groq backend request failed: ${e.message}")
            Result.failure(
                IOException("Cannot reach backend at $backendUrl. Configure a Groq API key in Settings.", e)
            )
        }
    }

    private fun extractGroqErrorMessage(raw: String): String? {
        return try {
            val obj = gson.fromJson(raw, JsonObject::class.java)
            obj?.getAsJsonObject("error")?.get("message")?.asString
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private const val GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
    }
}
