package com.looi.ai.audio

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import androidx.core.content.ContextCompat
import com.looi.ai.settings.SettingsManager
import java.util.Locale
import java.util.UUID

interface VoiceSessionListener {
    fun onListeningStarted()
    fun onMicRmsChanged(normalizedAmplitude: Float)
    fun onPartialSpeech(text: String)
    fun onSpeechResult(spokenText: String)
    fun onSpeechEnded()
    fun onListeningError(errorCode: Int, message: String)
    fun onSpeakingStarted(audioSessionId: Int)
    fun onSpeakingFinished()
}

/**
 * Reusable Speech-to-Text + natural female Text-to-Speech controller
 * supporting continuous two-way conversation and immediate barge-in interruption.
 */
class VoiceSessionManager(
    context: Context,
    private val settings: SettingsManager,
    private val listener: VoiceSessionListener
) {
    private val appContext = context.applicationContext
    private val tag = "VoiceSessionManager"
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsAudioSessionId: Int = 0

    @Volatile
    var isTtsReady: Boolean = false
        private set

    @Volatile
    var isListening: Boolean = false
        private set

    @Volatile
    var isSpeaking: Boolean = false
        private set

    @Volatile
    private var isReleased: Boolean = false

    private var onSpeakCompletedAction: (() -> Unit)? = null

    init {
        val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        ttsAudioSessionId = audioManager?.generateAudioSessionId() ?: 0
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(appContext) { status ->
            if (isReleased) return@TextToSpeech
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                textToSpeech?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                applyTtsSettings()

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeaking = true
                        mainHandler.post {
                            if (!isReleased) listener.onSpeakingStarted(ttsAudioSessionId)
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        isSpeaking = false
                        mainHandler.post {
                            if (!isReleased) {
                                listener.onSpeakingFinished()
                                val callback = onSpeakCompletedAction
                                onSpeakCompletedAction = null
                                callback?.invoke()
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isSpeaking = false
                        mainHandler.post {
                            if (!isReleased) {
                                listener.onSpeakingFinished()
                                onSpeakCompletedAction = null
                            }
                        }
                    }
                })
            } else {
                Log.e(tag, "TextToSpeech initialization failed with status $status")
            }
        }
    }

    fun applyTtsSettings() {
        val tts = textToSpeech ?: return
        val targetLocale = Locale.forLanguageTag(settings.languageCode)
        val result = tts.setLanguage(targetLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale("en", "IN"))
        }

        val customVoiceName = settings.voiceName
        val voices = tts.voices.orEmpty()
        val chosenVoice: Voice? = if (customVoiceName.isNotBlank()) {
            voices.firstOrNull { it.name == customVoiceName }
        } else if (settings.preferFemaleVoice) {
            selectBestFemaleVoice(voices, targetLocale.language)
        } else {
            null
        }

        if (chosenVoice != null) {
            tts.voice = chosenVoice
        }

        tts.setPitch(settings.speechPitch)
        tts.setSpeechRate(settings.speechSpeed)
    }

    private fun selectBestFemaleVoice(voices: Set<Voice>, targetLanguage: String): Voice? {
        val candidates = voices.filter {
            it.locale.language == targetLanguage || it.locale.language == "hi" || it.locale.language == "en"
        }
        // Prefer network-independent high-quality female voices matching Android engine naming hints
        return candidates.firstOrNull { voice ->
            val lower = voice.name.lowercase()
            voice.locale.language == targetLanguage &&
                (lower.contains("female") || lower.contains("hia") || lower.contains("hie") ||
                    lower.contains("inl") || lower.contains("-f-") || lower.endsWith("f"))
        } ?: candidates.firstOrNull { voice ->
            val lower = voice.name.lowercase()
            lower.contains("female") || lower.contains("hia") || lower.contains("hie")
        }
    }

    fun initSpeechRecognizer() {
        if (isReleased) return
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
                listener.onListeningError(
                    SpeechRecognizer.ERROR_CLIENT,
                    "Speech recognition is not available on this device."
                )
                return@post
            }
            try {
                speechRecognizer?.destroy()
            } catch (_: Exception) {
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                        listener.onListeningStarted()
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = (rmsdB / 10f).coerceIn(0f, 1f)
                        listener.onMicRmsChanged(normalized * 0.45f)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        isListening = false
                        listener.onMicRmsChanged(0f)
                        listener.onSpeechEnded()
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        listener.onMicRmsChanged(0f)
                        val msg = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech matched"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout"
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech network error"
                            else -> "Speech recognizer error ($error)"
                        }
                        listener.onListeningError(error, msg)
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        listener.onMicRmsChanged(0f)
                        val spoken = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        listener.onSpeechResult(spoken)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                        if (!partial.isNullOrBlank()) {
                            listener.onPartialSpeech(partial)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun startListening(interruptSpeaking: Boolean = true) {
        if (isReleased) return
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            listener.onListeningError(
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS,
                "Microphone permission required."
            )
            return
        }

        if (interruptSpeaking && isSpeaking) {
            stopSpeaking()
        }

        mainHandler.post {
            if (isReleased) return@post
            if (speechRecognizer == null) {
                initSpeechRecognizer()
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, settings.languageCode)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, settings.languageCode)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
            }
            try {
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                isListening = false
                listener.onListeningError(
                    SpeechRecognizer.ERROR_CLIENT,
                    "Could not start speech listener: ${e.localizedMessage ?: "Error"}"
                )
            }
        }
    }

    fun stopListening() {
        isListening = false
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
            listener.onMicRmsChanged(0f)
        }
    }

    fun speak(text: String, onCompleted: (() -> Unit)? = null) {
        if (isReleased || !settings.soundEnabled || !isTtsReady || text.isBlank()) {
            onCompleted?.invoke()
            return
        }
        onSpeakCompletedAction = onCompleted
        val utteranceId = UUID.randomUUID().toString()
        val params = Bundle().apply {
            if (ttsAudioSessionId > 0) {
                putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, ttsAudioSessionId)
            }
        }
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun stopSpeaking() {
        isSpeaking = false
        onSpeakCompletedAction = null
        try {
            textToSpeech?.stop()
        } catch (_: Exception) {
        }
        listener.onSpeakingFinished()
    }

    fun release() {
        isReleased = true
        isListening = false
        isSpeaking = false
        onSpeakCompletedAction = null
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
            } catch (_: Exception) {
            } finally {
                speechRecognizer = null
            }
        }
        isTtsReady = false
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (_: Exception) {
        } finally {
            textToSpeech = null
        }
    }
}
