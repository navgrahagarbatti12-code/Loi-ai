package com.looi.ai.automation

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import com.looi.ai.memory.MemoryRepository

data class InstalledAppInfo(
    val packageName: String,
    val label: String
)

/**
 * Resolves and launches installed Android applications by spoken name (English/Hinglish)
 * using PackageManager <queries> and records usage frequency in Room memory.
 */
object AppLauncherHelper {

    private val commonAliases = mapOf(
        "youtube" to listOf("com.google.android.youtube"),
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "chrome" to listOf("com.android.chrome"),
        "instagram" to listOf("com.instagram.android"),
        "settings" to listOf("com.android.settings"),
        "camera" to listOf("com.android.camera", "com.google.android.GoogleCamera"),
        "play store" to listOf("com.android.vending"),
        "acode" to listOf("com.foxdebug.acodefree", "com.foxdebug.acode"),
        "trebedit" to listOf("com.teejay.trebedit"),
        "spck" to listOf("io.spck"),
        "quickedit" to listOf("com.rhmsoft.edit"),
        "anwriter" to listOf("com.ansm.anwriter"),
        "html editor" to listOf(
            "com.foxdebug.acodefree",
            "com.foxdebug.acode",
            "com.teejay.trebedit",
            "io.spck",
            "com.rhmsoft.edit",
            "com.ansm.anwriter"
        )
    )

    fun listLaunchableApps(context: Context): List<InstalledAppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolves: List<ResolveInfo> = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolves.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            val label = info.loadLabel(pm)?.toString() ?: pkg
            InstalledAppInfo(pkg, label)
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    fun findPackageForQuery(context: Context, spokenName: String): InstalledAppInfo? {
        val normalized = spokenName.trim().lowercase()
        if (normalized.isBlank()) return null

        val installed = listLaunchableApps(context)

        // 1. Check known aliases first
        for ((alias, packages) in commonAliases) {
            if (normalized.contains(alias)) {
                for (pkg in packages) {
                    val match = installed.firstOrNull { it.packageName == pkg }
                    if (match != null) return match
                }
            }
        }

        // 2. Exact label match
        installed.firstOrNull { it.label.lowercase() == normalized }?.let { return it }

        // 3. Partial label or package match
        return installed.firstOrNull {
            it.label.lowercase().contains(normalized) || normalized.contains(it.label.lowercase())
        }
    }

    suspend fun launchApp(
        context: Context,
        spokenName: String,
        memoryRepository: MemoryRepository? = null
    ): Result<InstalledAppInfo> {
        val app = findPackageForQuery(context, spokenName)
            ?: return Result.failure(IllegalStateException("$spokenName app phone mein install nahi mili."))

        val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } ?: return Result.failure(IllegalStateException("${app.label} ko launch karne ka permission/intent nahi mila."))

        return try {
            context.startActivity(launchIntent)
            memoryRepository?.recordAppUsage(app.packageName, app.label)
            Result.success(app)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("${app.label} open karne mein error aaya: ${e.localizedMessage}"))
        }
    }

    fun launchPackage(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } ?: return false
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
