package com.looi.ai.automation

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.looi.ai.accessibility.LooiAccessibilityService
import com.looi.ai.ai.gemini.GeminiLiveClient
import com.looi.ai.ai.groq.GroqManager
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.delay
import java.io.File

/**
 * Dedicated AI Code Editor Automation Engine.
 * Operates installed Android HTML/JS/CSS editors (Acode, TrebEdit, Spck, QuickEdit, AnWriter)
 * via AccessibilityService, with a reliable FileProvider .html file + Browser/Editor launch
 * fallback if the installed editor's code canvas does not expose an editable accessibility node.
 */
class HtmlEditorAutomationEngine(
    private val context: Context,
    private val settings: SettingsManager,
    private val groqManager: GroqManager,
    private val geminiClient: GeminiLiveClient
) {

    private val knownEditorPackages = listOf(
        "com.foxdebug.acodefree",
        "com.foxdebug.acode",
        "com.teejay.trebedit",
        "io.spck",
        "com.rhmsoft.edit",
        "com.ansm.anwriter"
    )

    fun detectInstalledHtmlEditor(): InstalledAppInfo? {
        val apps = AppLauncherHelper.listLaunchableApps(context)
        val preferred = settings.preferredHtmlEditorPackage
        if (preferred.isNotBlank()) {
            apps.firstOrNull { it.packageName == preferred }?.let { return it }
        }
        for (pkg in knownEditorPackages) {
            apps.firstOrNull { it.packageName == pkg }?.let { return it }
        }
        return apps.firstOrNull {
            val l = it.label.lowercase()
            l.contains("html") || l.contains("acode") || l.contains("trebedit") || l.contains("code editor")
        }
    }

    suspend fun generateHtmlProjectAndRun(userRequest: String): AutomationResult {
        val codeResult = generateCompleteHtmlFromAi(userRequest)
        val htmlCode = codeResult.getOrElse { err ->
            return AutomationResult(
                false,
                "HTML code generate nahi ho paya: ${err.localizedMessage ?: "AI API error"}"
            )
        }

        // Always save a real .html file on device storage for backup & FileProvider execution
        val savedFile = saveHtmlToLocalProjects(htmlCode, deriveFileName(userRequest))
        val editor = detectInstalledHtmlEditor()
        val svc = LooiAccessibilityService.instance

        if (editor != null && svc != null) {
            val launched = AppLauncherHelper.launchPackage(context, editor.packageName)
            if (launched) {
                delay(1600)
                // Try creating a new file if a New File / + button exists and no editor field is visible yet
                var hasEditable = svc.captureScreenSnapshot()?.editableHints?.isNotEmpty() == true
                if (!hasEditable) {
                    svc.clickByTextOrDescription("New file") ||
                        svc.clickByTextOrDescription("Create") ||
                        svc.clickByTextOrDescription("Add") ||
                        svc.clickByViewIdSuffix("fab", "add", "new_file")
                    delay(1000)
                    hasEditable = svc.captureScreenSnapshot()?.editableHints?.isNotEmpty() == true
                }

                if (hasEditable && svc.inputTextIntoField(htmlCode, replaceExisting = true)) {
                    delay(600)
                    val savedUi = clickSaveButton(svc)
                    delay(500)
                    val ranUi = clickRunOrPreviewButton(svc)
                    delay(1200)

                    val postRunSnapshot = svc.captureScreenSnapshot()
                    val runtimeError = postRunSnapshot?.detectedErrorText
                    if (!runtimeError.isNullOrBlank()) {
                        return AutomationResult(
                            true,
                            "${editor.label} mein code insert aur run kiya, lekin ek error dikh raha hai: $runtimeError. Bolo 'error fix karo' toh main fix kar doongi.",
                            verifiedOnScreen = true
                        )
                    }

                    val statusMsg = buildString {
                        append("${editor.label} mein complete HTML code insert kar diya")
                        if (savedUi) append(", file save ho gayi")
                        if (ranUi) append(", aur Run/Preview start kar diya hai!")
                        else append(". Preview ke liye Run button tap karein.")
                    }
                    return AutomationResult(true, statusMsg, verifiedOnScreen = ranUi || savedUi)
                }
            }
        }

        // Reliable supported fallback: copy code to clipboard AND open the generated HTML file directly
        copyToClipboard(htmlCode)
        val launchedFallback = openHtmlFileInEditorOrBrowser(savedFile, editor?.packageName)
        return if (launchedFallback) {
            val viaNote = if (editor != null && svc == null) {
                "LOOI Accessibility Service off hone ke karan direct HTML file (${savedFile.name}) open kar di hai aur code clipboard par copy kar diya hai."
            } else {
                "Installed code editor ka text field accessibility ke liye lock tha, isliye maine ${savedFile.name} file banakar directly launch kar di hai aur code clipboard par bhi copy kar diya hai."
            }
            AutomationResult(true, viaNote, verifiedOnScreen = false)
        } else {
            AutomationResult(
                false,
                "HTML code clipboard par copy ho gaya hai aur ${savedFile.name} save ho gayi hai, lekin viewer app open nahi ho paya."
            )
        }
    }

    suspend fun fixCurrentEditorErrors(): AutomationResult {
        val svc = LooiAccessibilityService.instance
            ?: return AutomationResult(false, "Editor code padhne ke liye Accessibility Service enable karo.")

        val snapshot = svc.captureScreenSnapshot()
        val currentCode = svc.getAllEditableText()
        val visibleError = snapshot?.detectedErrorText

        if (currentCode.isNullOrBlank()) {
            return AutomationResult(
                false,
                "Current screen par editable HTML code field access nahi ho raha hai."
            )
        }

        val fixPrompt = """
            Fix all HTML, CSS, and JavaScript syntax or runtime errors in the code below.
            Visible error on screen: ${visibleError ?: "Unknown / check syntax cleanly"}
            Return ONLY the complete corrected single-file HTML code with no markdown fences or explanation.
            
            Code:
            $currentCode
        """.trimIndent()

        val fixedResult = callAiForRawHtml(fixPrompt)
        val fixedHtml = fixedResult.getOrElse { err ->
            return AutomationResult(false, "Code fix karne mein AI error aaya: ${err.localizedMessage}")
        }

        val replaced = svc.inputTextIntoField(fixedHtml, replaceExisting = true)
        if (!replaced) {
            copyToClipboard(fixedHtml)
            return AutomationResult(
                false,
                "Editor mein direct replace failed, corrected code clipboard par copy kar diya hai."
            )
        }

        delay(500)
        clickSaveButton(svc)
        delay(400)
        val ran = clickRunOrPreviewButton(svc)
        return AutomationResult(
            true,
            if (ran) "Code errors fix karke dubara save aur run kar diya hai!" else "Code fix karke editor mein update kar diya hai!",
            verifiedOnScreen = true
        )
    }

    suspend fun modifyCurrentEditorCode(instruction: String): AutomationResult {
        val svc = LooiAccessibilityService.instance
            ?: return AutomationResult(false, "Editor modify karne ke liye Accessibility Service enable karo.")

        val currentCode = svc.getAllEditableText()
            ?: return generateHtmlProjectAndRun(instruction)

        val editPrompt = """
            Modify the following HTML/CSS/JS file according to this user request: "$instruction"
            Return ONLY the complete updated single-file HTML document without markdown backticks or commentary.
            
            Existing code:
            $currentCode
        """.trimIndent()

        val updated = callAiForRawHtml(editPrompt).getOrElse { err ->
            return AutomationResult(false, "Code update nahi ho paya: ${err.localizedMessage}")
        }

        val replaced = svc.inputTextIntoField(updated, replaceExisting = true)
        if (!replaced) {
            val savedFile = saveHtmlToLocalProjects(updated, "looi_updated_${System.currentTimeMillis()}.html")
            copyToClipboard(updated)
            openHtmlFileInEditorOrBrowser(savedFile, null)
            return AutomationResult(
                true,
                "Editor accessibility lock tha isliye updated HTML file open kar di aur code clipboard par copy kar diya."
            )
        }

        delay(500)
        clickSaveButton(svc)
        delay(400)
        clickRunOrPreviewButton(svc)
        return AutomationResult(true, "Code update karke save aur run kar diya hai!", verifiedOnScreen = true)
    }

    fun runCurrentEditorProject(): AutomationResult {
        val svc = LooiAccessibilityService.instance
            ?: return AutomationResult(false, "Run button dabane ke liye Accessibility Service enable karo.")
        clickSaveButton(svc)
        val ran = clickRunOrPreviewButton(svc)
        return if (ran) {
            AutomationResult(true, "Run button press kar diya hai!", verifiedOnScreen = true)
        } else {
            AutomationResult(false, "Screen par Run ya Preview button nahi mila.")
        }
    }

    private suspend fun generateCompleteHtmlFromAi(userRequest: String): Result<String> {
        val prompt = """
            Create a complete, polished, mobile-friendly, touch-playable single-file HTML5 web app/game for this request:
            "$userRequest"
            Requirements:
            - Single self-contained HTML file with inline <style> and <script>.
            - Works smoothly on mobile touch screens (include on-screen touch controls for games like Snake/Racing/Shooting).
            - Zero external CDN dependencies, zero syntax errors.
            - Return ONLY raw HTML starting with <!DOCTYPE html>. Do NOT wrap in ```html markdown fences.
        """.trimIndent()
        return callAiForRawHtml(prompt)
    }

    private suspend fun callAiForRawHtml(prompt: String): Result<String> {
        val systemPrompt =
            "You are an expert mobile HTML5, CSS3, and JavaScript developer. Output ONLY valid raw HTML code starting with <!DOCTYPE html> and nothing else."

        val useGroq = when (settings.aiProvider) {
            SettingsManager.PROVIDER_GROQ -> true
            SettingsManager.PROVIDER_GEMINI_DIRECT -> false
            SettingsManager.PROVIDER_BACKEND -> false
            else -> settings.groqApiKey.isNotBlank()
        }

        val rawResult = if (useGroq) {
            groqManager.generateText(systemPrompt, prompt, maxTokens = 3000, temperature = 0.3)
        } else if (settings.geminiApiKey.isNotBlank()) {
            geminiClient.generateDirectText(systemPrompt, prompt)
        } else {
            geminiClient.sendConversationTurn(
                userMessage = "$systemPrompt\n\n$prompt",
                detectedEmotion = "THINKING",
                detectedObjects = emptyList(),
                historyContext = ""
            )
        }

        return rawResult.map { stripMarkdownFences(it) }
    }

    private fun stripMarkdownFences(raw: String): String {
        var cleaned = raw.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.removePrefix("```html").removePrefix("```HTML").removePrefix("```").trim()
        }
        if (cleaned.endsWith("```")) {
            cleaned = cleaned.removeSuffix("```").trim()
        }
        return cleaned
    }

    private fun clickSaveButton(svc: LooiAccessibilityService): Boolean {
        return svc.clickByTextOrDescription("Save") ||
            svc.clickByViewIdSuffix("menu_save", "action_save", "btn_save")
    }

    private fun clickRunOrPreviewButton(svc: LooiAccessibilityService): Boolean {
        return svc.clickByTextOrDescription("Run") ||
            svc.clickByTextOrDescription("Preview") ||
            svc.clickByTextOrDescription("Play") ||
            svc.clickByViewIdSuffix("menu_run", "action_run", "btn_run", "preview")
    }

    private fun saveHtmlToLocalProjects(html: String, fileName: String): File {
        val dir = File(context.filesDir, "looi_projects").apply { mkdirs() }
        val file = File(dir, fileName)
        file.writeText(html)
        return file
    }

    private fun openHtmlFileInEditorOrBrowser(file: File, editorPackage: String?): Boolean {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "text/html")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (!editorPackage.isNullOrBlank()) {
                setPackage(editorPackage)
            }
        }
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            // Try generic browser/HTML chooser without package restriction
            val generic = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "text/html")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                context.startActivity(generic)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun copyToClipboard(text: String) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("LOOI HTML Code", text))
        } catch (_: Exception) {
        }
    }

    private fun deriveFileName(request: String): String {
        val slug = request.lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .take(24)
            .ifBlank { "looi_app" }
        return "$slug.html"
    }
}
