package com.looi.ai.automation

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.SystemClock
import android.view.KeyEvent
import com.looi.ai.accessibility.LooiAccessibilityService
import kotlinx.coroutines.delay

data class AutomationResult(
    val success: Boolean,
    val message: String,
    val verifiedOnScreen: Boolean = false
)

/**
 * Dedicated YouTube Automation Engine using official Android Intents,
 * standard Android media key events, and AccessibilityService verification.
 * Never uses unofficial YouTube APIs or claims a video played unless verified.
 */
class YouTubeAutomationEngine(
    private val context: Context
) {

    suspend fun openYouTube(): AutomationResult {
        val launched = AppLauncherHelper.launchPackage(context, YOUTUBE_PACKAGE)
        if (!launched) {
            // Browser fallback if official YouTube app is not installed
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://m.youtube.com")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                context.startActivity(webIntent)
                AutomationResult(true, "YouTube app nahi mila, browser mein YouTube open kar rahi hoon.")
            } catch (e: Exception) {
                AutomationResult(false, "YouTube open nahi ho paya: ${e.localizedMessage}")
            }
        }

        delay(1200)
        val verified = verifyYouTubeForeground()
        return AutomationResult(
            success = true,
            verifiedOnScreen = verified,
            message = if (verified) {
                "Okay, YouTube open ho gaya hai."
            } else {
                "YouTube launch command bhej diya hai."
            }
        )
    }

    suspend fun searchYouTube(query: String, autoPlayFirstResult: Boolean = false): AutomationResult {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) {
            return AutomationResult(false, "Search karne ke liye video ya channel ka naam batao.")
        }

        val searchUri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(cleanQuery)}")
        val intent = Intent(Intent.ACTION_VIEW, searchUri).apply {
            setPackage(YOUTUBE_PACKAGE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        val launchedApp = try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            // Try ACTION_SEARCH fallback
            val fallbackSearch = Intent(Intent.ACTION_SEARCH).apply {
                setPackage(YOUTUBE_PACKAGE)
                putExtra("query", cleanQuery)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(fallbackSearch)
                true
            } catch (_: Exception) {
                false
            }
        }

        if (!launchedApp) {
            return AutomationResult(false, "YouTube search start nahi ho paya. Kya YouTube app installed hai?")
        }

        delay(1800)
        val svc = LooiAccessibilityService.instance
        if (svc != null && autoPlayFirstResult) {
            val played = playSearchResultByTitleOrFirst(cleanQuery)
            if (played.success) {
                return played
            }
        }

        val verified = verifyYouTubeForeground()
        return AutomationResult(
            success = true,
            verifiedOnScreen = verified,
            message = "YouTube par '$cleanQuery' search kar diya hai."
        )
    }

    suspend fun playSearchResultByTitleOrFirst(hint: String? = null): AutomationResult {
        val svc = LooiAccessibilityService.instance
            ?: return AutomationResult(
                false,
                "Video select karke play karne ke liye LOOI Accessibility Service enable karo."
            )

        if (!verifyYouTubeForeground()) {
            return AutomationResult(false, "Abhi YouTube screen par open nahi hai.")
        }

        val snapshot = svc.captureScreenSnapshot()
        val targetTitle = if (!hint.isNullOrBlank()) {
            snapshot?.clickableLabels?.firstOrNull {
                it.length > 10 && it.lowercase().contains(hint.lowercase()) &&
                    !isYouTubeChromeButton(it)
            }
        } else {
            null
        } ?: snapshot?.clickableLabels?.firstOrNull {
            it.length > 14 && !isYouTubeChromeButton(it)
        }

        if (targetTitle != null && svc.clickByTextOrDescription(targetTitle)) {
            delay(1300)
            val after = svc.captureScreenSnapshot()
            val openedPlayer = after?.packageName == YOUTUBE_PACKAGE
            return AutomationResult(
                success = openedPlayer,
                verifiedOnScreen = openedPlayer,
                message = "Yeh video play kar rahi hoon: ${targetTitle.take(60)}"
            )
        }

        return AutomationResult(false, "Screen par koi playable video result nahi mila.")
    }

    fun pauseVideo(): AutomationResult {
        val svc = LooiAccessibilityService.instance
        val clickedUi = svc?.let {
            if (verifyYouTubeForeground()) {
                it.clickByTextOrDescription("Pause video") ||
                    it.clickByTextOrDescription("Pause") ||
                    it.clickByViewIdSuffix("player_control_play_pause_replay_button")
            } else {
                false
            }
        } ?: false

        val mediaSent = dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
        return if (clickedUi || mediaSent) {
            AutomationResult(true, "Video pause kar diya hai.", verifiedOnScreen = clickedUi)
        } else {
            AutomationResult(false, "Video pause nahi ho paya.")
        }
    }

    fun resumeVideo(): AutomationResult {
        val svc = LooiAccessibilityService.instance
        val clickedUi = svc?.let {
            if (verifyYouTubeForeground()) {
                it.clickByTextOrDescription("Play video") ||
                    it.clickByTextOrDescription("Play") ||
                    it.clickByViewIdSuffix("player_control_play_pause_replay_button")
            } else {
                false
            }
        } ?: false

        val mediaSent = dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        return if (clickedUi || mediaSent) {
            AutomationResult(true, "Video resume kar diya hai.", verifiedOnScreen = clickedUi)
        } else {
            AutomationResult(false, "Video resume nahi ho paya.")
        }
    }

    fun nextVideo(): AutomationResult {
        val svc = LooiAccessibilityService.instance
        val clickedUi = svc?.let {
            if (verifyYouTubeForeground()) {
                it.clickByTextOrDescription("Next video") ||
                    it.clickByTextOrDescription("Next") ||
                    it.clickByViewIdSuffix("player_control_next_button")
            } else {
                false
            }
        } ?: false

        val mediaSent = if (!clickedUi) dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT) else false
        return if (clickedUi || mediaSent) {
            AutomationResult(true, "Next video chala rahi hoon.", verifiedOnScreen = clickedUi)
        } else {
            AutomationResult(false, "Next video button ya media session nahi mila.")
        }
    }

    fun previousVideo(): AutomationResult {
        val svc = LooiAccessibilityService.instance
        val clickedUi = svc?.let {
            if (verifyYouTubeForeground()) {
                it.clickByTextOrDescription("Previous video") ||
                    it.clickByTextOrDescription("Previous") ||
                    it.clickByViewIdSuffix("player_control_previous_button")
            } else {
                false
            }
        } ?: false

        val mediaSent = if (!clickedUi) dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) else false
        return if (clickedUi || mediaSent) {
            AutomationResult(true, "Previous video par wapas jaa rahi hoon.", verifiedOnScreen = clickedUi)
        } else {
            AutomationResult(false, "Previous video control nahi mila.")
        }
    }

    fun scrollRecommendations(down: Boolean = true): AutomationResult {
        val svc = LooiAccessibilityService.instance
            ?: return AutomationResult(false, "Scroll karne ke liye Accessibility Service enable karo.")
        val scrolled = svc.scrollScreen(forward = down)
        return if (scrolled) {
            AutomationResult(true, "Recommendations scroll kar diya.", verifiedOnScreen = true)
        } else {
            AutomationResult(false, "Screen scroll nahi ho payi.")
        }
    }

    fun openVisibleChannel(): AutomationResult {
        val svc = LooiAccessibilityService.instance
            ?: return AutomationResult(false, "Channel open karne ke liye Accessibility Service enable karo.")
        val clicked = svc.clickByViewIdSuffix("channel_name", "owner_avatar", "avatar") ||
            svc.clickByTextOrDescription("Go to channel")
        return if (clicked) {
            AutomationResult(true, "Channel page open kar rahi hoon.", verifiedOnScreen = true)
        } else {
            AutomationResult(false, "Screen par channel link nahi mila.")
        }
    }

    fun subscribeWithUserConfirmation(confirmedByUser: Boolean): AutomationResult {
        if (!confirmedByUser) {
            return AutomationResult(
                false,
                "Confirmation chahiye: Kya aap sach mein is channel ko subscribe karna chahte ho? Bolo 'Haan subscribe karo'."
            )
        }
        val svc = LooiAccessibilityService.instance
            ?: return AutomationResult(false, "Subscribe karne ke liye Accessibility Service enable karo.")
        val clicked = svc.clickByTextOrDescription("Subscribe", exactMatch = true)
        return if (clicked) {
            AutomationResult(true, "Channel subscribe button press kar diya hai.", verifiedOnScreen = true)
        } else {
            AutomationResult(false, "Subscribe button screen par nahi mila (ho sakta hai already subscribed ho).")
        }
    }

    fun readVisibleVideoTitlesAndDescription(): AutomationResult {
        val svc = LooiAccessibilityService.instance
            ?: return AutomationResult(false, "Screen padhne ke liye LOOI Accessibility Service enable karo.")
        val snapshot = svc.captureScreenSnapshot()
            ?: return AutomationResult(false, "Screen content read nahi ho paya.")

        val candidateTitles = snapshot.visibleTexts.filter { text ->
            text.length > 10 && !isYouTubeChromeButton(text)
        }.take(5)

        return if (candidateTitles.isEmpty()) {
            AutomationResult(false, "YouTube par koi video title ya description read nahi ho paya.")
        } else {
            AutomationResult(
                true,
                "Screen par yeh dikh raha hai: ${candidateTitles.joinToString(". ")}",
                verifiedOnScreen = true
            )
        }
    }

    private fun verifyYouTubeForeground(): Boolean {
        val activePkg = LooiAccessibilityService.activeAppPackage.value
        val snapPkg = LooiAccessibilityService.instance?.captureScreenSnapshot()?.packageName.orEmpty()
        return activePkg == YOUTUBE_PACKAGE || snapPkg == YOUTUBE_PACKAGE
    }

    private fun isYouTubeChromeButton(label: String): Boolean {
        val lower = label.lowercase()
        return lower == "home" || lower == "shorts" || lower == "subscriptions" ||
            lower == "you" || lower == "search" || lower == "cast" ||
            lower == "notifications" || lower == "create" || lower == "more options"
    }

    private fun dispatchMediaKey(keyCode: Int): Boolean {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val now = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
            true
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        const val YOUTUBE_PACKAGE = "com.google.android.youtube"
    }
}
