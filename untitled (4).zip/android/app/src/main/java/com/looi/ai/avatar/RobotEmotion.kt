package com.looi.ai.avatar

enum class RobotEmotion {
    HAPPY,
    CURIOUS,
    SURPRISED,
    TALKING,
    LISTENING,
    THINKING,
    SAD,
    ANGRY,
    SLEEPING,
    SEARCHING
}
