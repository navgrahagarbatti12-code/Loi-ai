package com.looi.ai.camera

import android.content.Context
import android.os.Looper
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Production-ready CameraX Manager for LOOI AI.
 * Handles front-facing camera binding, PreviewView rendering,
 * session-token race-condition prevention, ordered teardown before ML Kit detector close,
 * and background frame analysis.
 */
class CameraXManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val previewView: PreviewView
) {
    private val tag = "CameraXManager"
    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalyzer: ImageAnalysis? = null

    @Volatile
    private var isRunning = false
    @Volatile
    private var isStarting = false
    @Volatile
    private var isReleased = false
    private val sessionToken = AtomicInteger(0)

    fun startCamera(analyzer: ImageAnalysis.Analyzer, onError: (Exception) -> Unit) {
        if (isReleased || isRunning || isStarting) {
            Log.d(tag, "CameraX skipped start (released=$isReleased running=$isRunning starting=$isStarting).")
            return
        }
        if (lifecycleOwner.lifecycle.currentState == Lifecycle.State.DESTROYED) {
            return
        }

        val activeToken = sessionToken.incrementAndGet()
        isStarting = true
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            isStarting = false
            if (isReleased ||
                activeToken != sessionToken.get() ||
                lifecycleOwner.lifecycle.currentState == Lifecycle.State.DESTROYED
            ) {
                Log.d(tag, "CameraX async start aborted due to stop/release or lifecycle destruction.")
                return@addListener
            }

            try {
                if (cameraExecutor.isShutdown) {
                    cameraExecutor = Executors.newSingleThreadExecutor()
                }

                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val preview = Preview.Builder()
                    .build()
                    .also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                imageAnalyzer = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, analyzer)
                    }

                val cameraSelector = CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                    .build()

                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageAnalyzer
                )

                isRunning = true
                Log.d(tag, "CameraX front camera started.")
            } catch (exc: Exception) {
                isRunning = false
                Log.e(tag, "Camera initialization failed", exc)
                onError(exc)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stopCamera(onStopped: (() -> Unit)? = null) {
        sessionToken.incrementAndGet()
        isStarting = false
        isRunning = false

        val unbindAction = Runnable {
            try {
                imageAnalyzer?.clearAnalyzer()
                imageAnalyzer = null
                cameraProvider?.unbindAll()
                Log.d(tag, "CameraX unbound safely.")
            } catch (e: Exception) {
                Log.w(tag, "Error stopping CameraX: ${e.message}")
            } finally {
                onStopped?.invoke()
            }
        }

        if (Looper.myLooper() == Looper.getMainLooper()) {
            unbindAction.run()
        } else {
            ContextCompat.getMainExecutor(context).execute(unbindAction)
        }
    }

    /**
     * Stops CameraX first and runs [afterExecutorShutdown] once pending frames flush,
     * ensuring ML Kit detectors are never closed while an ImageProxy is still in flight.
     */
    fun release(afterExecutorShutdown: (() -> Unit)? = null) {
        isReleased = true
        stopCamera {
            if (!cameraExecutor.isShutdown) {
                cameraExecutor.shutdown()
                try {
                    cameraExecutor.awaitTermination(250, TimeUnit.MILLISECONDS)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
            afterExecutorShutdown?.invoke()
        }
    }

    fun isCameraRunning(): Boolean = isRunning
}
