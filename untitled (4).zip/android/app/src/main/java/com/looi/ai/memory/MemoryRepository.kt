package com.looi.ai.memory

import com.looi.ai.memory.database.ActionHistoryEntity
import com.looi.ai.memory.database.AppUsageEntity
import com.looi.ai.memory.database.ConversationDao
import com.looi.ai.memory.database.ConversationEntity
import com.looi.ai.memory.database.UserPreferenceEntity
import kotlinx.coroutines.flow.Flow

class MemoryRepository(private val conversationDao: ConversationDao) {

    val allConversations: Flow<List<ConversationEntity>> = conversationDao.getAllMessages()
    val allActionHistory: Flow<List<ActionHistoryEntity>> = conversationDao.getActionHistory()

    suspend fun recordUserMessage(text: String, emotion: String? = null) {
        conversationDao.insertMessage(
            ConversationEntity(
                sender = "USER",
                messageText = text,
                detectedEmotion = emotion
            )
        )
    }

    suspend fun recordLooiResponse(text: String) {
        conversationDao.insertMessage(
            ConversationEntity(
                sender = "LOOI",
                messageText = text
            )
        )
    }

    suspend fun recordActionExecution(
        commandText: String,
        targetApp: String,
        planSummary: String,
        status: String,
        resultDetail: String
    ) {
        conversationDao.insertActionHistory(
            ActionHistoryEntity(
                commandText = commandText,
                targetApp = targetApp,
                planSummary = planSummary,
                status = status,
                resultDetail = resultDetail
            )
        )
    }

    suspend fun savePreference(key: String, value: String) {
        conversationDao.upsertPreference(
            UserPreferenceEntity(prefKey = key, prefValue = value)
        )
    }

    suspend fun recordAppUsage(packageName: String, appLabel: String) {
        val existing = conversationDao.getAppUsage(packageName)
        conversationDao.upsertAppUsage(
            AppUsageEntity(
                packageName = packageName,
                appLabel = appLabel,
                usageCount = (existing?.usageCount ?: 0) + 1,
                lastUsedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun getRecentContextSummary(): String {
        val recents = conversationDao.getRecentContext()
        val recentActions = conversationDao.getRecentActions()
        val prefs = conversationDao.getAllPreferences()
        val topApps = conversationDao.getTopApps()

        val sb = StringBuilder()
        if (prefs.isNotEmpty()) {
            sb.append("User Preferences: ")
            sb.append(prefs.take(6).joinToString("; ") { "${it.prefKey}=${it.prefValue}" })
            sb.append("\n")
        }
        if (topApps.isNotEmpty()) {
            sb.append("Frequently Used Apps: ")
            sb.append(topApps.take(5).joinToString(", ") { "${it.appLabel}(${it.usageCount})" })
            sb.append("\n")
        }
        if (recentActions.isNotEmpty()) {
            sb.append("Recent Automation Results:\n")
            recentActions.take(4).forEach {
                sb.append("- [${it.status}] ${it.commandText} -> ${it.resultDetail}\n")
            }
        }
        if (recents.isEmpty()) {
            sb.append("No prior chat history.")
        } else {
            sb.append("Recent Conversation:\n")
            sb.append(recents.reversed().joinToString("\n") { "${it.sender}: ${it.messageText}" })
        }
        return sb.toString().trim()
    }

    suspend fun clearMemory() {
        conversationDao.clearAll()
        conversationDao.clearActionHistory()
        conversationDao.clearPreferences()
        conversationDao.clearAppUsage()
    }

    suspend fun clearActionHistoryOnly() {
        conversationDao.clearActionHistory()
    }
}
