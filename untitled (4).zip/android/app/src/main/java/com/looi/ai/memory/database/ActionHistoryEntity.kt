package com.looi.ai.memory.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "action_history")
data class ActionHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val commandText: String,
    val targetApp: String,
    val planSummary: String,
    val status: String, // COMPLETED, FAILED, CANCELLED
    val resultDetail: String,
    val timestamp: Long = System.currentTimeMillis()
)
