package com.looi.ai.memory.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_usage")
data class AppUsageEntity(
    @PrimaryKey
    val packageName: String,
    val appLabel: String,
    val usageCount: Int = 1,
    val lastUsedAt: Long = System.currentTimeMillis()
)
