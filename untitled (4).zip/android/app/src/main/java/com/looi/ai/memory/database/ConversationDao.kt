package com.looi.ai.memory.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {

    @Query("SELECT * FROM conversations ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations ORDER BY timestamp DESC LIMIT 12")
    suspend fun getRecentContext(): List<ConversationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ConversationEntity): Long

    @Query("DELETE FROM conversations")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM conversations")
    suspend fun getCount(): Int

    // Action History
    @Query("SELECT * FROM action_history ORDER BY timestamp DESC LIMIT 100")
    fun getActionHistory(): Flow<List<ActionHistoryEntity>>

    @Query("SELECT * FROM action_history ORDER BY timestamp DESC LIMIT 6")
    suspend fun getRecentActions(): List<ActionHistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActionHistory(entry: ActionHistoryEntity): Long

    @Query("DELETE FROM action_history")
    suspend fun clearActionHistory()

    // User Preferences Memory
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPreference(pref: UserPreferenceEntity)

    @Query("SELECT * FROM user_preferences ORDER BY updatedAt DESC")
    suspend fun getAllPreferences(): List<UserPreferenceEntity>

    @Query("DELETE FROM user_preferences")
    suspend fun clearPreferences()

    // App Usage Frequency
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAppUsage(appUsage: AppUsageEntity)

    @Query("SELECT * FROM app_usage WHERE packageName = :pkg LIMIT 1")
    suspend fun getAppUsage(pkg: String): AppUsageEntity?

    @Query("SELECT * FROM app_usage ORDER BY usageCount DESC, lastUsedAt DESC LIMIT 8")
    suspend fun getTopApps(): List<AppUsageEntity>

    @Query("DELETE FROM app_usage")
    suspend fun clearAppUsage()
}
