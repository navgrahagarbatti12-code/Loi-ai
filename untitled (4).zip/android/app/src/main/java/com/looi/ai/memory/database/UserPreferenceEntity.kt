package com.looi.ai.memory.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_preferences")
data class UserPreferenceEntity(
    @PrimaryKey
    val prefKey: String,
    val prefValue: String,
    val updatedAt: Long = System.currentTimeMillis()
)
