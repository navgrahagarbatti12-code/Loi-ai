package com.looi.ai.planner

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.looi.ai.accessibility.LooiAccessibilityService
import com.looi.ai.ai.gemini.GeminiLiveClient
import com.looi.ai.ai.groq.GroqManager
import com.looi.ai.automation.AppLauncherHelper
import com.looi.ai.settings.SettingsManager

enum class ActionType {
    OPEN_APP,
    YOUTUBE_OPEN,
    YOUTUBE_SEARCH_PLAY,
    YOUTUBE_PAUSE,
    YOUTUBE_RESUME,
    YOUTUBE_NEXT,
    YOUTUBE_PREVIOUS,
    YOUTUBE_SCROLL_DOWN,
    YOUTUBE_SCROLL_UP,
    YOUTUBE_OPEN_CHANNEL,
    YOUTUBE_SUBSCRIBE,
    YOUTUBE_READ_SCREEN,
    SCREEN_EXPLAIN,
    HTML_CREATE_RUN,
    HTML_MODIFY,
    HTML_FIX_ERRORS,
    HTML_RUN,
    UI_CLICK,
    UI_INPUT,
    UI_SCROLL_DOWN,
    UI_SCROLL_UP,
    UI_SWIPE_LEFT,
    UI_SWIPE_RIGHT,
    UI_NAVIGATE_BACK,
    UI_NAVIGATE_HOME,
    UI_OPEN_RECENTS,
    CANCEL_TASK,
    CONVERSATION
}

data class ActionStep(
    val type: ActionType,
    val target: String = "",
    val query: String = "",
    val text: String = "",
    val autoPlay: Boolean = true,
    val requireConfirmation: Boolean = false,
    val description: String = ""
)

data class ActionPlan(
    val intentSummary: String,
    val targetApp: String,
    val steps: List<ActionStep>,
    val isPureConversation: Boolean = false
)

/**
 * Converts Hindi, Hinglish, and English voice commands into structured multi-step executable plans.
 * Uses deterministic fast-path intent recognition for speed/reliability and AI JSON planning for complex multi-step requests.
 */
class ActionPlanner(
    private val context: Context,
    private val settings: SettingsManager,
    private val groqManager: GroqManager,
    private val geminiClient: GeminiLiveClient
) {
    private val tag = "ActionPlanner"
    private val gson = Gson()

    suspend fun createPlan(
        command: String,
        historyContext: String = "",
        hasPendingSubscribeConfirmation: Boolean = false
    ): ActionPlan {
        val raw = command.trim()
        val lower = raw.lowercase()

        // 1. Immediate cancellation commands
        if (matchesCancelCommand(lower)) {
            return ActionPlan(
                intentSummary = "Cancel active task",
                targetApp = "LOOI",
                steps = listOf(ActionStep(ActionType.CANCEL_TASK, description = "Stopping active automation"))
            )
        }

        // 2. Explicit confirmation for pending sensitive action (e.g., YouTube Subscribe)
        if (hasPendingSubscribeConfirmation && matchesSubscribeConfirm(lower)) {
            return ActionPlan(
                intentSummary = "Confirmed YouTube subscribe",
                targetApp = "YouTube",
                steps = listOf(
                    ActionStep(
                        type = ActionType.YOUTUBE_SUBSCRIBE,
                        requireConfirmation = false,
                        description = "Subscribing to channel after user confirmation"
                    )
                )
            )
        }

        // 3. Fast-path deterministic multi-step & single-step intents
        parseFastPath(raw, lower)?.let { return it }

        // 4. If command contains action verbs, ask AI planner for a structured JSON plan
        if (looksLikeActionableCommand(lower)) {
            val aiPlan = tryBuildAiPlan(raw, historyContext)
            if (aiPlan != null && aiPlan.steps.isNotEmpty()) {
                return aiPlan
            }
        }

        // 5. Fallback to natural conversational response
        return ActionPlan(
            intentSummary = "Conversation",
            targetApp = "LOOI",
            steps = listOf(ActionStep(ActionType.CONVERSATION, query = raw)),
            isPureConversation = true
        )
    }

    private fun matchesCancelCommand(lower: String): Boolean {
        return lower == "stop" || lower == "cancel" || lower == "ruko" ||
            lower.contains("ruk jao") || lower.contains("band karo") ||
            lower.contains("task cancel") || lower.contains("stop automation") ||
            lower.contains("looi stop") || lower.contains("looi ruko")
    }

    private fun matchesSubscribeConfirm(lower: String): Boolean {
        return lower.contains("haan") || lower.contains("yes") ||
            lower.contains("kar do") || lower.contains("confirm") ||
            lower.contains("subscribe karo")
    }

    private fun parseFastPath(raw: String, lower: String): ActionPlan? {
        // Screen understanding queries
        if (lower.contains("screen par kya") || lower.contains("screen pe kya") ||
            lower.contains("read screen") || lower.contains("explain screen") ||
            lower.contains("screen batao") || lower.contains("kya dikh raha hai") ||
            lower.contains("screen padho") || lower.contains("what is on my screen")
        ) {
            return ActionPlan(
                intentSummary = "Read and explain active screen",
                targetApp = LooiAccessibilityService.activeAppLabel.value,
                steps = listOf(ActionStep(ActionType.SCREEN_EXPLAIN, query = raw))
            )
        }

        // HTML / Code Editor commands
        if (isHtmlCodingCommand(lower)) {
            if (lower.contains("error fix") || lower.contains("bug fix") || lower.contains("fix error") ||
                lower.contains("sahi karo") && lower.contains("code")
            ) {
                return ActionPlan(
                    intentSummary = "Fix errors in HTML editor",
                    targetApp = "HTML Editor",
                    steps = listOf(ActionStep(ActionType.HTML_FIX_ERRORS, query = raw))
                )
            }
            if ((lower.contains("modify") || lower.contains("update") || lower.contains("change") || lower.contains("badlo")) &&
                (lower.contains("code") || lower.contains("html") || lower.contains("game") || lower.contains("page"))
            ) {
                return ActionPlan(
                    intentSummary = "Modify current HTML project",
                    targetApp = "HTML Editor",
                    steps = listOf(ActionStep(ActionType.HTML_MODIFY, query = raw))
                )
            }
            if ((lower.contains("run karo") || lower.contains("preview") || lower.contains("chalao")) &&
                (lower.contains("code") || lower.contains("html") || lower.contains("editor")) &&
                !lower.contains("banao") && !lower.contains("likho")
            ) {
                return ActionPlan(
                    intentSummary = "Run current HTML project",
                    targetApp = "HTML Editor",
                    steps = listOf(ActionStep(ActionType.HTML_RUN, query = raw))
                )
            }
            return ActionPlan(
                intentSummary = "Create & run HTML project",
                targetApp = "HTML Editor",
                steps = listOf(ActionStep(ActionType.HTML_CREATE_RUN, query = raw))
            )
        }

        // YouTube voice automation
        val activePkg = LooiAccessibilityService.activeAppPackage.value
        val inYouTube = activePkg == "com.google.android.youtube"
        if (lower.contains("youtube") || (inYouTube && isYouTubeControlVerb(lower))) {
            if (lower.contains("pause")) {
                return ActionPlan("Pause YouTube video", "YouTube", listOf(ActionStep(ActionType.YOUTUBE_PAUSE)))
            }
            if (lower.contains("resume") || (lower.contains("play") && !lower.contains("search") && extractYouTubeQuery(raw).isBlank())) {
                return ActionPlan("Resume YouTube video", "YouTube", listOf(ActionStep(ActionType.YOUTUBE_RESUME)))
            }
            if (lower.contains("next video") || lower.contains("agla video") || lower == "next") {
                return ActionPlan("Play next video", "YouTube", listOf(ActionStep(ActionType.YOUTUBE_NEXT)))
            }
            if (lower.contains("previous video") || lower.contains("pichla video") || lower == "previous") {
                return ActionPlan("Play previous video", "YouTube", listOf(ActionStep(ActionType.YOUTUBE_PREVIOUS)))
            }
            if (lower.contains("subscribe")) {
                return ActionPlan(
                    "Ask confirmation before subscribing",
                    "YouTube",
                    listOf(ActionStep(ActionType.YOUTUBE_SUBSCRIBE, requireConfirmation = true))
                )
            }
            if (lower.contains("channel kholo") || lower.contains("open channel")) {
                return ActionPlan("Open video channel", "YouTube", listOf(ActionStep(ActionType.YOUTUBE_OPEN_CHANNEL)))
            }
            if (lower.contains("title") || lower.contains("description") || lower.contains("video ka naam")) {
                return ActionPlan("Read YouTube screen", "YouTube", listOf(ActionStep(ActionType.YOUTUBE_READ_SCREEN)))
            }

            val query = extractYouTubeQuery(raw)
            if (query.isNotBlank()) {
                val shouldPlay = lower.contains("play") || lower.contains("chalao") ||
                    lower.contains("lagao") || lower.contains("bajaao") ||
                    lower.contains("dekho") || lower.contains("kholo")
                return ActionPlan(
                    intentSummary = "Search YouTube for '$query'",
                    targetApp = "YouTube",
                    steps = listOf(
                        ActionStep(
                            type = ActionType.YOUTUBE_SEARCH_PLAY,
                            query = query,
                            autoPlay = shouldPlay,
                            description = "Searching YouTube for $query"
                        )
                    )
                )
            }
            return ActionPlan("Open YouTube", "YouTube", listOf(ActionStep(ActionType.YOUTUBE_OPEN)))
        }

        // System navigation & generic UI control
        if (lower == "back" || lower.contains("back jao") || lower.contains("piche jao") || lower.contains("go back")) {
            return ActionPlan("Navigate Back", "System", listOf(ActionStep(ActionType.UI_NAVIGATE_BACK)))
        }
        if (lower == "home" || lower.contains("home jao") || lower.contains("go home") || lower.contains("home screen")) {
            return ActionPlan("Navigate Home", "System", listOf(ActionStep(ActionType.UI_NAVIGATE_HOME)))
        }
        if (lower.contains("recent apps") || lower == "recents" || lower.contains("recents kholo")) {
            return ActionPlan("Open Recent Apps", "System", listOf(ActionStep(ActionType.UI_OPEN_RECENTS)))
        }
        if (lower.contains("scroll down") || lower.contains("niche scroll")) {
            return ActionPlan("Scroll Down", LooiAccessibilityService.activeAppLabel.value, listOf(ActionStep(ActionType.UI_SCROLL_DOWN)))
        }
        if (lower.contains("scroll up") || lower.contains("upar scroll")) {
            return ActionPlan("Scroll Up", LooiAccessibilityService.activeAppLabel.value, listOf(ActionStep(ActionType.UI_SCROLL_UP)))
        }
        if (lower.contains("swipe left") || lower.contains("baayein swipe")) {
            return ActionPlan("Swipe Left", LooiAccessibilityService.activeAppLabel.value, listOf(ActionStep(ActionType.UI_SWIPE_LEFT)))
        }
        if (lower.contains("swipe right") || lower.contains("daayein swipe")) {
            return ActionPlan("Swipe Right", LooiAccessibilityService.activeAppLabel.value, listOf(ActionStep(ActionType.UI_SWIPE_RIGHT)))
        }

        // Click / Tap UI element: "click <label>" or "<label> par click karo"
        val clickMatch = Regex("""(?:click|tap|dabao|press)\s+(.+)""", RegexOption.IGNORE_CASE).find(raw)
            ?: Regex("""(.+?)\s+(?:par\s+)?(?:click|tap|dabao)\s*(?:karo|do)?""", RegexOption.IGNORE_CASE).find(raw)
        if (clickMatch != null) {
            val targetLabel = clickMatch.groupValues[1]
                .replace(Regex("""^(looi|hey looi)[,\s]*""", RegexOption.IGNORE_CASE), "")
                .trim()
            if (targetLabel.isNotBlank()) {
                return ActionPlan(
                    intentSummary = "Click '$targetLabel'",
                    targetApp = LooiAccessibilityService.activeAppLabel.value,
                    steps = listOf(ActionStep(ActionType.UI_CLICK, target = targetLabel))
                )
            }
        }

        // Input text: "type <text>" or "likho <text>"
        val typeMatch = Regex("""^(?:looi[,\s]+)?(?:type|likho|enter)\s+(.+)$""", RegexOption.IGNORE_CASE).find(raw)
        if (typeMatch != null) {
            val textToType = typeMatch.groupValues[1].trim()
            if (textToType.isNotBlank()) {
                return ActionPlan(
                    intentSummary = "Type text",
                    targetApp = LooiAccessibilityService.activeAppLabel.value,
                    steps = listOf(ActionStep(ActionType.UI_INPUT, text = textToType))
                )
            }
        }

        // Open installed app by name: "open <app>" or "<app> kholo"
        val appQuery = extractAppOpenQuery(raw)
        if (!appQuery.isNullOrBlank()) {
            val matchedApp = AppLauncherHelper.findPackageForQuery(context, appQuery)
            if (matchedApp != null) {
                return ActionPlan(
                    intentSummary = "Open ${matchedApp.label}",
                    targetApp = matchedApp.label,
                    steps = listOf(ActionStep(ActionType.OPEN_APP, target = appQuery))
                )
            }
        }

        return null
    }

    private fun isHtmlCodingCommand(lower: String): Boolean {
        val codeKeywords = listOf(
            "html", "acode", "trebedit", "spck", "quickedit", "anwriter",
            "snake game", "racing game", "webpage", "website", "web page",
            "calculator app", "html editor", "code likho", "game banao"
        )
        return codeKeywords.any { lower.contains(it) }
    }

    private fun isYouTubeControlVerb(lower: String): Boolean {
        return lower.contains("pause") || lower.contains("resume") ||
            lower.contains("next") || lower.contains("previous") ||
            lower.contains("subscribe") || lower.contains("channel") ||
            lower.contains("title") || lower.contains("description")
    }

    private fun extractYouTubeQuery(raw: String): String {
        var q = raw
            .replace(Regex("""^(hey\s+)?looi[,\s]*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\byoutube\b""", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("""\b(kholo|khol\s*ke|open|aur|and|par|pe|mein|me|ka|ki|ke|ko|search|karo|karke|play|chalao|lagao|bajaao|video|song|gaana)\b""", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
        // If stripping removed too much, keep only words between youtube/par and search/play
        if (q.length < 2) {
            val m = Regex("""(?:youtube\s+(?:par|pe|mein)?\s*)(.+?)(?:\s+(?:search|play|chalao|lagao).*)?$""", RegexOption.IGNORE_CASE).find(raw)
            q = m?.groupValues?.getOrNull(1)?.trim().orEmpty()
        }
        return q
    }

    private fun extractAppOpenQuery(raw: String): String? {
        val cleaned = raw.replace(Regex("""^(hey\s+)?looi[,\s]*""", RegexOption.IGNORE_CASE), "").trim()
        val m1 = Regex("""^(?:open|launch|start|kholo)\s+(.+)$""", RegexOption.IGNORE_CASE).find(cleaned)
        if (m1 != null) return m1.groupValues[1].trim()
        val m2 = Regex("""^(.+?)\s+(?:app\s+)?(?:kholo|khol\s+do|open\s+karo|launch\s+karo|chalu\s+karo)$""", RegexOption.IGNORE_CASE).find(cleaned)
        if (m2 != null) return m2.groupValues[1].trim()
        return null
    }

    private fun looksLikeActionableCommand(lower: String): Boolean {
        val actionHints = listOf(
            "kholo", "open", "launch", "search", "play", "chalao", "click", "tap",
            "scroll", "swipe", "back", "home", "type", "likho", "banao", "run",
            "screen", "pause", "next", "previous", "subscribe"
        )
        return actionHints.any { lower.contains(it) }
    }

    private suspend fun tryBuildAiPlan(command: String, historyContext: String): ActionPlan? {
        val screenSummary = LooiAccessibilityService.instance?.captureScreenSnapshot()?.toPromptSummary()
            ?: "No accessibility screen context available."

        val plannerSystemPrompt = """
            You are LOOI's Android Action Planner. Convert the user's command into JSON ONLY (no markdown).
            Available action types:
            OPEN_APP, YOUTUBE_OPEN, YOUTUBE_SEARCH_PLAY, YOUTUBE_PAUSE, YOUTUBE_RESUME, YOUTUBE_NEXT, YOUTUBE_PREVIOUS,
            YOUTUBE_SCROLL_DOWN, YOUTUBE_SCROLL_UP, YOUTUBE_OPEN_CHANNEL, YOUTUBE_SUBSCRIBE, YOUTUBE_READ_SCREEN,
            SCREEN_EXPLAIN, HTML_CREATE_RUN, HTML_MODIFY, HTML_FIX_ERRORS, HTML_RUN,
            UI_CLICK, UI_INPUT, UI_SCROLL_DOWN, UI_SCROLL_UP, UI_NAVIGATE_BACK, UI_NAVIGATE_HOME, UI_OPEN_RECENTS,
            CONVERSATION.
            
            Respond strictly with JSON:
            {"intentSummary":"...","targetApp":"...","steps":[{"type":"...","target":"...","query":"...","text":"...","autoPlay":true}]}
            If it's normal chat with no phone action, use a single CONVERSATION step.
        """.trimIndent()

        val plannerUserPrompt = """
            Current Screen:
            $screenSummary
            Recent Memory:
            $historyContext
            User Command: "$command"
        """.trimIndent()

        val useGroq = when (settings.aiProvider) {
            SettingsManager.PROVIDER_GROQ -> true
            SettingsManager.PROVIDER_GEMINI_DIRECT, SettingsManager.PROVIDER_BACKEND -> false
            else -> settings.groqApiKey.isNotBlank()
        }

        val rawRes = if (useGroq) {
            groqManager.generateText(plannerSystemPrompt, plannerUserPrompt, maxTokens = 450, temperature = 0.1)
        } else if (settings.geminiApiKey.isNotBlank()) {
            geminiClient.generateDirectText(plannerSystemPrompt, plannerUserPrompt)
        } else {
            return null
        }

        val jsonText = rawRes.getOrNull()
            ?.trim()
            ?.removePrefix("```json")
            ?.removePrefix("```")
            ?.removeSuffix("```")
            ?.trim()
            ?: return null

        return try {
            val obj = gson.fromJson(jsonText, JsonObject::class.java)
            val summary = obj.get("intentSummary")?.asString ?: command
            val targetApp = obj.get("targetApp")?.asString ?: "Android"
            val arr = obj.getAsJsonArray("steps") ?: return null
            val steps = arr.mapNotNull { el ->
                val stepObj = el.asJsonObject
                val typeStr = stepObj.get("type")?.asString ?: return@mapNotNull null
                val type = runCatching { ActionType.valueOf(typeStr) }.getOrNull() ?: return@mapNotNull null
                ActionStep(
                    type = type,
                    target = stepObj.get("target")?.asString.orEmpty(),
                    query = stepObj.get("query")?.asString.orEmpty(),
                    text = stepObj.get("text")?.asString.orEmpty(),
                    autoPlay = stepObj.get("autoPlay")?.asBoolean ?: true,
                    requireConfirmation = type == ActionType.YOUTUBE_SUBSCRIBE,
                    description = summary
                )
            }
            if (steps.isEmpty()) null else ActionPlan(
                intentSummary = summary,
                targetApp = targetApp,
                steps = steps,
                isPureConversation = steps.size == 1 && steps.first().type == ActionType.CONVERSATION
            )
        } catch (e: Exception) {
            Log.w(tag, "AI plan JSON parse failed, falling back to conversation: ${e.message}")
            null
        }
    }
}
