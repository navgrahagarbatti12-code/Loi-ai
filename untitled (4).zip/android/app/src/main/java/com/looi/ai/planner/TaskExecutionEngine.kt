package com.looi.ai.planner

import android.content.Context
import com.looi.ai.accessibility.LooiAccessibilityService
import com.looi.ai.ai.gemini.GeminiLiveClient
import com.looi.ai.ai.groq.GroqManager
import com.looi.ai.automation.AppLauncherHelper
import com.looi.ai.automation.HtmlEditorAutomationEngine
import com.looi.ai.automation.YouTubeAutomationEngine
import com.looi.ai.memory.MemoryRepository
import com.looi.ai.settings.SettingsManager
import com.looi.ai.vision.ScreenIntelligenceEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

data class AssistantTaskState(
    val isExecuting: Boolean = false,
    val currentCommand: String = "",
    val currentStep: String = "",
    val awaitingSubscribeConfirmation: Boolean = false,
    val lastOutcome: String = ""
)

data class TaskExecutionResult(
    val spokenReply: String,
    val succeeded: Boolean,
    val isConversation: Boolean = false,
    val wasCancelled: Boolean = false,
    val errorDetail: String? = null
)

/**
 * Coordinates safe step-by-step execution, screen verification, retry/recovery,
 * immediate cancellation ("LOOI, ruk jao"), and Room ActionHistory logging.
 */
class TaskExecutionEngine(
    private val context: Context,
    private val settings: SettingsManager,
    private val memoryRepository: MemoryRepository,
    private val groqManager: GroqManager,
    private val geminiClient: GeminiLiveClient,
    private val actionPlanner: ActionPlanner,
    private val youTubeEngine: YouTubeAutomationEngine,
    private val htmlEditorEngine: HtmlEditorAutomationEngine,
    private val screenIntelligenceEngine: ScreenIntelligenceEngine
) {
    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var activeJob: Job? = null

    @Volatile
    private var cancelledRequested = false

    private val _taskState = MutableStateFlow(AssistantTaskState())
    val taskState: StateFlow<AssistantTaskState> = _taskState.asStateFlow()

    fun cancelCurrentTask(reason: String = "User ne automation stop karne ko kaha.") {
        cancelledRequested = true
        activeJob?.cancel(CancellationException(reason))
        activeJob = null
        _taskState.value = _taskState.value.copy(
            isExecuting = false,
            currentStep = "Cancelled",
            awaitingSubscribeConfirmation = false,
            lastOutcome = reason
        )
    }

    suspend fun handleVoiceCommand(
        command: String,
        detectedEmotion: String = "CURIOUS",
        detectedObjects: List<String> = emptyList()
    ): TaskExecutionResult {
        val cleanCmd = command.trim()
        if (cleanCmd.isBlank()) {
            return TaskExecutionResult("Kuch sunai nahi diya, dubara bolo.", succeeded = false)
        }

        // Fast interrupt check before even starting
        val lower = cleanCmd.lowercase()
        if (lower.contains("ruk jao") || lower == "stop" || lower == "cancel" || lower.contains("band karo")) {
            cancelCurrentTask("Okay, maine current task rok diya hai.")
            if (settings.saveHistoryEnabled) {
                memoryRepository.recordActionExecution(
                    commandText = cleanCmd,
                    targetApp = "LOOI",
                    planSummary = "Stop/Cancel active task",
                    status = "CANCELLED",
                    resultDetail = "Stopped by user voice command"
                )
            }
            return TaskExecutionResult(
                spokenReply = "Okay, maine kaam rok diya hai.",
                succeeded = true,
                wasCancelled = true
            )
        }

        cancelledRequested = false
        val historyContext = memoryRepository.getRecentContextSummary()
        val wasAwaitingSubscribe = _taskState.value.awaitingSubscribeConfirmation

        val plan = actionPlanner.createPlan(
            command = cleanCmd,
            historyContext = historyContext,
            hasPendingSubscribeConfirmation = wasAwaitingSubscribe
        )

        if (plan.isPureConversation || (plan.steps.size == 1 && plan.steps.first().type == ActionType.CONVERSATION)) {
            return executeConversation(cleanCmd, detectedEmotion, detectedObjects, historyContext)
        }

        _taskState.value = AssistantTaskState(
            isExecuting = true,
            currentCommand = cleanCmd,
            currentStep = plan.intentSummary,
            awaitingSubscribeConfirmation = false
        )

        var lastMessage = ""
        var allOk = true

        try {
            withContext(engineScope.coroutineContext) {
                activeJob = coroutineContext[Job]
                for ((index, step) in plan.steps.withIndex()) {
                    ensureActive()
                    if (cancelledRequested) {
                        throw CancellationException("Stopped by user")
                    }

                    _taskState.value = _taskState.value.copy(
                        currentStep = "Step ${index + 1}/${plan.steps.size}: ${step.description.ifBlank { step.type.name }}"
                    )

                    val stepResult = executeSingleStep(step, cleanCmd)
                    lastMessage = stepResult.spokenReply
                    if (!stepResult.succeeded) {
                        allOk = false
                        break
                    }

                    // Short pause between multi-step actions so target UI settles
                    if (index < plan.steps.lastIndex) {
                        delay(700)
                    }
                }
            }

            if (settings.saveHistoryEnabled) {
                memoryRepository.recordActionExecution(
                    commandText = cleanCmd,
                    targetApp = plan.targetApp,
                    planSummary = plan.intentSummary,
                    status = if (allOk) "COMPLETED" else "FAILED",
                    resultDetail = lastMessage
                )
            }

            _taskState.value = _taskState.value.copy(
                isExecuting = false,
                currentStep = if (allOk) "Done" else "Issue",
                lastOutcome = lastMessage
            )

            return TaskExecutionResult(
                spokenReply = lastMessage,
                succeeded = allOk,
                errorDetail = if (allOk) null else lastMessage
            )
        } catch (ce: CancellationException) {
            if (settings.saveHistoryEnabled) {
                memoryRepository.recordActionExecution(
                    commandText = cleanCmd,
                    targetApp = plan.targetApp,
                    planSummary = plan.intentSummary,
                    status = "CANCELLED",
                    resultDetail = "Task cancelled mid-execution"
                )
            }
            _taskState.value = _taskState.value.copy(
                isExecuting = false,
                currentStep = "Cancelled",
                lastOutcome = "Task cancelled"
            )
            return TaskExecutionResult(
                spokenReply = "Okay, task cancel kar diya.",
                succeeded = true,
                wasCancelled = true
            )
        } finally {
            activeJob = null
        }
    }

    private suspend fun executeSingleStep(step: ActionStep, originalCommand: String): TaskExecutionResult {
        coroutineContext.ensureActive()
        return when (step.type) {
            ActionType.CANCEL_TASK -> {
                cancelCurrentTask()
                TaskExecutionResult("Okay, kaam rok diya.", succeeded = true, wasCancelled = true)
            }

            ActionType.OPEN_APP -> {
                val res = AppLauncherHelper.launchApp(context, step.target, memoryRepository)
                res.fold(
                    onSuccess = { app ->
                        TaskExecutionResult("Okay, ${app.label} open kar rahi hoon.", succeeded = true)
                    },
                    onFailure = { err ->
                        TaskExecutionResult(err.localizedMessage ?: "${step.target} open nahi ho paya.", succeeded = false)
                    }
                )
            }

            ActionType.YOUTUBE_OPEN -> {
                val res = youTubeEngine.openYouTube()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_SEARCH_PLAY -> {
                val res = youTubeEngine.searchYouTube(step.query, autoPlayFirstResult = step.autoPlay)
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_PAUSE -> {
                val res = youTubeEngine.pauseVideo()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_RESUME -> {
                val res = youTubeEngine.resumeVideo()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_NEXT -> {
                val res = youTubeEngine.nextVideo()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_PREVIOUS -> {
                val res = youTubeEngine.previousVideo()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_SCROLL_DOWN -> {
                val res = youTubeEngine.scrollRecommendations(down = true)
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_SCROLL_UP -> {
                val res = youTubeEngine.scrollRecommendations(down = false)
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_OPEN_CHANNEL -> {
                val res = youTubeEngine.openVisibleChannel()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_SUBSCRIBE -> {
                val res = youTubeEngine.subscribeWithUserConfirmation(confirmedByUser = !step.requireConfirmation)
                if (!res.success && step.requireConfirmation) {
                    _taskState.value = _taskState.value.copy(awaitingSubscribeConfirmation = true)
                }
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.YOUTUBE_READ_SCREEN -> {
                val res = youTubeEngine.readVisibleVideoTitlesAndDescription()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.SCREEN_EXPLAIN -> {
                val res = screenIntelligenceEngine.explainCurrentScreen(step.query.ifBlank { originalCommand })
                res.fold(
                    onSuccess = { TaskExecutionResult(it.explanation, succeeded = true) },
                    onFailure = { TaskExecutionResult(it.localizedMessage ?: "Screen read nahi ho payi.", succeeded = false) }
                )
            }

            ActionType.HTML_CREATE_RUN -> {
                val res = htmlEditorEngine.generateHtmlProjectAndRun(step.query.ifBlank { originalCommand })
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.HTML_MODIFY -> {
                val res = htmlEditorEngine.modifyCurrentEditorCode(step.query.ifBlank { originalCommand })
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.HTML_FIX_ERRORS -> {
                val res = htmlEditorEngine.fixCurrentEditorErrors()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.HTML_RUN -> {
                val res = htmlEditorEngine.runCurrentEditorProject()
                TaskExecutionResult(res.message, res.success)
            }

            ActionType.UI_CLICK -> {
                val svc = LooiAccessibilityService.instance
                    ?: return TaskExecutionResult("Screen tap karne ke liye Accessibility Service enable karo.", false)
                val ok = svc.clickByTextOrDescription(step.target)
                TaskExecutionResult(
                    if (ok) "'${step.target}' par tap kar diya." else "Screen par '${step.target}' button nahi mila.",
                    ok
                )
            }

            ActionType.UI_INPUT -> {
                val svc = LooiAccessibilityService.instance
                    ?: return TaskExecutionResult("Text type karne ke liye Accessibility Service enable karo.", false)
                val ok = svc.inputTextIntoField(step.text, step.target.ifBlank { null })
                TaskExecutionResult(
                    if (ok) "Text enter kar diya hai." else "Screen par koi editable text box nahi mila.",
                    ok
                )
            }

            ActionType.UI_SCROLL_DOWN -> {
                val ok = LooiAccessibilityService.instance?.scrollScreen(forward = true) == true
                TaskExecutionResult(
                    if (ok) "Niche scroll kar diya." else "Scroll karne ke liye Accessibility Service enable karo.",
                    ok
                )
            }

            ActionType.UI_SCROLL_UP -> {
                val ok = LooiAccessibilityService.instance?.scrollScreen(forward = false) == true
                TaskExecutionResult(
                    if (ok) "Upar scroll kar diya." else "Scroll karne ke liye Accessibility Service enable karo.",
                    ok
                )
            }

            ActionType.UI_SWIPE_LEFT -> {
                val ok = LooiAccessibilityService.instance?.swipeHorizontal(swipeLeft = true) == true
                TaskExecutionResult(
                    if (ok) "Left swipe kar diya." else "Swipe karne ke liye Accessibility Service enable karo.",
                    ok
                )
            }

            ActionType.UI_SWIPE_RIGHT -> {
                val ok = LooiAccessibilityService.instance?.swipeHorizontal(swipeLeft = false) == true
                TaskExecutionResult(
                    if (ok) "Right swipe kar diya." else "Swipe karne ke liye Accessibility Service enable karo.",
                    ok
                )
            }

            ActionType.UI_NAVIGATE_BACK -> {
                val ok = LooiAccessibilityService.instance?.navigateBack() == true
                TaskExecutionResult(
                    if (ok) "Back chali gayi." else "Back navigation ke liye Accessibility Service enable karo.",
                    ok
                )
            }

            ActionType.UI_NAVIGATE_HOME -> {
                val ok = LooiAccessibilityService.instance?.navigateHome() == true
                TaskExecutionResult(
                    if (ok) "Home screen par aa gayi." else "Home navigation ke liye Accessibility Service enable karo.",
                    ok
                )
            }

            ActionType.UI_OPEN_RECENTS -> {
                val ok = LooiAccessibilityService.instance?.openRecents() == true
                TaskExecutionResult(
                    if (ok) "Recent apps open kar diya." else "Recents open karne ke liye Accessibility Service enable karo.",
                    ok
                )
            }

            ActionType.CONVERSATION -> {
                executeConversation(step.query.ifBlank { originalCommand }, "CURIOUS", emptyList(), "")
            }
        }
    }

    private suspend fun executeConversation(
        query: String,
        detectedEmotion: String,
        detectedObjects: List<String>,
        historyContext: String
    ): TaskExecutionResult {
        val useGroq = when (settings.aiProvider) {
            SettingsManager.PROVIDER_GROQ -> true
            SettingsManager.PROVIDER_GEMINI_DIRECT, SettingsManager.PROVIDER_BACKEND -> false
            else -> settings.groqApiKey.isNotBlank()
        }

        val result = if (useGroq) {
            groqManager.chatCompletion(
                userMessage = query,
                detectedEmotion = detectedEmotion,
                detectedObjects = detectedObjects,
                historyContext = historyContext
            )
        } else {
            geminiClient.sendConversationTurn(
                userMessage = query,
                detectedEmotion = detectedEmotion,
                detectedObjects = detectedObjects,
                historyContext = historyContext
            )
        }

        return result.fold(
            onSuccess = { reply ->
                TaskExecutionResult(spokenReply = reply, succeeded = true, isConversation = true)
            },
            onFailure = { err ->
                val detail = err.localizedMessage ?: "Network/API error. Check Settings."
                TaskExecutionResult(
                    spokenReply = detail,
                    succeeded = false,
                    isConversation = true,
                    errorDetail = detail
                )
            }
        )
    }
}
