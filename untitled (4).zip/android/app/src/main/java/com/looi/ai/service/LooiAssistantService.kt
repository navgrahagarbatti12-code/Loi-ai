package com.looi.ai.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.looi.ai.LooiApplication
import com.looi.ai.audio.VoiceSessionListener
import com.looi.ai.audio.VoiceSessionManager
import com.looi.ai.settings.SettingsManager
import com.looi.ai.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Background Voice & Wake-Word Assistant Foreground Service.
 * Keeps LOOI AI responsive across other apps (YouTube, HTML Editor, Browser) with a visible
 * persistent notification, Stop/Pause/Resume controls, and clean microphone handoff with MainActivity.
 */
class LooiAssistantService : Service(), VoiceSessionListener {

    private val tag = "LooiAssistantService"
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var settings: SettingsManager
    private lateinit var voiceManager: VoiceSessionManager

    @Volatile
    private var isPaused = false

    @Volatile
    private var awaitingFollowUpCommand = false

    @Volatile
    private var isProcessingCommand = false

    private val restartListenerRunnable = Runnable {
        if (!isPaused && !isForegroundUiActive && !isProcessingCommand && settings.wakeWordEnabled) {
            voiceManager.startListening(interruptSpeaking = false)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        settings = LooiApplication.instance.settingsManager
        voiceManager = VoiceSessionManager(this, settings, this)
        createNotificationChannel()
        _isServiceRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                settings.wakeWordEnabled = false
                stopSelfSafely()
                return START_NOT_STICKY
            }

            ACTION_PAUSE_WAKE -> {
                isPaused = true
                awaitingFollowUpCommand = false
                mainHandler.removeCallbacks(restartListenerRunnable)
                voiceManager.stopListening()
                voiceManager.stopSpeaking()
                updateNotification("LOOI Assistant Paused (Tap Resume)")
                _serviceStatusText.value = "Paused"
                return START_STICKY
            }

            ACTION_RESUME_WAKE -> {
                isPaused = false
                if (!startForegroundSafe()) {
                    stopSelfSafely()
                    return START_NOT_STICKY
                }
                scheduleWakeListening(250L)
                updateNotification("Wake word active: \"${settings.wakeWordPhrase}\"")
                _serviceStatusText.value = "Listening for \"${settings.wakeWordPhrase}\""
                return START_STICKY
            }

            ACTION_STOP_TASK -> {
                LooiApplication.instance.taskExecutionEngine.cancelCurrentTask()
                voiceManager.stopSpeaking()
                updateNotification("Automation stopped")
                _serviceStatusText.value = "Stopped task"
                return START_STICKY
            }
        }

        if (!startForegroundSafe()) {
            Log.w(tag, "Cannot start microphone foreground service without RECORD_AUDIO permission.")
            stopSelfSafely()
            return START_NOT_STICKY
        }

        if (!isPaused && !isForegroundUiActive && settings.wakeWordEnabled) {
            scheduleWakeListening(350L)
            _serviceStatusText.value = "Wake word active"
        } else if (isForegroundUiActive) {
            _serviceStatusText.value = "Handed mic to main screen"
        }

        return START_STICKY
    }

    private fun startForegroundSafe(): Boolean {
        val hasAudio = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasAudio) return false

        val notification = buildNotification(
            if (isPaused) "LOOI Assistant Paused" else "Say \"${settings.wakeWordPhrase}\" anytime"
        )
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (e: Exception) {
            Log.e(tag, "startForeground failed: ${e.message}", e)
            false
        }
    }

    fun onForegroundUiStateChanged(inForeground: Boolean) {
        mainHandler.removeCallbacks(restartListenerRunnable)
        if (inForeground) {
            voiceManager.stopListening()
            _serviceStatusText.value = "Foreground UI Active"
            updateNotification("LOOI active on main screen")
        } else if (!isPaused && settings.wakeWordEnabled) {
            scheduleWakeListening(500L)
            updateNotification("Wake word active: \"${settings.wakeWordPhrase}\"")
        }
    }

    private fun scheduleWakeListening(delayMs: Long) {
        mainHandler.removeCallbacks(restartListenerRunnable)
        mainHandler.postDelayed(restartListenerRunnable, delayMs)
    }

    // VoiceSessionListener implementation
    override fun onListeningStarted() {
        _serviceStatusText.value = if (awaitingFollowUpCommand) {
            "Listening for command…"
        } else {
            "Wake word active"
        }
    }

    override fun onMicRmsChanged(normalizedAmplitude: Float) {}

    override fun onPartialSpeech(text: String) {}

    override fun onSpeechEnded() {}

    override fun onSpeechResult(spokenText: String) {
        if (isPaused || isForegroundUiActive) return

        val clean = spokenText.trim()
        if (clean.isBlank()) {
            scheduleWakeListening(400L)
            return
        }

        val wakePhrase = settings.wakeWordPhrase.lowercase()
        val lower = clean.lowercase()
        val containsWakeWord = lower.contains(wakePhrase) ||
            lower.contains("hey looi") ||
            lower.contains("he looi") ||
            lower.contains("looi")

        if (!awaitingFollowUpCommand && !containsWakeWord) {
            // Ignore background chatter that doesn't mention LOOI
            scheduleWakeListening(350L)
            return
        }

        val commandText = if (awaitingFollowUpCommand) {
            awaitingFollowUpCommand = false
            clean
        } else {
            extractCommandAfterWakeWord(clean, wakePhrase)
        }

        if (commandText.isBlank()) {
            awaitingFollowUpCommand = true
            updateNotification("Haan bolo! Sun rahi hoon…")
            voiceManager.speak("Haan bolo!") {
                if (!isPaused && !isForegroundUiActive) {
                    scheduleWakeListening(200L)
                }
            }
            return
        }

        executeBackgroundCommand(commandText)
    }

    override fun onListeningError(errorCode: Int, message: String) {
        if (isPaused || isForegroundUiActive || isProcessingCommand || !settings.wakeWordEnabled) return
        val delayMs = when (errorCode) {
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1200L
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                isPaused = true
                updateNotification("Mic permission needed for background wake word")
                return
            }
            else -> 650L
        }
        scheduleWakeListening(delayMs)
    }

    override fun onSpeakingStarted(audioSessionId: Int) {}

    override fun onSpeakingFinished() {}

    private fun extractCommandAfterWakeWord(fullText: String, configuredWake: String): String {
        val patterns = listOf(configuredWake, "hey looi", "he looi", "hi looi", "looi")
        var result = fullText
        for (p in patterns) {
            val idx = result.lowercase().indexOf(p)
            if (idx >= 0) {
                result = result.substring(idx + p.length).trim(' ', ',', '.', '!', '?')
                break
            }
        }
        return result
    }

    private fun executeBackgroundCommand(commandText: String) {
        isProcessingCommand = true
        updateNotification("Executing: $commandText")
        _serviceStatusText.value = "Running: $commandText"

        serviceScope.launch {
            val repo = LooiApplication.instance.memoryRepository
            if (settings.saveHistoryEnabled) {
                repo.recordUserMessage(commandText, "BACKGROUND")
            }

            val result = LooiApplication.instance.taskExecutionEngine.handleVoiceCommand(
                command = commandText
            )

            if (settings.saveHistoryEnabled && result.spokenReply.isNotBlank()) {
                repo.recordLooiResponse(result.spokenReply)
            }

            isProcessingCommand = false
            updateNotification("Wake word active: \"${settings.wakeWordPhrase}\"")

            voiceManager.speak(result.spokenReply) {
                if (!isPaused && !isForegroundUiActive && settings.wakeWordEnabled) {
                    scheduleWakeListening(300L)
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "LOOI AI Background Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent controls for LOOI wake-word & hands-free mobile assistant"
                setSound(null, null)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(contentText: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(contentText))
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            10,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleActionIntent = PendingIntent.getService(
            this,
            11,
            Intent(this, LooiAssistantService::class.java).apply {
                action = if (isPaused) ACTION_RESUME_WAKE else ACTION_PAUSE_WAKE
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopTaskIntent = PendingIntent.getService(
            this,
            12,
            Intent(this, LooiAssistantService::class.java).apply {
                action = ACTION_STOP_TASK
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopServiceIntent = PendingIntent.getService(
            this,
            13,
            Intent(this, LooiAssistantService::class.java).apply {
                action = ACTION_STOP_SERVICE
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("LOOI AI Personal Assistant")
            .setContentText(contentText)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openIntent)
            .addAction(
                0,
                if (isPaused) "Resume" else "Pause",
                toggleActionIntent
            )
            .addAction(0, "Stop Task", stopTaskIntent)
            .addAction(0, "Turn Off", stopServiceIntent)
            .build()
    }

    private fun stopSelfSafely() {
        mainHandler.removeCallbacks(restartListenerRunnable)
        voiceManager.stopListening()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
        mainHandler.removeCallbacks(restartListenerRunnable)
        voiceManager.release()
        serviceScope.cancel()
        _isServiceRunning.value = false
        _serviceStatusText.value = "Off"
    }

    companion object {
        private const val CHANNEL_ID = "looi_assistant_channel"
        private const val NOTIFICATION_ID = 4001

        const val ACTION_START = "com.looi.ai.action.START_ASSISTANT"
        const val ACTION_STOP_SERVICE = "com.looi.ai.action.STOP_SERVICE"
        const val ACTION_PAUSE_WAKE = "com.looi.ai.action.PAUSE_WAKE"
        const val ACTION_RESUME_WAKE = "com.looi.ai.action.RESUME_WAKE"
        const val ACTION_STOP_TASK = "com.looi.ai.action.STOP_TASK"

        @Volatile
        var instance: LooiAssistantService? = null
            private set

        @Volatile
        private var isForegroundUiActive = false

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        private val _serviceStatusText = MutableStateFlow("Off")
        val serviceStatusText: StateFlow<String> = _serviceStatusText.asStateFlow()

        fun setForegroundUiActive(active: Boolean) {
            isForegroundUiActive = active
            instance?.onForegroundUiStateChanged(active)
        }

        fun startOrUpdate(context: Context) {
            val hasAudio = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasAudio) return

            val intent = Intent(context, LooiAssistantService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, LooiAssistantService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
