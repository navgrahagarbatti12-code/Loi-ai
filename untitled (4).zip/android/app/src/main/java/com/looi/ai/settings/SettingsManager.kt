package com.looi.ai.settings

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Persistent configuration manager for LOOI AI.
 * Stores sensitive API keys strictly inside Android Keystore-backed EncryptedSharedPreferences.
 * Never silently falls back to plain-text SharedPreferences for secrets.
 */
class SettingsManager(context: Context) {

    private val appContext = context.applicationContext

    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var secureStorageErrorMessage: String? = null
        private set

    private val encryptedPrefs: SharedPreferences? by lazy {
        initEncryptedPrefs(appContext)
    }

    private fun initEncryptedPrefs(context: Context): SharedPreferences? {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            val secure = EncryptedSharedPreferences.create(
                context,
                SECURE_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            secureStorageErrorMessage = null
            // Wipe any legacy plain-text keys if they ever existed in older builds
            if (prefs.contains(KEY_GROQ_API_KEY) || prefs.contains(KEY_GEMINI_API_KEY)) {
                val legacyGroq = prefs.getString(KEY_GROQ_API_KEY, null)?.trim()
                val legacyGemini = prefs.getString(KEY_GEMINI_API_KEY, null)?.trim()
                val editor = secure.edit()
                if (!legacyGroq.isNullOrEmpty() && secure.getString(KEY_GROQ_API_KEY, null).isNullOrEmpty()) {
                    editor.putString(KEY_GROQ_API_KEY, legacyGroq)
                }
                if (!legacyGemini.isNullOrEmpty() && secure.getString(KEY_GEMINI_API_KEY, null).isNullOrEmpty()) {
                    editor.putString(KEY_GEMINI_API_KEY, legacyGemini)
                }
                editor.apply()
                prefs.edit().remove(KEY_GROQ_API_KEY).remove(KEY_GEMINI_API_KEY).apply()
            }
            secure
        } catch (e: Exception) {
            secureStorageErrorMessage =
                "Android Keystore encrypted storage is unavailable on this device (${e.localizedMessage ?: e.javaClass.simpleName}). Use the secure HTTPS Companion Backend Proxy instead."
            Log.e(TAG, secureStorageErrorMessage!!, e)
            // Also wipe any legacy plain-text keys so secrets are never left unencrypted
            prefs.edit().remove(KEY_GROQ_API_KEY).remove(KEY_GEMINI_API_KEY).apply()
            null
        }
    }

    fun isSecureStorageAvailable(): Boolean = encryptedPrefs != null

    var aiProvider: String
        get() = prefs.getString(KEY_AI_PROVIDER, PROVIDER_AUTO) ?: PROVIDER_AUTO
        set(value) = prefs.edit().putString(KEY_AI_PROVIDER, value).apply()

    var groqApiKey: String
        get() = encryptedPrefs?.getString(KEY_GROQ_API_KEY, null)?.trim().orEmpty()
        set(value) {
            val secure = encryptedPrefs
                ?: throw IllegalStateException(
                    secureStorageErrorMessage ?: "Secure Keystore storage is unavailable; cannot save API key in plain text."
                )
            val trimmed = value.trim()
            if (trimmed.isEmpty()) {
                secure.edit().remove(KEY_GROQ_API_KEY).apply()
            } else {
                secure.edit().putString(KEY_GROQ_API_KEY, trimmed).apply()
            }
        }

    var geminiApiKey: String
        get() = encryptedPrefs?.getString(KEY_GEMINI_API_KEY, null)?.trim().orEmpty()
        set(value) {
            val secure = encryptedPrefs
                ?: throw IllegalStateException(
                    secureStorageErrorMessage ?: "Secure Keystore storage is unavailable; cannot save API key in plain text."
                )
            val trimmed = value.trim()
            if (trimmed.isEmpty()) {
                secure.edit().remove(KEY_GEMINI_API_KEY).apply()
            } else {
                secure.edit().putString(KEY_GEMINI_API_KEY, trimmed).apply()
            }
        }

    var groqModel: String
        get() = prefs.getString(KEY_GROQ_MODEL, DEFAULT_GROQ_MODEL) ?: DEFAULT_GROQ_MODEL
        set(value) = prefs.edit().putString(KEY_GROQ_MODEL, value).apply()

    var geminiModel: String
        get() = prefs.getString(KEY_GEMINI_MODEL, DEFAULT_GEMINI_MODEL) ?: DEFAULT_GEMINI_MODEL
        set(value) = prefs.edit().putString(KEY_GEMINI_MODEL, value).apply()

    var backendUrl: String
        get() = prefs.getString(KEY_BACKEND_URL, DEFAULT_BACKEND_URL)?.trim()?.trimEnd('/') ?: DEFAULT_BACKEND_URL
        set(value) = prefs.edit().putString(KEY_BACKEND_URL, value.trim().trimEnd('/')).apply()

    fun isBackendUrlAllowedBySecurityPolicy(url: String): Boolean {
        val normalized = url.trim().lowercase()
        if (normalized.startsWith("https://")) return true
        return normalized.startsWith("http://10.0.2.2") ||
            normalized.startsWith("http://localhost") ||
            normalized.startsWith("http://127.0.0.1")
    }

    var languageCode: String
        get() = prefs.getString(KEY_LANGUAGE_CODE, "hi-IN") ?: "hi-IN"
        set(value) = prefs.edit().putString(KEY_LANGUAGE_CODE, value).apply()

    var voiceName: String
        get() = prefs.getString(KEY_VOICE_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_VOICE_NAME, value).apply()

    var preferFemaleVoice: Boolean
        get() = prefs.getBoolean(KEY_PREFER_FEMALE_VOICE, true)
        set(value) = prefs.edit().putBoolean(KEY_PREFER_FEMALE_VOICE, value).apply()

    var continuousVoiceEnabled: Boolean
        get() = prefs.getBoolean(KEY_CONTINUOUS_VOICE, true)
        set(value) = prefs.edit().putBoolean(KEY_CONTINUOUS_VOICE, value).apply()

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean(KEY_WAKE_WORD_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_WAKE_WORD_ENABLED, value).apply()

    var wakeWordPhrase: String
        get() = prefs.getString(KEY_WAKE_WORD_PHRASE, "Hey LOOI")?.trim().orEmpty().ifBlank { "Hey LOOI" }
        set(value) = prefs.edit().putString(KEY_WAKE_WORD_PHRASE, value.trim().ifBlank { "Hey LOOI" }).apply()

    var screenCaptureConsentGranted: Boolean
        get() = prefs.getBoolean(KEY_SCREEN_CAPTURE_CONSENT, false)
        set(value) = prefs.edit().putBoolean(KEY_SCREEN_CAPTURE_CONSENT, value).apply()

    var preferredHtmlEditorPackage: String
        get() = prefs.getString(KEY_HTML_EDITOR_PKG, "") ?: ""
        set(value) = prefs.edit().putString(KEY_HTML_EDITOR_PKG, value.trim()).apply()

    var speechSpeed: Float
        get() = prefs.getFloat(KEY_SPEECH_SPEED, 1.05f).coerceIn(0.5f, 2.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_SPEED, value.coerceIn(0.5f, 2.0f)).apply()

    var speechPitch: Float
        get() = prefs.getFloat(KEY_SPEECH_PITCH, 1.15f).coerceIn(0.6f, 1.8f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_PITCH, value.coerceIn(0.6f, 1.8f)).apply()

    var eyeAnimationSpeed: Float
        get() = prefs.getFloat(KEY_EYE_ANIM_SPEED, 1.0f).coerceIn(0.4f, 2.0f)
        set(value) = prefs.edit().putFloat(KEY_EYE_ANIM_SPEED, value.coerceIn(0.4f, 2.0f)).apply()

    var cameraEnabled: Boolean
        get() = prefs.getBoolean(KEY_CAMERA_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_CAMERA_ENABLED, value).apply()

    var mirrorCamera: Boolean
        get() = prefs.getBoolean(KEY_MIRROR_CAMERA, true)
        set(value) = prefs.edit().putBoolean(KEY_MIRROR_CAMERA, value).apply()

    var objectDetectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_OBJECT_DETECTION, true)
        set(value) = prefs.edit().putBoolean(KEY_OBJECT_DETECTION, value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, value).apply()

    var saveHistoryEnabled: Boolean
        get() = prefs.getBoolean(KEY_SAVE_HISTORY, true)
        set(value) = prefs.edit().putBoolean(KEY_SAVE_HISTORY, value).apply()

    companion object {
        private const val TAG = "SettingsManager"
        private const val PREFS_NAME = "looi_ai_settings"
        private const val SECURE_PREFS_NAME = "looi_ai_secrets"
        private const val KEY_AI_PROVIDER = "ai_provider"
        private const val KEY_GROQ_API_KEY = "groq_api_key"
        private const val KEY_GEMINI_API_KEY = "gemini_api_key"
        private const val KEY_GROQ_MODEL = "groq_model"
        private const val KEY_GEMINI_MODEL = "gemini_model"
        private const val KEY_BACKEND_URL = "backend_url"
        private const val KEY_LANGUAGE_CODE = "language_code"
        private const val KEY_VOICE_NAME = "voice_name"
        private const val KEY_PREFER_FEMALE_VOICE = "prefer_female_voice"
        private const val KEY_CONTINUOUS_VOICE = "continuous_voice"
        private const val KEY_WAKE_WORD_ENABLED = "wake_word_enabled"
        private const val KEY_WAKE_WORD_PHRASE = "wake_word_phrase"
        private const val KEY_SCREEN_CAPTURE_CONSENT = "screen_capture_consent"
        private const val KEY_HTML_EDITOR_PKG = "html_editor_pkg"
        private const val KEY_SPEECH_SPEED = "speech_speed"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
        private const val KEY_EYE_ANIM_SPEED = "eye_anim_speed"
        private const val KEY_CAMERA_ENABLED = "camera_enabled"
        private const val KEY_MIRROR_CAMERA = "mirror_camera"
        private const val KEY_OBJECT_DETECTION = "object_detection"
        private const val KEY_SOUND_ENABLED = "sound_enabled"
        private const val KEY_SAVE_HISTORY = "save_history"

        const val PROVIDER_AUTO = "AUTO"
        const val PROVIDER_GROQ = "GROQ"
        const val PROVIDER_GEMINI_DIRECT = "GEMINI_DIRECT"
        const val PROVIDER_BACKEND = "BACKEND"

        const val DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile"
        const val DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
        const val DEFAULT_BACKEND_URL = "http://10.0.2.2:3000"
    }
}
