package com.looi.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.looi.ai.LooiApplication
import com.looi.ai.R
import com.looi.ai.databinding.ActivityActionHistoryBinding
import com.looi.ai.memory.database.ActionHistoryEntity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ActionHistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityActionHistoryBinding
    private val adapter = ActionAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityActionHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbarActionHistory)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbarActionHistory.setNavigationOnClickListener { finish() }

        binding.rvActionHistory.adapter = adapter

        lifecycleScope.launch {
            LooiApplication.instance.memoryRepository.allActionHistory.collectLatest { items ->
                adapter.submitList(items)
                binding.tvEmptyActionHistory.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                binding.tvActionSummary.text = "${items.size} recorded automation tasks"
            }
        }

        binding.btnClearActionHistory.setOnClickListener {
            lifecycleScope.launch {
                LooiApplication.instance.memoryRepository.clearActionHistoryOnly()
                Toast.makeText(this@ActionHistoryActivity, "Action history cleared", Toast.LENGTH_SHORT).show()
            }
        }
    }

    class ActionAdapter : RecyclerView.Adapter<ActionViewHolder>() {
        private var items: List<ActionHistoryEntity> = emptyList()

        fun submitList(newItems: List<ActionHistoryEntity>) {
            items = newItems
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActionViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_action_history, parent, false)
            return ActionViewHolder(view)
        }

        override fun onBindViewHolder(holder: ActionViewHolder, position: Int) {
            val item = items[position]
            val ctx = holder.itemView.context
            holder.tvStatus.text = item.status
            val statusColor = when (item.status) {
                "COMPLETED" -> ContextCompat.getColor(ctx, R.color.looi_green)
                "CANCELLED" -> ContextCompat.getColor(ctx, R.color.looi_yellow)
                else -> ContextCompat.getColor(ctx, R.color.looi_red)
            }
            holder.tvStatus.setTextColor(statusColor)
            holder.tvTargetApp.text = item.targetApp
            holder.tvTime.text = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
                .format(Date(item.timestamp))
            holder.tvCommand.text = item.commandText
            holder.tvPlan.text = "Plan: ${item.planSummary}"
            holder.tvResult.text = item.resultDetail
        }

        override fun getItemCount(): Int = items.size
    }

    class ActionViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvStatus: TextView = view.findViewById(R.id.tvActionStatus)
        val tvTargetApp: TextView = view.findViewById(R.id.tvTargetApp)
        val tvTime: TextView = view.findViewById(R.id.tvActionTime)
        val tvCommand: TextView = view.findViewById(R.id.tvCommandText)
        val tvPlan: TextView = view.findViewById(R.id.tvPlanSummary)
        val tvResult: TextView = view.findViewById(R.id.tvResultDetail)
    }
}
