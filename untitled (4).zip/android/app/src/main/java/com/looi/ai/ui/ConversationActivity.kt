package com.looi.ai.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.looi.ai.LooiApplication
import com.looi.ai.R
import com.looi.ai.databinding.ActivityConversationBinding
import com.looi.ai.memory.database.ConversationEntity
import com.looi.ai.settings.SettingsManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ConversationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityConversationBinding
    private val adapter = MessageAdapter()
    private lateinit var settings: SettingsManager
    private var isSending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConversationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = LooiApplication.instance.settingsManager

        setSupportActionBar(binding.toolbarConversation)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbarConversation.setNavigationOnClickListener { finish() }

        binding.rvMessages.adapter = adapter

        lifecycleScope.launch {
            LooiApplication.instance.memoryRepository.allConversations.collectLatest { list ->
                adapter.submitList(list)
                if (list.isNotEmpty()) {
                    binding.rvMessages.smoothScrollToPosition(list.size - 1)
                }
            }
        }

        binding.chip1.setOnClickListener { sendMessage(binding.chip1.text.toString()) }
        binding.chip2.setOnClickListener { sendMessage(binding.chip2.text.toString()) }
        binding.chip3.setOnClickListener { sendMessage(binding.chip3.text.toString()) }

        binding.btnSend.setOnClickListener {
            val txt = binding.etMessage.text.toString().trim()
            if (txt.isNotBlank()) {
                sendMessage(txt)
                binding.etMessage.text?.clear()
            }
        }
    }

    private fun sendMessage(text: String) {
        if (isSending) return
        isSending = true
        binding.btnSend.isEnabled = false
        binding.toolbarConversation.subtitle = "LOOI is thinking…"

        lifecycleScope.launch {
            val app = LooiApplication.instance
            val repo = app.memoryRepository

            if (settings.saveHistoryEnabled) {
                repo.recordUserMessage(text)
            }

            val result = app.taskExecutionEngine.handleVoiceCommand(
                command = text,
                detectedEmotion = "CURIOUS",
                detectedObjects = emptyList()
            )

            if (result.succeeded) {
                if (settings.saveHistoryEnabled && result.spokenReply.isNotBlank()) {
                    repo.recordLooiResponse(result.spokenReply)
                }
            } else {
                Toast.makeText(this@ConversationActivity, result.spokenReply, Toast.LENGTH_LONG).show()
                if (settings.saveHistoryEnabled) {
                    repo.recordLooiResponse("Error: ${result.spokenReply}")
                }
            }

            binding.toolbarConversation.subtitle = null
            binding.btnSend.isEnabled = true
            isSending = false
        }
    }

    class MessageAdapter : RecyclerView.Adapter<MessageViewHolder>() {
        private var items: List<ConversationEntity> = emptyList()

        fun submitList(newItems: List<ConversationEntity>) {
            items = newItems
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_message, parent, false)
            return MessageViewHolder(view)
        }

        override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
            val item = items[position]
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(item.timestamp))
            val isLooi = item.sender == "LOOI"

            holder.tvSender.text = if (isLooi) "LOOI AI" else "YOU"
            holder.tvSender.setTextColor(if (isLooi) 0xFF00F2FE.toInt() else 0xFF38BDF8.toInt())
            holder.tvTimestamp.text = time
            holder.tvMessageBody.text = item.messageText

            val params = holder.container.layoutParams as ViewGroup.MarginLayoutParams
            if (isLooi) {
                params.marginStart = 0
                params.marginEnd = 48
            } else {
                params.marginStart = 48
                params.marginEnd = 0
            }
            holder.container.layoutParams = params
        }

        override fun getItemCount(): Int = items.size
    }

    class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val container: LinearLayout = view.findViewById(R.id.messageContainer)
        val tvSender: TextView = view.findViewById(R.id.tvSender)
        val tvTimestamp: TextView = view.findViewById(R.id.tvTimestamp)
        val tvMessageBody: TextView = view.findViewById(R.id.tvMessageBody)
    }
}
