package com.looi.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.objects.DetectedObject
import com.looi.ai.LooiApplication
import com.looi.ai.accessibility.LooiAccessibilityService
import com.looi.ai.audio.LipSyncController
import com.looi.ai.audio.VoiceSessionListener
import com.looi.ai.audio.VoiceSessionManager
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.camera.CameraXManager
import com.looi.ai.databinding.ActivityMainBinding
import com.looi.ai.service.LooiAssistantService
import com.looi.ai.settings.SettingsManager
import com.looi.ai.vision.CompositeVisionAnalyzer
import com.looi.ai.vision.FaceTrackingListener
import com.looi.ai.vision.ObjectDetectionListener
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Main LOOI AI Personal Assistant & Robot Companion Activity.
 * Integrates:
 * - Glowing expressive RobotFaceCanvasView + real-time LipSyncController
 * - CameraX front camera + simultaneous ML Kit Face & Object Tracking (safe ordered teardown)
 * - Two-way continuous Hindi/Hinglish/English VoiceSessionManager with barge-in interruption
 * - Unified TaskExecutionEngine (YouTube automation, HTML Editor automation, Screen reading, App launching)
 * - Clean mic handoff with LooiAssistantService foreground wake-word service
 */
class MainActivity : AppCompatActivity(),
    FaceTrackingListener,
    ObjectDetectionListener,
    VoiceSessionListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: SettingsManager
    private lateinit var lipSyncController: LipSyncController
    private lateinit var voiceSessionManager: VoiceSessionManager

    private var cameraXManager: CameraXManager? = null
    private var visionAnalyzer: CompositeVisionAnalyzer? = null

    private var currentEmotion = RobotEmotion.HAPPY
    private val detectedObjectsList = mutableListOf<String>()
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var lastTurnWasConversation = false

    @Volatile
    private var userManuallyStoppedListening = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.containsKey(Manifest.permission.CAMERA)) {
            val cameraGranted = permissions[Manifest.permission.CAMERA] == true
            if (cameraGranted && settings.cameraEnabled) {
                setupCamera()
            } else if (!cameraGranted) {
                cameraXManager?.stopCamera()
                binding.cameraPreviewCard.visibility = View.GONE
                binding.tvTrackingBadge.text = "CAMERA DENIED"
                Toast.makeText(
                    this,
                    "Camera permission denied. Enable it in Android Settings for face & object tracking.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        if (permissions.containsKey(Manifest.permission.RECORD_AUDIO)) {
            val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
            if (audioGranted) {
                voiceSessionManager.initSpeechRecognizer()
                if (settings.wakeWordEnabled) {
                    LooiAssistantService.startOrUpdate(this)
                }
            } else {
                Toast.makeText(
                    this,
                    "Microphone permission denied. Voice input requires microphone access.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = LooiApplication.instance.settingsManager
        lipSyncController = LipSyncController(this, binding.robotFaceView, lifecycleScope)
        voiceSessionManager = VoiceSessionManager(this, settings, this)

        setupButtons()
        observeAssistantStates()
        applySettingsToRuntime()
        checkPermissionsAndStart()
    }

    override fun onResume() {
        super.onResume()
        // Hand microphone cleanly to foreground UI while MainActivity is visible
        LooiAssistantService.setForegroundUiActive(true)
        applySettingsToRuntime()
        updateAssistantStatusStrip()

        if (settings.cameraEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            cameraXManager?.isCameraRunning() != true
        ) {
            setupCamera()
        }
    }

    override fun onPause() {
        super.onPause()
        mainHandler.removeCallbacksAndMessages(null)
        voiceSessionManager.stopListening()
        voiceSessionManager.stopSpeaking()
        lipSyncController.onSpeakingFinished(currentEmotion)
        // Return microphone control to background wake-word service if enabled
        LooiAssistantService.setForegroundUiActive(false)
    }

    private fun observeAssistantStates() {
        val taskEngine = LooiApplication.instance.taskExecutionEngine
        lifecycleScope.launch {
            taskEngine.taskState.collectLatest { state ->
                binding.btnStopAutomation.visibility =
                    if (state.isExecuting || voiceSessionManager.isSpeaking) View.VISIBLE else View.GONE
                updateAssistantStatusStrip(state.currentStep.takeIf { state.isExecuting })
            }
        }
        lifecycleScope.launch {
            LooiAccessibilityService.isServiceConnected.collectLatest {
                updateAssistantStatusStrip()
            }
        }
        lifecycleScope.launch {
            LooiAccessibilityService.activeAppLabel.collectLatest {
                updateAssistantStatusStrip()
            }
        }
        lifecycleScope.launch {
            LooiAssistantService.isServiceRunning.collectLatest {
                updateAssistantStatusStrip()
            }
        }
    }

    private fun updateAssistantStatusStrip(activeStep: String? = null) {
        val bgRunning = LooiAssistantService.isServiceRunning.value
        val wakeEnabled = settings.wakeWordEnabled
        val a11yEnabled = LooiAccessibilityService.isAccessibilityEnabled(this)
        val appLabel = LooiAccessibilityService.activeAppLabel.value

        binding.btnWakeWordToggle.text = if (bgRunning || wakeEnabled) "BG Wake: ON" else "BG Wake: OFF"

        binding.tvAssistantStatus.text = if (!activeStep.isNullOrBlank()) {
            "Task: $activeStep"
        } else {
            "BG: ${if (bgRunning) "ON" else "OFF"} | A11y: ${if (a11yEnabled) "ON" else "OFF"} | $appLabel"
        }
    }

    private fun applySettingsToRuntime() {
        binding.robotFaceView.animationSpeedMultiplier = settings.eyeAnimationSpeed

        visionAnalyzer?.isObjectDetectionEnabled = settings.objectDetectionEnabled
        visionAnalyzer?.isFrontCameraMirrored = settings.mirrorCamera

        if (!settings.objectDetectionEnabled) {
            binding.tvDetectedObjects.visibility = View.GONE
        }

        if (!settings.cameraEnabled) {
            cameraXManager?.stopCamera()
            binding.cameraPreviewCard.visibility = View.GONE
            binding.tvDetectedObjects.visibility = View.GONE
        } else if (binding.cameraPreviewCard.visibility != View.VISIBLE &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        ) {
            binding.cameraPreviewCard.visibility = View.VISIBLE
        }

        if (voiceSessionManager.isTtsReady) {
            voiceSessionManager.applyTtsSettings()
        }

        if (settings.wakeWordEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            LooiAssistantService.startOrUpdate(this)
        }
    }

    private fun checkPermissionsAndStart() {
        val permissionsToRequest = mutableListOf<String>()
        if (settings.cameraEnabled &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            if (settings.cameraEnabled) {
                setupCamera()
            }
            voiceSessionManager.initSpeechRecognizer()
            if (settings.wakeWordEnabled) {
                LooiAssistantService.startOrUpdate(this)
            }
        }
    }

    private fun setupCamera() {
        if (!settings.cameraEnabled) return
        if (cameraXManager == null) {
            cameraXManager = CameraXManager(this, this, binding.cameraPreviewView)
        }
        if (visionAnalyzer == null) {
            visionAnalyzer = CompositeVisionAnalyzer(
                faceListener = this,
                objectListener = this,
                isObjectDetectionEnabled = settings.objectDetectionEnabled,
                isFrontCameraMirrored = settings.mirrorCamera
            )
        }

        val analyzer = visionAnalyzer ?: return
        binding.cameraPreviewCard.visibility = View.VISIBLE
        cameraXManager?.startCamera(analyzer) { error ->
            runOnUiThread {
                binding.cameraPreviewCard.visibility = View.GONE
                binding.tvTrackingBadge.text = "CAM ERROR"
                Toast.makeText(
                    this,
                    "Camera unavailable: ${error.localizedMessage ?: "Unknown error"}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun setupButtons() {
        binding.robotFaceView.setOnClickListener {
            if (binding.robotFaceView.currentEmotion == RobotEmotion.SLEEPING) {
                binding.robotFaceView.wakeUp()
                currentEmotion = RobotEmotion.HAPPY
                binding.tvEmotionStatus.text = "MOOD: HAPPY"
            } else {
                binding.robotFaceView.triggerBlink()
            }
        }

        binding.btnMic.setOnClickListener {
            if (voiceSessionManager.isListening) {
                userManuallyStoppedListening = true
                voiceSessionManager.stopListening()
                binding.robotFaceView.currentEmotion = currentEmotion
                binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
            } else {
                userManuallyStoppedListening = false
                startVoiceListeningWithBargeIn()
            }
        }

        binding.btnStopAutomation.setOnClickListener {
            userManuallyStoppedListening = true
            LooiApplication.instance.taskExecutionEngine.cancelCurrentTask()
            voiceSessionManager.stopSpeaking()
            voiceSessionManager.stopListening()
            lipSyncController.onSpeakingFinished(currentEmotion)
            binding.tvSubtitleSpeaker.text = "LOOI AI:"
            binding.tvSubtitleText.text = "Task aur voice output rok diya gaya hai."
        }

        binding.btnWakeWordToggle.setOnClickListener {
            val enable = !settings.wakeWordEnabled
            settings.wakeWordEnabled = enable
            if (enable) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                } else {
                    LooiAssistantService.startOrUpdate(this)
                    Toast.makeText(
                        this,
                        "Background Wake Word ON: Say \"${settings.wakeWordPhrase}\"",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                LooiAssistantService.stop(this)
                Toast.makeText(this, "Background Wake Word turned OFF", Toast.LENGTH_SHORT).show()
            }
            updateAssistantStatusStrip()
        }

        binding.btnActionHistory.setOnClickListener {
            startActivity(Intent(this, ActionHistoryActivity::class.java))
        }

        binding.btnChatHistory.setOnClickListener {
            startActivity(Intent(this, ConversationActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnToggleCamera.setOnClickListener {
            val enableCamera = !settings.cameraEnabled
            settings.cameraEnabled = enableCamera
            if (enableCamera) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    setupCamera()
                } else {
                    permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                }
            } else {
                cameraXManager?.stopCamera()
                detectedObjectsList.clear()
                binding.cameraPreviewCard.visibility = View.GONE
                binding.tvDetectedObjects.visibility = View.GONE
                binding.tvTrackingBadge.text = "CAMERA OFF"
                Toast.makeText(this, "Camera & tracking paused", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnScanObject.setOnClickListener {
            triggerObjectScan()
        }
    }

    private fun startVoiceListeningWithBargeIn() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        // Interrupt speaking immediately if LOOI is talking (barge-in)
        if (voiceSessionManager.isSpeaking) {
            voiceSessionManager.stopSpeaking()
            lipSyncController.onSpeakingFinished(currentEmotion)
        }
        voiceSessionManager.startListening(interruptSpeaking = true)
    }

    // VoiceSessionListener implementation
    override fun onListeningStarted() {
        binding.tvSubtitleSpeaker.text = "LOOI AI (Listening…)"
        binding.tvEmotionStatus.text = "STATE: LISTENING"
        binding.robotFaceView.currentEmotion = RobotEmotion.LISTENING
    }

    override fun onMicRmsChanged(normalizedAmplitude: Float) {
        binding.robotFaceView.mouthAmplitude = normalizedAmplitude
    }

    override fun onPartialSpeech(text: String) {
        binding.tvSubtitleText.text = text
    }

    override fun onSpeechEnded() {
        binding.robotFaceView.mouthAmplitude = 0f
        binding.tvEmotionStatus.text = "STATE: THINKING"
        binding.robotFaceView.currentEmotion = RobotEmotion.THINKING
    }

    override fun onSpeechResult(spokenText: String) {
        binding.robotFaceView.mouthAmplitude = 0f
        if (spokenText.isNotBlank()) {
            processUserQuery(spokenText)
        } else {
            binding.robotFaceView.currentEmotion = currentEmotion
            binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
        }
    }

    override fun onListeningError(errorCode: Int, message: String) {
        binding.robotFaceView.mouthAmplitude = 0f
        binding.robotFaceView.currentEmotion = currentEmotion
        binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
        if (errorCode != SpeechRecognizer.ERROR_NO_MATCH && errorCode != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            binding.tvSubtitleSpeaker.text = "LOOI AI"
            binding.tvSubtitleText.text = "$message Tap mic to retry."
        }
    }

    override fun onSpeakingStarted(audioSessionId: Int) {
        lipSyncController.onSpeakingStarted(audioSessionId)
        binding.tvEmotionStatus.text = "STATE: SPEAKING"
        binding.btnStopAutomation.visibility = View.VISIBLE
    }

    override fun onSpeakingFinished() {
        lipSyncController.onSpeakingFinished(currentEmotion)
        binding.tvEmotionStatus.text = "MOOD: ${currentEmotion.name}"
        val taskExecuting = LooiApplication.instance.taskExecutionEngine.taskState.value.isExecuting
        binding.btnStopAutomation.visibility = if (taskExecuting) View.VISIBLE else View.GONE
    }

    private fun processUserQuery(query: String) {
        lifecycleScope.launch {
            binding.tvSubtitleSpeaker.text = "You said:"
            binding.tvSubtitleText.text = query

            val app = LooiApplication.instance
            if (settings.saveHistoryEnabled) {
                app.memoryRepository.recordUserMessage(query, currentEmotion.name)
            }

            binding.tvEmotionStatus.text = "STATE: THINKING"
            binding.robotFaceView.currentEmotion = RobotEmotion.THINKING

            val result = app.taskExecutionEngine.handleVoiceCommand(
                command = query,
                detectedEmotion = currentEmotion.name,
                detectedObjects = detectedObjectsList.toList()
            )

            lastTurnWasConversation = result.isConversation

            if (result.succeeded) {
                if (settings.saveHistoryEnabled && result.spokenReply.isNotBlank()) {
                    app.memoryRepository.recordLooiResponse(result.spokenReply)
                }
                binding.tvSubtitleSpeaker.text = "LOOI AI:"
                binding.tvSubtitleText.text = result.spokenReply

                voiceSessionManager.speak(result.spokenReply) {
                    // Continue two-way conversation loop smoothly if enabled & staying inside LOOI
                    if (settings.continuousVoiceEnabled &&
                        lastTurnWasConversation &&
                        !result.wasCancelled &&
                        !userManuallyStoppedListening &&
                        hasWindowFocus()
                    ) {
                        mainHandler.postDelayed({
                            if (hasWindowFocus() && !voiceSessionManager.isListening && !voiceSessionManager.isSpeaking) {
                                startVoiceListeningWithBargeIn()
                            }
                        }, 300L)
                    }
                }
            } else {
                binding.robotFaceView.currentEmotion = RobotEmotion.SAD
                binding.tvEmotionStatus.text = "ISSUE / SETUP NEEDED"
                binding.tvSubtitleSpeaker.text = "LOOI AI:"
                binding.tvSubtitleText.text = result.spokenReply
                voiceSessionManager.speak(result.spokenReply)
            }
        }
    }

    private fun triggerObjectScan() {
        if (!settings.objectDetectionEnabled) {
            Toast.makeText(this, "Object detection is disabled in Settings", Toast.LENGTH_SHORT).show()
            return
        }

        binding.tvEmotionStatus.text = "SCANNING OBJECTS…"
        binding.robotFaceView.currentEmotion = RobotEmotion.CURIOUS

        lifecycleScope.launch {
            val dominant = detectedObjectsList.firstOrNull()
            if (dominant.isNullOrBlank()) {
                val msg = "Point the front camera at an object so I can identify it!"
                binding.tvSubtitleSpeaker.text = "LOOI Vision:"
                binding.tvSubtitleText.text = msg
                voiceSessionManager.speak(msg)
                return@launch
            }

            val groqResult = LooiApplication.instance.groqManager.describeDetectedObject(dominant)
            groqResult.onSuccess { description ->
                binding.tvSubtitleSpeaker.text = "LOOI Vision ($dominant):"
                binding.tvSubtitleText.text = description
                voiceSessionManager.speak(description)
            }.onFailure {
                val localSummary = "I detected: ${detectedObjectsList.joinToString(", ")}."
                binding.tvSubtitleSpeaker.text = "LOOI Vision:"
                binding.tvSubtitleText.text = localSummary
                voiceSessionManager.speak(localSummary)
            }
        }
    }

    // FaceTrackingListener implementation
    override fun onFaceTracked(lookX: Float, lookY: Float, emotion: RobotEmotion, face: Face) {
        runOnUiThread {
            binding.robotFaceView.setLookTarget(lookX, lookY)
            if (binding.robotFaceView.currentEmotion != RobotEmotion.TALKING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.LISTENING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.THINKING
            ) {
                currentEmotion = emotion
                binding.robotFaceView.currentEmotion = emotion
                binding.tvEmotionStatus.text = "MOOD: ${emotion.name}"
            }
            binding.tvTrackingBadge.text =
                String.format(Locale.US, "FACE (%.1f, %.1f)", lookX, lookY)
        }
    }

    override fun onFaceLost() {
        runOnUiThread {
            if (binding.robotFaceView.currentEmotion != RobotEmotion.TALKING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.LISTENING &&
                binding.robotFaceView.currentEmotion != RobotEmotion.THINKING
            ) {
                currentEmotion = RobotEmotion.SEARCHING
                binding.robotFaceView.currentEmotion = RobotEmotion.SEARCHING
                binding.tvEmotionStatus.text = "SEARCHING…"
                binding.tvTrackingBadge.text = "SEARCHING…"
            }
        }
    }

    // ObjectDetectionListener implementation
    override fun onObjectsDetected(objects: List<DetectedObject>, primaryLabel: String?) {
        runOnUiThread {
            if (!settings.objectDetectionEnabled || !settings.cameraEnabled) {
                detectedObjectsList.clear()
                binding.tvDetectedObjects.visibility = View.GONE
                return@runOnUiThread
            }

            val labels = objects.flatMap { it.labels }
                .filter { it.confidence > 0.45f }
                .sortedByDescending { it.confidence }
                .map { it.text }
                .distinct()

            if (labels.isNotEmpty()) {
                detectedObjectsList.clear()
                detectedObjectsList.addAll(labels.take(5))
                binding.tvDetectedObjects.visibility = View.VISIBLE
                binding.tvDetectedObjects.text = "Seeing: ${detectedObjectsList.joinToString(", ")}"
            } else if (!primaryLabel.isNullOrBlank()) {
                detectedObjectsList.clear()
                detectedObjectsList.add(primaryLabel)
                binding.tvDetectedObjects.visibility = View.VISIBLE
                binding.tvDetectedObjects.text = "Seeing: $primaryLabel"
            } else {
                detectedObjectsList.clear()
                binding.tvDetectedObjects.visibility = View.GONE
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        lipSyncController.release()
        voiceSessionManager.release()

        // Strictly stop CameraX and drain its executor BEFORE closing ML Kit detectors
        val analyzerToClose = visionAnalyzer
        visionAnalyzer = null
        val camMgr = cameraXManager
        cameraXManager = null
        if (camMgr != null) {
            camMgr.release {
                analyzerToClose?.close()
            }
        } else {
            analyzerToClose?.close()
        }
    }
}
