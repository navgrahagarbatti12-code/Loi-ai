package com.looi.ai.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.looi.ai.LooiApplication
import com.looi.ai.R
import com.looi.ai.accessibility.LooiAccessibilityService
import com.looi.ai.automation.AppLauncherHelper
import com.looi.ai.databinding.ActivitySettingsBinding
import com.looi.ai.service.LooiAssistantService
import com.looi.ai.settings.SettingsManager
import com.looi.ai.vision.ScreenCaptureManager
import kotlinx.coroutines.launch
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var settings: SettingsManager

    private var tts: TextToSpeech? = null
    private var availableVoices: List<Voice> = emptyList()
    private var htmlEditorPackages: List<String> = emptyList()

    private val providerCodes = listOf(
        SettingsManager.PROVIDER_AUTO,
        SettingsManager.PROVIDER_GROQ,
        SettingsManager.PROVIDER_GEMINI_DIRECT,
        SettingsManager.PROVIDER_BACKEND
    )
    private val providerLabels = listOf(
        "Auto (Groq if key set, else Gemini / Backend)",
        "Groq Direct API",
        "Gemini Direct API",
        "Companion HTTPS Backend Proxy"
    )

    private val groqModels = listOf(
        "llama-3.3-70b-versatile",
        "llama-3.1-8b-instant",
        "mixtral-8x7b-32768"
    )

    private val geminiModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-1.5-flash"
    )

    private val languageCodes = listOf("hi-IN", "en-IN", "en-US")
    private val languageLabels = listOf(
        "Hindi / Hinglish (hi-IN)",
        "English India (en-IN)",
        "English US (en-US)"
    )

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            ScreenCaptureManager.saveConsentResult(result.resultCode, result.data)
            settings.screenCaptureConsentGranted = true
            Toast.makeText(this, "Screen OCR capture consent granted!", Toast.LENGTH_SHORT).show()
        } else {
            ScreenCaptureManager.clearConsent()
            settings.screenCaptureConsentGranted = false
            Toast.makeText(this, "Screen capture consent not granted.", Toast.LENGTH_SHORT).show()
        }
        refreshPermissionStatuses()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = LooiApplication.instance.settingsManager

        setSupportActionBar(binding.toolbarSettings)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbarSettings.setNavigationOnClickListener { finish() }

        setupSpinners()
        setupSliders()
        setupPermissionButtons()
        loadSavedValues()
        initVoiceList()

        binding.btnSaveSettings.setOnClickListener {
            saveSettings()
        }

        binding.btnClearMemory.setOnClickListener {
            lifecycleScope.launch {
                LooiApplication.instance.memoryRepository.clearMemory()
                Toast.makeText(
                    this@SettingsActivity,
                    "LOOI conversation & action memory cleared",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatuses()
    }

    private fun setupSpinners() {
        binding.spinnerAiProvider.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            providerLabels
        )
        binding.spinnerGroqModel.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            groqModels
        )
        binding.spinnerGeminiModel.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            geminiModels
        )
        binding.spinnerLanguage.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            languageLabels
        )

        val editorCandidates = AppLauncherHelper.listLaunchableApps(this).filter {
            val l = it.label.lowercase()
            val p = it.packageName.lowercase()
            l.contains("acode") || l.contains("trebedit") || l.contains("spck") ||
                l.contains("quickedit") || l.contains("anwriter") || l.contains("html") ||
                p.contains("acode") || p.contains("trebedit") || p.contains("spck")
        }
        htmlEditorPackages = listOf("") + editorCandidates.map { it.packageName }
        val editorLabels = listOf("Auto-detect Installed HTML Editor") +
            editorCandidates.map { "${it.label} (${it.packageName})" }
        binding.spinnerHtmlEditor.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            editorLabels
        )
    }

    private fun setupSliders() {
        binding.seekSpeechSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val speed = 0.5f + (progress / 100f)
                binding.tvSpeechSpeedValue.text = String.format(Locale.US, "%.2fx", speed)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekEyeSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val speed = 0.4f + (progress / 100f)
                binding.tvEyeSpeedValue.text = String.format(Locale.US, "%.2fx", speed)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupPermissionButtons() {
        binding.btnEnableAccessibility.setOnClickListener {
            LooiAccessibilityService.openAccessibilitySettings(this)
        }

        binding.btnBatteryOptimization.setOnClickListener {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        binding.btnToggleScreenCapture.setOnClickListener {
            if (ScreenCaptureManager.hasConsent()) {
                ScreenCaptureManager.clearConsent()
                settings.screenCaptureConsentGranted = false
                refreshPermissionStatuses()
                Toast.makeText(this, "Screen capture consent cleared", Toast.LENGTH_SHORT).show()
            } else {
                screenCaptureLauncher.launch(ScreenCaptureManager.createCaptureIntent(this))
            }
        }
    }

    private fun refreshPermissionStatuses() {
        // Keystore encryption status
        if (settings.isSecureStorageAvailable()) {
            binding.tvKeystoreStatus.text = "Security: Android Keystore Encrypted Storage Active (AES256-GCM)"
            binding.tvKeystoreStatus.setTextColor(ContextCompat.getColor(this, R.color.looi_green))
        } else {
            binding.tvKeystoreStatus.text = settings.secureStorageErrorMessage
                ?: "Security Warning: Android Keystore unavailable. Use Companion HTTPS Backend Proxy."
            binding.tvKeystoreStatus.setTextColor(ContextCompat.getColor(this, R.color.looi_red))
        }

        // Accessibility Service status
        val a11yOn = LooiAccessibilityService.isAccessibilityEnabled(this)
        binding.tvAccessibilityStatus.text = if (a11yOn) {
            "Accessibility Service: CONNECTED (Phone & App Control Active)"
        } else {
            "Accessibility Service: OFF (Required for YouTube, HTML Editor & Screen Control)"
        }
        binding.tvAccessibilityStatus.setTextColor(
            ContextCompat.getColor(this, if (a11yOn) R.color.looi_green else R.color.looi_yellow)
        )

        // Battery Optimization status
        val pm = getSystemService(POWER_SERVICE) as? PowerManager
        val ignoringBattery = pm?.isIgnoringBatteryOptimizations(packageName) == true
        binding.tvBatteryStatus.text = if (ignoringBattery) {
            "Battery Optimization: Unrestricted (Background service protected)"
        } else {
            "Battery Optimization: Restricted (May kill wake-word service in background)"
        }
        binding.tvBatteryStatus.setTextColor(
            ContextCompat.getColor(this, if (ignoringBattery) R.color.looi_green else R.color.text_secondary)
        )

        // Screen Capture Consent
        val captureActive = ScreenCaptureManager.hasConsent()
        binding.tvScreenCaptureStatus.text = if (captureActive) {
            "Optional Screen OCR Capture: CONSENT GRANTED"
        } else {
            "Optional Screen OCR Capture: Off (Accessibility tree still works without it)"
        }
        binding.btnToggleScreenCapture.text = if (captureActive) {
            "Revoke Screen Capture Consent"
        } else {
            "Grant One-Tap Screen Capture Consent"
        }
    }

    private fun loadSavedValues() {
        val providerIdx = providerCodes.indexOf(settings.aiProvider).coerceAtLeast(0)
        binding.spinnerAiProvider.setSelection(providerIdx)

        binding.etGroqApiKey.setText(settings.groqApiKey)
        binding.etGeminiApiKey.setText(settings.geminiApiKey)

        val groqModelIdx = groqModels.indexOf(settings.groqModel).coerceAtLeast(0)
        binding.spinnerGroqModel.setSelection(groqModelIdx)

        val geminiModelIdx = geminiModels.indexOf(settings.geminiModel).coerceAtLeast(0)
        binding.spinnerGeminiModel.setSelection(geminiModelIdx)

        binding.etBackendUrl.setText(settings.backendUrl)

        val langIdx = languageCodes.indexOf(settings.languageCode).coerceAtLeast(0)
        binding.spinnerLanguage.setSelection(langIdx)

        val editorIdx = htmlEditorPackages.indexOf(settings.preferredHtmlEditorPackage).coerceAtLeast(0)
        binding.spinnerHtmlEditor.setSelection(editorIdx)

        binding.switchPreferFemaleVoice.isChecked = settings.preferFemaleVoice
        binding.switchContinuousVoice.isChecked = settings.continuousVoiceEnabled
        binding.switchWakeWordEnabled.isChecked = settings.wakeWordEnabled
        binding.etWakeWordPhrase.setText(settings.wakeWordPhrase)

        val speechProgress = ((settings.speechSpeed - 0.5f) * 100f).toInt().coerceIn(0, 150)
        binding.seekSpeechSpeed.progress = speechProgress
        binding.tvSpeechSpeedValue.text = String.format(Locale.US, "%.2fx", settings.speechSpeed)

        val eyeProgress = ((settings.eyeAnimationSpeed - 0.4f) * 100f).toInt().coerceIn(0, 160)
        binding.seekEyeSpeed.progress = eyeProgress
        binding.tvEyeSpeedValue.text = String.format(Locale.US, "%.2fx", settings.eyeAnimationSpeed)

        binding.switchCameraEnabled.isChecked = settings.cameraEnabled
        binding.switchMirrorCamera.isChecked = settings.mirrorCamera
        binding.switchObjectDetection.isChecked = settings.objectDetectionEnabled
        binding.switchSoundEnabled.isChecked = settings.soundEnabled
        binding.switchSaveHistory.isChecked = settings.saveHistoryEnabled

        refreshPermissionStatuses()
    }

    private fun initVoiceList() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val voices = tts?.voices
                    ?.filter { it.locale.language == "hi" || it.locale.language == "en" }
                    ?.sortedBy { it.name }
                    .orEmpty()

                availableVoices = voices
                val labels = mutableListOf("Auto Female / System Default")
                labels.addAll(voices.map { "${it.locale.displayLanguage} (${it.name})" })

                runOnUiThread {
                    if (isDestroyed || isFinishing) return@runOnUiThread
                    binding.spinnerVoice.adapter = ArrayAdapter(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        labels
                    )
                    val savedName = settings.voiceName
                    if (savedName.isNotBlank()) {
                        val idx = voices.indexOfFirst { it.name == savedName }
                        if (idx >= 0) {
                            binding.spinnerVoice.setSelection(idx + 1)
                        }
                    }
                }
            }
        }
    }

    private fun saveSettings() {
        val enteredBackendUrl = binding.etBackendUrl.text?.toString().orEmpty().trim()
            .ifBlank { SettingsManager.DEFAULT_BACKEND_URL }
        if (!settings.isBackendUrlAllowedBySecurityPolicy(enteredBackendUrl)) {
            Toast.makeText(
                this,
                "Physical devices require https:// for remote Backend URLs (http:// is allowed only for 10.0.2.2/localhost).",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val enteredGroqKey = binding.etGroqApiKey.text?.toString().orEmpty().trim()
        val enteredGeminiKey = binding.etGeminiApiKey.text?.toString().orEmpty().trim()

        // Strictly require Android Keystore before persisting API keys (no plain-text fallback)
        if ((enteredGroqKey.isNotEmpty() || enteredGeminiKey.isNotEmpty()) && !settings.isSecureStorageAvailable()) {
            Toast.makeText(
                this,
                settings.secureStorageErrorMessage
                    ?: "Android Keystore unavailable; cannot store API keys securely. Clear keys and use HTTPS Backend Proxy.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        try {
            if (settings.isSecureStorageAvailable()) {
                settings.groqApiKey = enteredGroqKey
                settings.geminiApiKey = enteredGeminiKey
            }
        } catch (e: IllegalStateException) {
            Toast.makeText(this, e.localizedMessage ?: "Secure storage error", Toast.LENGTH_LONG).show()
            return
        }

        settings.aiProvider = providerCodes.getOrElse(binding.spinnerAiProvider.selectedItemPosition) {
            SettingsManager.PROVIDER_AUTO
        }
        settings.groqModel = groqModels.getOrElse(binding.spinnerGroqModel.selectedItemPosition) {
            SettingsManager.DEFAULT_GROQ_MODEL
        }
        settings.geminiModel = geminiModels.getOrElse(binding.spinnerGeminiModel.selectedItemPosition) {
            SettingsManager.DEFAULT_GEMINI_MODEL
        }
        settings.backendUrl = enteredBackendUrl
        settings.languageCode = languageCodes.getOrElse(binding.spinnerLanguage.selectedItemPosition) { "hi-IN" }
        settings.preferredHtmlEditorPackage = htmlEditorPackages.getOrElse(
            binding.spinnerHtmlEditor.selectedItemPosition
        ) { "" }

        val selectedVoicePos = binding.spinnerVoice.selectedItemPosition
        settings.voiceName = if (selectedVoicePos > 0 && selectedVoicePos - 1 < availableVoices.size) {
            availableVoices[selectedVoicePos - 1].name
        } else {
            ""
        }

        settings.preferFemaleVoice = binding.switchPreferFemaleVoice.isChecked
        settings.continuousVoiceEnabled = binding.switchContinuousVoice.isChecked
        settings.wakeWordEnabled = binding.switchWakeWordEnabled.isChecked
        settings.wakeWordPhrase = binding.etWakeWordPhrase.text?.toString().orEmpty().trim()

        if (settings.wakeWordEnabled) {
            LooiAssistantService.startOrUpdate(this)
        } else {
            LooiAssistantService.stop(this)
        }

        settings.speechSpeed = 0.5f + (binding.seekSpeechSpeed.progress / 100f)
        settings.eyeAnimationSpeed = 0.4f + (binding.seekEyeSpeed.progress / 100f)
        settings.cameraEnabled = binding.switchCameraEnabled.isChecked
        settings.mirrorCamera = binding.switchMirrorCamera.isChecked
        settings.objectDetectionEnabled = binding.switchObjectDetection.isChecked
        settings.soundEnabled = binding.switchSoundEnabled.isChecked
        settings.saveHistoryEnabled = binding.switchSaveHistory.isChecked

        Toast.makeText(this, "Settings saved securely!", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
