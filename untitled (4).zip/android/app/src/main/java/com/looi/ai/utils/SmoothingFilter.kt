package com.looi.ai.utils

/**
 * Exponential low-pass filter to smooth out jittery face tracking,
 * pupil coordinates, and animation transitions.
 */
class SmoothingFilter(var alpha: Float = 0.25f) {
    private var currentValue: Float? = null

    fun filter(target: Float): Float {
        val current = currentValue
        val clampedAlpha = alpha.coerceIn(0.02f, 1.0f)
        val filtered = if (current == null) {
            target
        } else {
            current + clampedAlpha * (target - current)
        }
        currentValue = filtered
        return filtered
    }

    fun reset() {
        currentValue = null
    }
}
