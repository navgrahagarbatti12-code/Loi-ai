package com.looi.ai.vision

import android.annotation.SuppressLint
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.objects.DetectedObject
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.looi.ai.avatar.RobotEmotion
import com.looi.ai.utils.SmoothingFilter
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

/**
 * Combined non-blocking CameraX ImageAnalysis.Analyzer that runs
 * ML Kit Face Tracking (every frame) and ML Kit Object Detection (every 3rd frame)
 * on a background executor, enforcing monotonic frame ordering, failure cleanup,
 * and strict shutdown guards before detector close().
 */
class CompositeVisionAnalyzer(
    private val faceListener: FaceTrackingListener,
    private val objectListener: ObjectDetectionListener,
    @Volatile var isObjectDetectionEnabled: Boolean = true,
    @Volatile var isFrontCameraMirrored: Boolean = true
) : ImageAnalysis.Analyzer {

    private val tag = "CompositeVisionAnalyzer"

    @Volatile
    private var isClosed = false

    private val frameSequence = AtomicLong(0L)
    private val latestFaceSeq = AtomicLong(0L)
    private val latestObjectSeq = AtomicLong(0L)

    private val faceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setMinFaceSize(0.15f)
            .build()
    )

    private val objectDetector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableClassification()
            .enableMultipleObjects()
            .build()
    )

    private val smoothX = SmoothingFilter(0.32f)
    private val smoothY = SmoothingFilter(0.32f)

    private var consecutiveLostFrames = 0
    private val lostThreshold = 8
    private var frameCounter = 0

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        if (isClosed) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val seq = frameSequence.incrementAndGet()
        val rotation = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rotation)

        val uprightWidth = if (rotation == 90 || rotation == 270) {
            mediaImage.height.toFloat()
        } else {
            mediaImage.width.toFloat()
        }
        val uprightHeight = if (rotation == 90 || rotation == 270) {
            mediaImage.width.toFloat()
        } else {
            mediaImage.height.toFloat()
        }

        val tasks = mutableListOf<Task<*>>()

        // 1. Face Tracking Task (every frame)
        val faceTask = faceDetector.process(inputImage)
            .addOnSuccessListener { faces ->
                if (isClosed || seq < latestFaceSeq.get()) return@addOnSuccessListener
                latestFaceSeq.set(seq)
                handleFaces(faces, uprightWidth, uprightHeight)
            }
            .addOnFailureListener { e ->
                if (isClosed || seq < latestFaceSeq.get()) return@addOnFailureListener
                latestFaceSeq.set(seq)
                Log.w(tag, "Face detection frame error: ${e.message}")
                consecutiveLostFrames++
                if (consecutiveLostFrames >= lostThreshold) {
                    faceListener.onFaceLost()
                }
            }
        tasks.add(faceTask)

        // 2. Object Detection Task (every 3rd frame to optimize battery & thermal budget)
        frameCounter++
        if (isObjectDetectionEnabled && frameCounter % 3 == 0) {
            val objectTask = objectDetector.process(inputImage)
                .addOnSuccessListener { detectedObjects ->
                    if (isClosed || seq < latestObjectSeq.get()) return@addOnSuccessListener
                    latestObjectSeq.set(seq)
                    handleObjects(detectedObjects)
                }
                .addOnFailureListener { e ->
                    if (isClosed || seq < latestObjectSeq.get()) return@addOnFailureListener
                    latestObjectSeq.set(seq)
                    Log.w(tag, "Object detection failure: ${e.message}")
                    objectListener.onObjectsDetected(emptyList(), null)
                }
            tasks.add(objectTask)
        } else if (!isObjectDetectionEnabled) {
            objectListener.onObjectsDetected(emptyList(), null)
        }

        Tasks.whenAllComplete(tasks)
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    private fun handleFaces(faces: List<Face>, frameWidth: Float, frameHeight: Float) {
        if (isClosed) return
        if (faces.isNotEmpty() && frameWidth > 0f && frameHeight > 0f) {
            consecutiveLostFrames = 0
            val face = faces[0]
            val box = face.boundingBox

            val mirrorSign = if (isFrontCameraMirrored) -1f else 1f
            val rawCenterX = ((box.centerX() / frameWidth) - 0.5f) * 2f * mirrorSign
            val rawCenterY = ((box.centerY() / frameHeight) - 0.5f) * 2f

            val filteredX = smoothX.filter(rawCenterX.coerceIn(-1f, 1f))
            val filteredY = smoothY.filter(rawCenterY.coerceIn(-1f, 1f))

            val smileProb = face.smilingProbability ?: 0f
            val leftEyeOpen = face.leftEyeOpenProbability ?: 1f
            val rightEyeOpen = face.rightEyeOpenProbability ?: 1f
            val headEulerZ = face.headEulerAngleZ

            val emotion = when {
                smileProb > 0.65f -> RobotEmotion.HAPPY
                leftEyeOpen < 0.2f && rightEyeOpen < 0.2f -> RobotEmotion.SLEEPING
                leftEyeOpen < 0.35f || rightEyeOpen < 0.35f -> RobotEmotion.CURIOUS
                abs(headEulerZ) > 18f -> RobotEmotion.CURIOUS
                else -> RobotEmotion.HAPPY
            }

            faceListener.onFaceTracked(filteredX, filteredY, emotion, face)
        } else {
            consecutiveLostFrames++
            if (consecutiveLostFrames >= lostThreshold) {
                faceListener.onFaceLost()
            }
        }
    }

    private fun handleObjects(detectedObjects: List<DetectedObject>) {
        if (isClosed) return
        if (detectedObjects.isEmpty()) {
            objectListener.onObjectsDetected(emptyList(), null)
            return
        }

        var dominantLabel: String? = null
        var maxConfidence = 0.45f

        for (obj in detectedObjects) {
            val bestLabel = obj.labels.maxByOrNull { it.confidence }
            if (bestLabel != null && bestLabel.confidence > 0.45f && bestLabel.confidence > maxConfidence) {
                maxConfidence = bestLabel.confidence
                dominantLabel = bestLabel.text
            }
        }

        objectListener.onObjectsDetected(detectedObjects, dominantLabel)
    }

    fun close() {
        isClosed = true
        try {
            faceDetector.close()
            objectDetector.close()
        } catch (_: Exception) {
        }
    }
}
