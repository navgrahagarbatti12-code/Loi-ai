package com.looi.ai.vision

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

data class CapturedScreenFrame(
    val ocrText: String,
    val jpegBytes: ByteArray
)

/**
 * Optional on-demand Screen Capture Manager using Android MediaProjection
 * ONLY after explicit user consent. Captures a single frame when requested
 * (never continuously streams screenshots) and runs on-device ML Kit OCR.
 */
object ScreenCaptureManager {

    private const val tag = "ScreenCaptureManager"
    private var consentResultCode: Int? = null
    private var consentResultData: Intent? = null

    fun hasConsent(): Boolean = consentResultCode == Activity.RESULT_OK && consentResultData != null

    fun saveConsentResult(resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK && data != null) {
            consentResultCode = resultCode
            consentResultData = data
        } else {
            clearConsent()
        }
    }

    fun clearConsent() {
        consentResultCode = null
        consentResultData = null
    }

    fun createCaptureIntent(context: Context): Intent {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return mgr.createScreenCaptureIntent()
    }

    suspend fun captureSingleFrameWithOcr(context: Context): CapturedScreenFrame? {
        val code = consentResultCode ?: return null
        val data = consentResultData ?: return null

        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection: MediaProjection = try {
            mgr.getMediaProjection(code, data)
        } catch (e: Exception) {
            Log.e(tag, "Failed to obtain MediaProjection: ${e.message}")
            clearConsent()
            return null
        }

        val dm = context.resources.displayMetrics
        val width = (dm.widthPixels / 2).coerceAtLeast(360)
        val height = (dm.heightPixels / 2).coerceAtLeast(640)
        val densityDpi = dm.densityDpi

        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        var virtualDisplay: VirtualDisplay? = null

        val bitmap: Bitmap? = suspendCancellableCoroutine { cont ->
            val handler = Handler(Looper.getMainLooper())
            var resumed = false

            val cleanup = {
                try {
                    imageReader.setOnImageAvailableListener(null, null)
                    virtualDisplay?.release()
                    imageReader.close()
                    projection.stop()
                } catch (_: Exception) {
                }
            }

            cont.invokeOnCancellation { cleanup() }

            val timeoutRunnable = Runnable {
                if (!resumed) {
                    resumed = true
                    cleanup()
                    cont.resume(null)
                }
            }
            handler.postDelayed(timeoutRunnable, 1500L)

            imageReader.setOnImageAvailableListener({ reader ->
                if (resumed) return@setOnImageAvailableListener
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                resumed = true
                handler.removeCallbacks(timeoutRunnable)

                val converted = try {
                    val planes = image.planes
                    val buffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val rawBmp = Bitmap.createBitmap(
                        width + rowPadding / pixelStride,
                        height,
                        Bitmap.Config.ARGB_8888
                    )
                    rawBmp.copyPixelsFromBuffer(buffer)
                    Bitmap.createBitmap(rawBmp, 0, 0, width, height)
                } catch (e: Exception) {
                    Log.e(tag, "Bitmap extraction failed", e)
                    null
                } finally {
                    image.close()
                    cleanup()
                }
                cont.resume(converted)
            }, handler)

            try {
                virtualDisplay = projection.createVirtualDisplay(
                    "LooiScreenCapture",
                    width,
                    height,
                    densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.surface,
                    null,
                    handler
                )
            } catch (e: Exception) {
                if (!resumed) {
                    resumed = true
                    handler.removeCallbacks(timeoutRunnable)
                    cleanup()
                    cont.resume(null)
                }
            }
        }

        if (bitmap == null) return null

        val ocrText = runOnDeviceOcr(bitmap)
        val jpegBytes = ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, out)
            out.toByteArray()
        }
        bitmap.recycle()

        return CapturedScreenFrame(ocrText = ocrText, jpegBytes = jpegBytes)
    }

    private suspend fun runOnDeviceOcr(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                recognizer.close()
                cont.resume(result.text.trim())
            }
            .addOnFailureListener {
                recognizer.close()
                cont.resume("")
            }
    }
}
