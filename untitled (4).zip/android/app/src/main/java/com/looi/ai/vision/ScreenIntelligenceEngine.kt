package com.looi.ai.vision

import android.content.Context
import com.looi.ai.accessibility.LooiAccessibilityService
import com.looi.ai.accessibility.ScreenSnapshot
import com.looi.ai.ai.gemini.GeminiLiveClient
import com.looi.ai.ai.groq.GroqManager
import com.looi.ai.settings.SettingsManager

data class ScreenUnderstandingResult(
    val appLabel: String,
    val packageName: String,
    val snapshot: ScreenSnapshot?,
    val ocrText: String,
    val explanation: String
)

/**
 * Live Screen Intelligence Engine.
 * Reads the real Accessibility tree and, when permitted, optional MediaProjection OCR/Vision
 * so LOOI answers questions strictly from actual observed screen data.
 */
class ScreenIntelligenceEngine(
    private val context: Context,
    private val settings: SettingsManager,
    private val groqManager: GroqManager,
    private val geminiClient: GeminiLiveClient
) {

    suspend fun explainCurrentScreen(userQuestion: String): Result<ScreenUnderstandingResult> {
        val accessibility = LooiAccessibilityService.instance
        val snapshot = accessibility?.captureScreenSnapshot()

        var ocrText = ""
        var screenshotJpeg: ByteArray? = null

        val shouldUseCapture = (snapshot == null || snapshot.visibleTexts.size < 3) &&
            settings.screenCaptureConsentGranted &&
            ScreenCaptureManager.hasConsent()

        if (shouldUseCapture) {
            val captured = ScreenCaptureManager.captureSingleFrameWithOcr(context)
            if (captured != null) {
                ocrText = captured.ocrText
                screenshotJpeg = captured.jpegBytes
            }
        }

        if (snapshot == null && ocrText.isBlank() && screenshotJpeg == null) {
            return Result.failure(
                IllegalStateException(
                    "Accessibility Service enable nahi hai aur screen capture consent bhi active nahi hai. Settings mein LOOI Accessibility Service on karo taaki main screen padh sakoon."
                )
            )
        }

        if (snapshot?.isSensitiveScreen == true) {
            return Result.success(
                ScreenUnderstandingResult(
                    appLabel = snapshot.appLabel,
                    packageName = snapshot.packageName,
                    snapshot = snapshot,
                    ocrText = "",
                    explanation = "Yeh ek sensitive screen hai (password, OTP, payment ya system permission), isliye privacy ke liye main isko read nahi karungi."
                )
            )
        }

        val combinedContext = buildString {
            if (snapshot != null) {
                appendLine(snapshot.toPromptSummary())
            }
            if (ocrText.isNotBlank()) {
                appendLine("Screen OCR Text:")
                appendLine(ocrText.take(1600))
            }
        }.trim()

        val prompt = """
            User question about the phone screen: "$userQuestion"
            
            Actual observed screen content:
            $combinedContext
            
            Explain clearly in 2-3 short natural Hinglish/Hindi sentences what is currently visible on screen and what action can be taken next. Never guess anything not present in the screen data.
        """.trimIndent()

        val aiResponse = when {
            screenshotJpeg != null && settings.geminiApiKey.isNotBlank() -> {
                geminiClient.sendConversationTurn(
                    userMessage = prompt,
                    detectedEmotion = "CURIOUS",
                    detectedObjects = emptyList(),
                    historyContext = "",
                    screenshotJpeg = screenshotJpeg
                )
            }
            settings.aiProvider == SettingsManager.PROVIDER_GROQ ||
                (settings.aiProvider == SettingsManager.PROVIDER_AUTO && settings.groqApiKey.isNotBlank()) -> {
                groqManager.chatCompletion(
                    userMessage = prompt,
                    detectedEmotion = "CURIOUS",
                    detectedObjects = emptyList(),
                    historyContext = ""
                )
            }
            else -> {
                geminiClient.sendConversationTurn(
                    userMessage = prompt,
                    detectedEmotion = "CURIOUS",
                    detectedObjects = emptyList(),
                    historyContext = ""
                )
            }
        }

        val explanation = aiResponse.getOrElse {
            // Even if AI network fails, return real factual summary from the accessibility tree!
            buildLocalScreenSummary(snapshot, ocrText)
        }

        return Result.success(
            ScreenUnderstandingResult(
                appLabel = snapshot?.appLabel ?: "Current Screen",
                packageName = snapshot?.packageName.orEmpty(),
                snapshot = snapshot,
                ocrText = ocrText,
                explanation = explanation
            )
        )
    }

    private fun buildLocalScreenSummary(snapshot: ScreenSnapshot?, ocrText: String): String {
        val app = snapshot?.appLabel ?: "Screen"
        val preview = snapshot?.visibleTexts?.take(6)?.joinToString(", ")
            ?: ocrText.lines().take(5).joinToString(", ")
        return if (preview.isBlank()) {
            "$app khula hua hai, lekin koi readable text detect nahi hua."
        } else {
            "$app khula hai. Screen par yeh dikh raha hai: $preview."
        }
    }
}
