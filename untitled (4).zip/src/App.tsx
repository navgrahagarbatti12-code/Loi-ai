import React, { useState, useEffect, useRef, useCallback } from 'react';
import { LooiRobotCanvas, RobotEmotion } from './components/LooiRobotCanvas';
import { looiVisionService, DetectedVisualObject } from './services/looiVision';
import { looiVoiceService, ChatMessage } from './services/looiVoice';
import { looiMemoryService, LooiPreferences } from './services/looiMemory';
import { AndroidCodeExplorer } from './components/AndroidCodeExplorer';
import {
  Camera,
  Settings,
  MessageSquare,
  Trash2,
  RefreshCw,
  Shield,
  Cpu,
  CheckCircle2,
  Languages,
  Volume2,
  Play,
  ArrowLeft,
  Power,
} from 'lucide-react';

type ScreenType =
  | 'main'
  | 'conversation'
  | 'camera_settings'
  | 'voice_settings'
  | 'api_settings'
  | 'memory'
  | 'privacy'
  | 'about_android';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('main');

  // Robot avatar state
  const [emotion, setEmotion] = useState<RobotEmotion>('HAPPY');
  const [lookX, setLookX] = useState(0);
  const [lookY, setLookY] = useState(0);
  const [mouthAmplitude, setMouthAmplitude] = useState(0);
  const [voiceState, setVoiceState] = useState<'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING'>('IDLE');
  const [isAwake, setIsAwake] = useState(false);

  // Background camera & vision state (hidden video element)
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const cameraStartedRef = useRef(false);
  const voiceStartedRef = useRef(false);
  const detectedObjectsRef = useRef<DetectedVisualObject[]>([]);
  const emotionRef = useRef<RobotEmotion>('HAPPY');
  const voiceStateRef = useRef<'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING'>('IDLE');
  const messagesRef = useRef<ChatMessage[]>([]);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [preferences, setPreferences] = useState<LooiPreferences>(looiMemoryService.getPreferences());

  // Sync refs for background callbacks
  useEffect(() => {
    emotionRef.current = emotion;
  }, [emotion]);

  useEffect(() => {
    voiceStateRef.current = voiceState;
  }, [voiceState]);

  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  const handleSpeak = useCallback((text: string, mood: RobotEmotion = 'HAPPY') => {
    looiVoiceService.pauseForSpeech();
    setEmotion('TALKING');
    looiVoiceService.speak(text, () => {
      setEmotion(mood);
      looiVoiceService.resumeAfterSpeech();
    });
  }, []);

  const handleUserQuery = useCallback(
    async (queryText: string) => {
      looiVoiceService.pauseForSpeech();

      const userMsg: ChatMessage = {
        id: String(Date.now()),
        sender: 'USER',
        text: queryText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      const updatedList = [...messagesRef.current, userMsg];
      setMessages(updatedList);
      looiMemoryService.saveMessage(userMsg);

      const context = looiMemoryService.getRecentContext();
      const objectLabels = Array.from(new Set(detectedObjectsRef.current.map((o) => o.label)));
      const frameSnapshot = looiVisionService.captureCurrentFrameBase64();

      const { reply, emotion: newEmotion } = await looiVoiceService.sendLooiMessage(
        queryText,
        emotionRef.current,
        objectLabels,
        context,
        frameSnapshot
      );

      const looiMsg: ChatMessage = {
        id: String(Date.now() + 1),
        sender: 'LOOI',
        text: reply,
        emotion: newEmotion,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, looiMsg]);
      looiMemoryService.saveMessage(looiMsg);
      handleSpeak(reply, newEmotion);
    },
    [handleSpeak]
  );

  // Start background camera & object/face tracking
  const startBackgroundVision = useCallback(async (fromUserGesture = false) => {
    if (cameraStartedRef.current || !videoRef.current) return;

    if (!fromUserGesture && navigator.permissions?.query) {
      try {
        const perm = await navigator.permissions.query({ name: 'camera' as PermissionName });
        if (perm.state === 'denied') {
          return;
        }
      } catch {
        // Permissions API for camera not supported in this browser; proceed
      }
    }

    cameraStartedRef.current = true;
    const started = await looiVisionService.startCamera(
      videoRef.current,
      (face) => {
        setLookX(face.lookX);
        setLookY(face.lookY);
        if (voiceStateRef.current !== 'SPEAKING' && voiceStateRef.current !== 'THINKING') {
          setEmotion(face.inferredEmotion);
        }
      },
      (objs) => {
        detectedObjectsRef.current = objs;
      }
    );
    if (!started) {
      cameraStartedRef.current = false;
    }
  }, []);

  const handleAudioTurn = useCallback(
    async (audioBase64: string, mimeType: string) => {
      looiVoiceService.pauseForSpeech();
      const context = looiMemoryService.getRecentContext();
      const objectLabels = Array.from(new Set(detectedObjectsRef.current.map((o) => o.label)));
      const frameSnapshot = looiVisionService.captureCurrentFrameBase64();

      const { silence, reply, emotion: newEmotion } = await looiVoiceService.sendLooiAudioTurn(
        audioBase64,
        mimeType,
        emotionRef.current,
        objectLabels,
        context,
        frameSnapshot
      );

      if (silence || !reply) {
        setEmotion('HAPPY');
        looiVoiceService.resumeAfterSpeech();
        return;
      }

      const looiMsg: ChatMessage = {
        id: String(Date.now()),
        sender: 'LOOI',
        text: reply,
        emotion: newEmotion,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, looiMsg]);
      looiMemoryService.saveMessage(looiMsg);
      handleSpeak(reply, newEmotion);
    },
    [handleSpeak]
  );

  // Start background continuous voice-to-voice (100% silent MediaRecorder + VAD)
  const startBackgroundVoice = useCallback(
    async (fromUserGesture = false) => {
      if (voiceStartedRef.current) return true;

      if (!fromUserGesture && navigator.permissions?.query) {
        try {
          const perm = await navigator.permissions.query({ name: 'microphone' as PermissionName });
          if (perm.state !== 'granted') {
            return false;
          }
        } catch {
          if (!fromUserGesture) return false;
        }
      }

      const started = await looiVoiceService.startContinuousListening(handleAudioTurn);

      if (started) {
        voiceStartedRef.current = true;
      }
      return started;
    },
    [handleAudioTurn]
  );

  const wakeUpCompanion = useCallback(async () => {
    looiVoiceService.primeAudioOutput();
    const firstWake = !isAwake;
    setIsAwake(true);

    if (firstWake) {
      handleSpeak('Haan dost, main sun raha hoon! Bolo kya baat hai?', 'HAPPY');
    }

    startBackgroundVision(true);
    await startBackgroundVoice(true);
  }, [isAwake, startBackgroundVision, startBackgroundVoice, handleSpeak]);

  const stopCompanion = useCallback(() => {
    looiVoiceService.stopListening();
    looiVoiceService.stopSpeaking();
    looiVisionService.stopCamera();
    cameraStartedRef.current = false;
    voiceStartedRef.current = false;
    setIsAwake(false);
    setLookX(0);
    setLookY(0);
    setMouthAmplitude(0);
    setEmotion('SLEEPING');
  }, []);

  // Initialize everything automatically in background on mount
  useEffect(() => {
    setMessages(looiMemoryService.getMessages());

    looiVoiceService.init(
      (amp) => setMouthAmplitude(amp),
      (st) => {
        setVoiceState(st);
        if (st === 'SPEAKING') setEmotion('TALKING');
        else if (st === 'THINKING') setEmotion('THINKING');
        else if (st === 'IDLE' && emotionRef.current === 'TALKING') setEmotion('HAPPY');
      }
    );

    // Auto-start if permissions were already granted
    startBackgroundVision(false);
    startBackgroundVoice(false).then((ok) => {
      if (ok) setIsAwake(true);
    });

    return () => {
      looiVisionService.stopCamera();
      looiVoiceService.stopListening();
    };
  }, [startBackgroundVision, startBackgroundVoice]);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#080C14] text-slate-100 font-sans select-none">
      {/* Hidden camera video element running object & face tracking in background */}
      <video ref={videoRef} playsInline muted className="hidden" />

      {/* ========================================================= */}
      {/* MAIN ROBOT FACE SCREEN: Pure full-screen face, no buttons */}
      {/* ========================================================= */}
      {currentScreen === 'main' && (
        <div className="relative w-full h-full flex items-center justify-center bg-[#080C14]">
          <LooiRobotCanvas
            emotion={emotion}
            lookX={lookX}
            lookY={lookY}
            mouthAmplitude={mouthAmplitude}
            onClick={wakeUpCompanion}
            className="w-full h-full"
          />

          {!isAwake && (
            <div
              onClick={wakeUpCompanion}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 text-xs tracking-wider text-cyan-400/70 font-mono animate-pulse cursor-pointer"
            >
              Tap anywhere to talk with LOOI
            </div>
          )}

          {/* Single-corner minimal controls: Stop/Start + Settings */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2 py-1.5 rounded-full bg-slate-900/50 border border-slate-800/60 backdrop-blur-md opacity-45 hover:opacity-100 transition-opacity">
            <button
              onClick={() => (isAwake ? stopCompanion() : wakeUpCompanion())}
              className={`p-1.5 rounded-full transition-colors ${
                isAwake
                  ? 'text-rose-400 hover:bg-rose-500/20'
                  : 'text-emerald-400 hover:bg-emerald-500/20'
              }`}
              title={isAwake ? 'Stop LOOI' : 'Start LOOI'}
              aria-label={isAwake ? 'Stop LOOI' : 'Start LOOI'}
            >
              <Power className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentScreen('camera_settings')}
              className="p-1.5 rounded-full text-slate-300 hover:bg-slate-800 transition-colors"
              title="Settings"
              aria-label="Settings"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* CONVERSATION HISTORY SCREEN (accessible from menu)        */}
      {/* ========================================================= */}
      {currentScreen === 'conversation' && (
        <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full h-full p-4 overflow-hidden">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentScreen('main')}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <MessageSquare className="w-5 h-5 text-cyan-400" />
              <h2 className="text-base font-bold text-slate-100">LOOI Conversation History</h2>
            </div>
            <button
              onClick={() => {
                looiMemoryService.clearMemory();
                setMessages(looiMemoryService.getMessages());
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-medium border border-rose-500/30 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear Memory
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-4 space-y-3">
            {messages.map((msg) => {
              const isLooi = msg.sender === 'LOOI';
              return (
                <div key={msg.id} className={`flex gap-3 ${isLooi ? 'justify-start' : 'justify-end'}`}>
                  <div
                    className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm shadow-md ${
                      isLooi
                        ? 'bg-slate-900 border border-slate-800 text-slate-200'
                        : 'bg-gradient-to-r from-cyan-600 to-blue-600 text-slate-950 font-medium'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-4 mb-1 text-[11px] opacity-75 font-mono">
                      <span className="font-bold">{msg.sender}</span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <p className="leading-relaxed">{msg.text}</p>
                    {isLooi && (
                      <button
                        onClick={() => handleSpeak(msg.text, msg.emotion)}
                        className="mt-2 text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold"
                      >
                        <Play className="w-3 h-3" />
                        Speak aloud
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && inputText.trim()) {
                  handleUserQuery(inputText.trim());
                  setInputText('');
                }
              }}
              placeholder="Talk with LOOI in Hindi or Hinglish…"
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={() => {
                if (inputText.trim()) {
                  handleUserQuery(inputText.trim());
                  setInputText('');
                }
              }}
              className="px-5 py-3 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-sm"
            >
              Send
            </button>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SETTINGS SCREENS                                          */}
      {/* ========================================================= */}
      {(currentScreen === 'camera_settings' ||
        currentScreen === 'voice_settings' ||
        currentScreen === 'api_settings' ||
        currentScreen === 'memory' ||
        currentScreen === 'privacy') && (
        <div className="flex-1 flex max-w-4xl mx-auto w-full h-full p-6 overflow-hidden">
          <div className="w-56 bg-slate-900/60 rounded-2xl border border-slate-800 p-3 space-y-1 mr-6">
            <button
              onClick={() => setCurrentScreen('main')}
              className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 text-cyan-400 hover:bg-slate-800 mb-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Robot Face
            </button>
            <button
              onClick={() => setCurrentScreen('conversation')}
              className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 text-slate-400 hover:bg-slate-800"
            >
              <MessageSquare className="w-4 h-4" />
              Chat History
            </button>
            <button
              onClick={() => setCurrentScreen('camera_settings')}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 ${
                currentScreen === 'camera_settings' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Camera className="w-4 h-4" />
              Camera &amp; Vision
            </button>
            <button
              onClick={() => setCurrentScreen('voice_settings')}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 ${
                currentScreen === 'voice_settings' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Languages className="w-4 h-4" />
              Voice &amp; Language
            </button>
            <button
              onClick={() => setCurrentScreen('api_settings')}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 ${
                currentScreen === 'api_settings' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Cpu className="w-4 h-4" />
              Gemini &amp; Groq AI
            </button>
            <button
              onClick={() => setCurrentScreen('memory')}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 ${
                currentScreen === 'memory' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              <RefreshCw className="w-4 h-4" />
              Room Memory
            </button>
            <button
              onClick={() => setCurrentScreen('privacy')}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 ${
                currentScreen === 'privacy' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Shield className="w-4 h-4" />
              Privacy &amp; Security
            </button>
            <button
              onClick={() => setCurrentScreen('about_android')}
              className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 text-slate-400 hover:bg-slate-800"
            >
              <Settings className="w-4 h-4" />
              Android Studio Code
            </button>
          </div>

          <div className="flex-1 bg-slate-900/40 rounded-2xl border border-slate-800 p-6 overflow-y-auto">
            {currentScreen === 'camera_settings' && (
              <div className="space-y-6">
                <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Camera className="w-5 h-5 text-cyan-400" />
                  Camera &amp; Vision Settings
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-slate-950 border border-slate-800">
                    <div>
                      <div className="text-sm font-semibold text-slate-200">Mirror Front Camera</div>
                      <div className="text-xs text-slate-400">Natural mirror orientation for eye tracking</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.mirrorCamera}
                      onChange={(e) =>
                        setPreferences(looiMemoryService.savePreferences({ mirrorCamera: e.target.checked }))
                      }
                      className="w-5 h-5 accent-cyan-400"
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-xl bg-slate-950 border border-slate-800">
                    <div>
                      <div className="text-sm font-semibold text-slate-200">On-Device Object Tracking</div>
                      <div className="text-xs text-slate-400">Recognize &amp; follow objects automatically</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.detectObjects}
                      onChange={(e) =>
                        setPreferences(looiMemoryService.savePreferences({ detectObjects: e.target.checked }))
                      }
                      className="w-5 h-5 accent-cyan-400"
                    />
                  </div>
                </div>
              </div>
            )}

            {currentScreen === 'voice_settings' && (
              <div className="space-y-6">
                <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Languages className="w-5 h-5 text-cyan-400" />
                  Voice &amp; Language Settings
                </h3>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <label className="text-sm font-semibold text-slate-200">Primary Language</label>
                  <select
                    value={preferences.language}
                    onChange={(e) =>
                      setPreferences(looiMemoryService.savePreferences({ language: e.target.value }))
                    }
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-sm text-slate-200"
                  >
                    <option value="hi-IN">Hindi (हिंदी &amp; Romanized Hinglish)</option>
                    <option value="en-IN">Indian English (Hinglish mix)</option>
                  </select>
                </div>
                <button
                  onClick={() => handleSpeak('Arey hello dost! Meri aawaz kaisi lag rahi hai?', 'HAPPY')}
                  className="px-4 py-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-2"
                >
                  <Volume2 className="w-4 h-4" />
                  Test Companion Voice
                </button>
              </div>
            )}

            {currentScreen === 'api_settings' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-slate-100">AI Engine (Gemini Live &amp; Groq)</h3>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-bold text-slate-200">Gemini 3.1 Flash Lite (Voice Chat)</div>
                    <div className="text-xs text-slate-400">Ultra-low-latency Hindi/Hinglish responses</div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-mono font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    ACTIVE
                  </span>
                </div>
              </div>
            )}

            {currentScreen === 'memory' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-slate-100">Persistent Memory</h3>
                <p className="text-xs text-slate-400">Total saved messages: {messages.length}</p>
                <button
                  onClick={() => {
                    looiMemoryService.clearMemory();
                    setMessages(looiMemoryService.getMessages());
                  }}
                  className="px-4 py-2 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  Clear Memory
                </button>
              </div>
            )}

            {currentScreen === 'privacy' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-emerald-400">Privacy &amp; Local Vision</h3>
                <p className="text-xs text-slate-300">
                  Camera frames are processed locally on-device for object and face tracking. No continuous video is uploaded.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* ANDROID CODE EXPLORER SCREEN                              */}
      {/* ========================================================= */}
      {currentScreen === 'about_android' && (
        <div className="flex-1 p-6 flex flex-col h-full max-w-6xl mx-auto w-full gap-3">
          <button
            onClick={() => setCurrentScreen('main')}
            className="self-start flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs text-slate-300"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Robot Face
          </button>
          <div className="flex-1 min-h-0">
            <AndroidCodeExplorer />
          </div>
        </div>
      )}
    </div>
  );
}
