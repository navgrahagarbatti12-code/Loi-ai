import React, { useEffect, useState } from 'react';
import { ANDROID_PROJECT_FILES, AndroidFileRecord, downloadAndroidStudioZip, fetchCompleteAndroidFiles } from '../services/androidExporter';
import { Download, FileCode, Check, Copy, Terminal, FolderTree, Cpu } from 'lucide-react';

export const AndroidCodeExplorer: React.FC = () => {
  const [files, setFiles] = useState<AndroidFileRecord[]>(ANDROID_PROJECT_FILES);
  const [selectedFile, setSelectedFile] = useState<AndroidFileRecord>(ANDROID_PROJECT_FILES[5]);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    fetchCompleteAndroidFiles().then((loaded) => {
      const textFiles = loaded.filter((f) => f.encoding !== 'base64');
      setFiles(textFiles);
      const preferred = textFiles.find((f) => f.path.endsWith('RobotFaceCanvasView.kt')) || textFiles[0];
      if (preferred) setSelectedFile(preferred);
    });
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadAndroidStudioZip();
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Top Header */}
      <div className="flex items-center justify-between px-6 py-4 bg-slate-900/90 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Cpu className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              LOOI AI – Native Android Studio Codebase
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
                Kotlin &amp; CameraX
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Complete production project ready to import into Android Studio Iguana / Jellyfish / Ladybug
            </p>
          </div>
        </div>

        <button
          onClick={handleDownload}
          disabled={downloading}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/20 transition-all active:scale-95 disabled:opacity-50"
        >
          <Download className="w-4 h-4" />
          {downloading ? 'Packing ZIP…' : 'Download Complete Project (.ZIP)'}
        </button>
      </div>

      {/* Main Split: File Tree on left, Code viewer on right */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Left Sidebar: File Tree */}
        <div className="w-72 bg-slate-900/50 border-r border-slate-800 flex flex-col">
          <div className="p-3 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400 font-semibold uppercase tracking-wider">
            <span className="flex items-center gap-2">
              <FolderTree className="w-3.5 h-3.5 text-cyan-400" />
              Project Files
            </span>
            <span className="text-slate-500">{files.length} files</span>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {files.map((file) => {
              const isSelected = selectedFile.path === file.path;
              const fileName = file.path.split('/').pop() || file.path;
              const dirPath = file.path.includes('/')
                ? file.path.substring(0, file.path.lastIndexOf('/'))
                : '';

              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-colors flex items-start gap-2.5 ${
                    isSelected
                      ? 'bg-cyan-500/15 text-cyan-300 font-medium border border-cyan-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                  }`}
                >
                  <FileCode className={`w-4 h-4 shrink-0 mt-0.5 ${isSelected ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <div className="truncate">
                    <div className="truncate font-mono">{fileName}</div>
                    {dirPath && <div className="text-[10px] text-slate-500 truncate">{dirPath}</div>}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Quick Terminal Guide */}
          <div className="p-3 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-400 space-y-1.5 font-mono">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
              <Terminal className="w-3.5 h-3.5" />
              Build Command
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800 text-slate-300 select-all">
              ./gradlew assembleDebug
            </div>
          </div>
        </div>

        {/* Right Pane: Code Viewer */}
        <div className="flex-1 flex flex-col min-w-0 bg-slate-950">
          <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/60 border-b border-slate-800 text-xs">
            <span className="font-mono text-cyan-400 font-medium truncate">
              {selectedFile.path}
            </span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>

          <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-300">
            <pre className="whitespace-pre">{selectedFile.content}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};
