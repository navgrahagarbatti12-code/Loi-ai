import React, { useEffect, useRef, useState } from 'react';
import {
  Video,
  VideoOff,
  Camera,
  Maximize2,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  LayoutGrid,
  Square,
  Columns,
  Grid,
  Download,
  Activity,
  Layers,
} from 'lucide-react';
import { CameraDevice } from '../types/vision';
import { cameraService } from '../services/cameraService';

interface CCTVMonitoringViewProps {
  onCaptureSnapshot?: (dataUrl: string, cameraName: string) => void;
}

export const CCTVMonitoringView: React.FC<CCTVMonitoringViewProps> = ({
  onCaptureSnapshot,
}) => {
  const [devices, setDevices] = useState<CameraDevice[]>([]);
  const [gridLayout, setGridLayout] = useState<'1x1' | '1x2' | '2x2'>('2x2');
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [connectingId, setConnectingId] = useState<string | null>(null);
  const [globalError, setGlobalError] = useState<string | null>(null);

  // Video element references for each camera tile
  const videoRefs = useRef<Map<string, HTMLVideoElement>>(new Map());

  // Subscribe to device updates from cameraService
  useEffect(() => {
    const unsubscribe = cameraService.onDevicesChange((devList) => {
      setDevices(devList);
      if (devList.length > 0 && !selectedCameraId) {
        setSelectedCameraId(devList[0].id);
      }
    });

    // Initial device refresh
    cameraService.refreshDevices();

    return () => {
      unsubscribe();
    };
  }, [selectedCameraId]);

  // Synchronize video elements with active streams
  useEffect(() => {
    devices.forEach((dev) => {
      const vid = videoRefs.current.get(dev.id);
      if (vid) {
        if (dev.stream && dev.status === 'online') {
          if (vid.srcObject !== dev.stream) {
            vid.srcObject = dev.stream;
            vid.play().catch((err) => {
              console.warn(`Autoplay thwarted on camera ${dev.id}:`, err);
            });
          }
        } else {
          vid.srcObject = null;
        }
      }
    });
  }, [devices]);

  const handleToggleCamera = async (cameraId: string) => {
    const dev = devices.find((d) => d.id === cameraId);
    if (!dev) return;

    setGlobalError(null);

    if (dev.status === 'online') {
      cameraService.stopCamera(cameraId);
    } else {
      setConnectingId(cameraId);
      try {
        await cameraService.startCamera(cameraId);
      } catch (err: any) {
        setGlobalError(err.message || 'Failed to start camera');
      } finally {
        setConnectingId(null);
      }
    }
  };

  const handleCaptureSnapshot = (cameraId: string) => {
    const dev = devices.find((d) => d.id === cameraId);
    const video = videoRefs.current.get(cameraId);
    if (!video || !dev || dev.status !== 'online') return;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);

    // Trigger download
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `CCTV_Snapshot_${dev.label.replace(/\s+/g, '_')}_${Date.now()}.jpg`;
    link.click();

    if (onCaptureSnapshot) {
      onCaptureSnapshot(dataUrl, dev.label);
    }
  };

  const handleFullscreen = (cameraId: string) => {
    const video = videoRefs.current.get(cameraId);
    if (video && video.requestFullscreen) {
      video.requestFullscreen().catch((err) => {
        console.warn('Fullscreen request failed:', err);
      });
    }
  };

  const onlineCount = devices.filter((d) => d.status === 'online').length;

  return (
    <div className="space-y-6">
      {/* View Header with Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-bold text-slate-100">Live CCTV Surveillance Matrix</h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-cyan-950 text-cyan-400 border border-cyan-800/80">
              {onlineCount} OF {devices.length} LIVE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real hardware camera stream endpoints and synthetic CCTV feeds with low latency.
          </p>
        </div>

        {/* Layout & Control Buttons */}
        <div className="flex items-center space-x-2">
          {/* Refresh hardware devices */}
          <button
            onClick={() => cameraService.refreshDevices()}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
            title="Scan for attached cameras"
          >
            <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
            <span>Rescan Devices</span>
          </button>

          {/* Grid Layout Selectors */}
          <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setGridLayout('1x1')}
              className={`p-1.5 rounded ${
                gridLayout === '1x1' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Single Focused View (1x1)"
            >
              <Square className="w-4 h-4" />
            </button>
            <button
              onClick={() => setGridLayout('1x2')}
              className={`p-1.5 rounded ${
                gridLayout === '1x2' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Split View (1x2)"
            >
              <Columns className="w-4 h-4" />
            </button>
            <button
              onClick={() => setGridLayout('2x2')}
              className={`p-1.5 rounded ${
                gridLayout === '2x2' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Quad Matrix (2x2)"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Global Error Banner */}
      {globalError && (
        <div className="flex items-center space-x-3 p-3 rounded-xl bg-rose-950/70 border border-rose-800/80 text-rose-300 text-xs font-mono">
          <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-400" />
          <span>{globalError}</span>
        </div>
      )}

      {/* Camera Grid Display */}
      {devices.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-slate-900/40 border border-slate-800 space-y-3">
          <Camera className="w-10 h-10 mx-auto text-slate-600 animate-pulse" />
          <h3 className="text-base font-semibold text-slate-300">No Cameras Detected</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Please ensure your webcam or CCTV capture card is connected and you have granted camera permissions in your browser.
          </p>
          <button
            onClick={() => cameraService.refreshDevices()}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md transition"
          >
            Request Permission &amp; Scan
          </button>
        </div>
      ) : (
        <div
          className={`grid gap-4 ${
            gridLayout === '1x1'
              ? 'grid-cols-1'
              : gridLayout === '1x2'
              ? 'grid-cols-1 md:grid-cols-2'
              : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-2'
          }`}
        >
          {devices.map((device, index) => {
            const isOnline = device.status === 'online';
            const isConnecting = device.status === 'connecting' || connectingId === device.id;

            return (
              <div
                key={device.id}
                className="relative flex flex-col rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl transition hover:border-slate-700"
              >
                {/* Tile Header Bar */}
                <div className="flex items-center justify-between px-3.5 py-2.5 bg-slate-950/90 border-b border-slate-800/80 z-10">
                  <div className="flex items-center space-x-2 min-w-0">
                    <span
                      className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
                        isOnline
                          ? 'bg-emerald-400 animate-pulse ring-4 ring-emerald-500/20'
                          : isConnecting
                          ? 'bg-amber-400 animate-spin'
                          : 'bg-slate-600'
                      }`}
                    ></span>
                    <span className="text-xs font-semibold text-slate-200 truncate">
                      {device.label}
                    </span>
                    {device.isSimulated && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-purple-950 text-purple-300 border border-purple-800">
                        SYNTH
                      </span>
                    )}
                  </div>

                  <div className="flex items-center space-x-2 text-xs font-mono">
                    <span className="text-[11px] text-slate-400">
                      {isOnline ? 'LIVE' : device.status.toUpperCase()}
                    </span>

                    {/* Camera connect/disconnect toggle */}
                    <button
                      onClick={() => handleToggleCamera(device.id)}
                      disabled={isConnecting}
                      className={`px-2.5 py-1 rounded text-xs font-medium transition flex items-center space-x-1 ${
                        isOnline
                          ? 'bg-rose-950/80 text-rose-300 border border-rose-800 hover:bg-rose-900'
                          : 'bg-cyan-950/80 text-cyan-300 border border-cyan-800 hover:bg-cyan-900'
                      }`}
                    >
                      {isOnline ? (
                        <>
                          <VideoOff className="w-3 h-3" />
                          <span>Stop</span>
                        </>
                      ) : (
                        <>
                          <Video className="w-3 h-3" />
                          <span>{isConnecting ? 'Connecting...' : 'Start'}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Video Viewport Area */}
                <div className="relative aspect-video bg-slate-950 flex items-center justify-center overflow-hidden">
                  {/* Real HTML5 Video element */}
                  <video
                    ref={(el) => {
                      if (el) videoRefs.current.set(device.id, el);
                      else videoRefs.current.delete(device.id);
                    }}
                    autoPlay
                    playsInline
                    muted
                    className={`w-full h-full object-cover transition-opacity duration-300 ${
                      isOnline ? 'opacity-100' : 'opacity-0'
                    }`}
                  />

                  {/* Offline / Placeholder state */}
                  {!isOnline && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-b from-slate-950/80 to-slate-900/90">
                      {device.status === 'error' ? (
                        <>
                          <AlertTriangle className="w-8 h-8 text-rose-500 mb-2" />
                          <p className="text-xs text-rose-300 font-semibold mb-1">Stream Error</p>
                          <p className="text-[11px] text-slate-400 max-w-xs">{device.errorMessage}</p>
                          <div className="flex flex-wrap items-center justify-center gap-2 mt-3">
                            <button
                              onClick={() => handleToggleCamera(device.id)}
                              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700"
                            >
                              Retry Connection
                            </button>
                            <button
                              onClick={async () => {
                                const synth = devices.find((d) => d.isSimulated);
                                if (synth) {
                                  await cameraService.startCamera(synth.id);
                                }
                              }}
                              className="px-3 py-1.5 rounded-lg bg-cyan-700 hover:bg-cyan-600 text-xs font-semibold text-white shadow"
                            >
                              Start Zone-02 Test Feed
                            </button>
                          </div>
                        </>
                      ) : isConnecting ? (
                        <>
                          <RefreshCw className="w-8 h-8 text-amber-400 animate-spin mb-2" />
                          <p className="text-xs text-amber-300 font-medium">Negotiating Camera Stream...</p>
                        </>
                      ) : (
                        <>
                          <VideoOff className="w-8 h-8 text-slate-600 mb-2" />
                          <p className="text-xs text-slate-400 font-medium">Camera Feed Inactive</p>
                          <p className="text-[11px] text-slate-600 mb-3">Click Start to bind live media stream</p>
                          <button
                            onClick={() => handleToggleCamera(device.id)}
                            className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md transition"
                          >
                            Connect Camera
                          </button>
                        </>
                      )}
                    </div>
                  )}

                  {/* HUD Overlay when Online */}
                  {isOnline && (
                    <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between pointer-events-none">
                      <div className="bg-slate-950/80 backdrop-blur px-2 py-0.5 rounded text-[11px] font-mono text-cyan-300 border border-slate-800">
                        CAM #{index + 1} • {device.resolution}
                      </div>

                      <div className="flex items-center space-x-1 pointer-events-auto">
                        <button
                          onClick={() => handleCaptureSnapshot(device.id)}
                          className="p-1.5 rounded bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 shadow"
                          title="Capture Snapshot"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleFullscreen(device.id)}
                          className="p-1.5 rounded bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 shadow"
                          title="Fullscreen"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Tile Footer Telemetry */}
                <div className="flex items-center justify-between px-3 py-2 bg-slate-950/50 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
                  <div className="flex items-center space-x-2">
                    <Activity className="w-3 h-3 text-cyan-400" />
                    <span>State: {device.status.toUpperCase()}</span>
                  </div>
                  <span>{isOnline ? 'FPS: 30' : 'FPS: 0'}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
