import React, { useEffect, useState } from 'react';
import {
  FileSpreadsheet,
  FileText,
  Trash2,
  Search,
  Filter,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  AlertOctagon,
  AlertTriangle,
  Info,
  RefreshCw,
  PlusCircle,
} from 'lucide-react';
import { SafetyViolation } from '../types/vision';
import { storageService, DatabaseSummaryMetrics } from '../services/storage';

export const HistoryAnalyticsView: React.FC = () => {
  const [incidents, setIncidents] = useState<SafetyViolation[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState<'csv' | 'pdf' | null>(null);
  const [metrics, setMetrics] = useState<DatabaseSummaryMetrics>({
    totalIncidents: 0,
    criticalCount: 0,
    warningCount: 0,
    infoCount: 0,
    noHelmetCount: 0,
    noVestCount: 0,
    fallCount: 0,
    intrusionCount: 0,
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const paged = await storageService.getPagedIncidents({
        page: currentPage,
        pageSize,
        severity: severityFilter,
        type: typeFilter,
        search: searchQuery,
      });

      setIncidents(paged.items);
      setTotalCount(paged.total);
      setTotalPages(paged.totalPages);

      const summary = await storageService.getSummaryMetrics();
      setMetrics(summary);
    } catch (err) {
      console.warn('Error loading history incidents:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentPage, pageSize, severityFilter, typeFilter, searchQuery]);

  const handleExportCSV = async () => {
    try {
      setExporting('csv');
      await storageService.exportCSV();
    } catch (err: any) {
      alert(err.message || 'Export CSV failed');
    } finally {
      setExporting(null);
    }
  };

  const handleExportPDF = async () => {
    try {
      setExporting('pdf');
      await storageService.exportPDF();
    } catch (err: any) {
      alert(err.message || 'Export PDF failed');
    } finally {
      setExporting(null);
    }
  };

  const handleClearHistory = async () => {
    if (window.confirm('Are you sure you want to clear all logged safety incidents from the database?')) {
      await storageService.clearAll();
      setCurrentPage(1);
      await loadData();
    }
  };

  const handleSeedDemoRecords = async () => {
    const demoItems = [
      {
        type: 'NO_HELMET' as const,
        severity: 'WARNING' as const,
        description: 'Worker #101 entered heavy fabrication zone without mandatory hardhat',
        cameraName: 'CAM-01 Main Bay',
        personTrackId: 101,
      },
      {
        type: 'NO_VEST' as const,
        severity: 'WARNING' as const,
        description: 'Forklift operator assistant missing ANSI high-visibility vest',
        cameraName: 'CAM-02 Logistics',
        personTrackId: 104,
      },
      {
        type: 'FALL_DETECTED' as const,
        severity: 'CRITICAL' as const,
        description: 'Kinematic fall event: Worker #109 collapsed on slippery mezzanine platform',
        cameraName: 'CAM-03 Mezzanine',
        personTrackId: 109,
      },
      {
        type: 'ZONE_INTRUSION' as const,
        severity: 'CRITICAL' as const,
        description: 'Unauthorized tripwire crossing into high-voltage electrical substation zone',
        cameraName: 'CAM-04 Perimeter',
        personTrackId: 112,
      },
    ];

    for (const item of demoItems) {
      await storageService.logIncident(item);
    }
    await loadData();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-bold text-slate-100">Audit History &amp; Safety Incident Database</h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-emerald-950 text-emerald-400 border border-emerald-800/80">
              INDEXEDDB PERSISTENCE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real incident logs, deduplication filters, paginated tables, and certified export reports.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleSeedDemoRecords}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
            title="Seed verification records"
          >
            <PlusCircle className="w-3.5 h-3.5 text-cyan-400" />
            <span>Seed Test Log</span>
          </button>

          <button
            onClick={handleExportCSV}
            disabled={exporting !== null || metrics.totalIncidents === 0}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 text-xs font-semibold border border-emerald-800 transition disabled:opacity-50"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>{exporting === 'csv' ? 'Exporting...' : 'Export CSV'}</span>
          </button>

          <button
            onClick={handleExportPDF}
            disabled={exporting !== null || metrics.totalIncidents === 0}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-indigo-950 hover:bg-indigo-900 text-indigo-300 text-xs font-semibold border border-indigo-800 transition disabled:opacity-50"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{exporting === 'pdf' ? 'Exporting...' : 'Export PDF'}</span>
          </button>

          <button
            onClick={handleClearHistory}
            disabled={metrics.totalIncidents === 0}
            className="p-2 rounded-xl bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800 transition disabled:opacity-50"
            title="Clear all database history"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Summary Analytics Cards from Real Database */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Total Incidents</span>
          <div className="text-2xl font-black text-slate-100 mt-1">{metrics.totalIncidents}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Verified database records</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Critical Violations</span>
          <div className="text-2xl font-black text-rose-500 mt-1">{metrics.criticalCount}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Falls &amp; high risk events</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">PPE Violations</span>
          <div className="text-2xl font-black text-amber-400 mt-1">
            {metrics.noHelmetCount + metrics.noVestCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            {metrics.noHelmetCount} Hardhat • {metrics.noVestCount} Vest
          </div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Fall Emergencies</span>
          <div className="text-2xl font-black text-purple-400 mt-1">{metrics.fallCount}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Kinematic collapse alerts</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search description, camera, ID..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full bg-slate-950 text-slate-200 text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Severity & Type Dropdowns */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center space-x-1.5 text-xs font-mono text-slate-400">
            <Filter className="w-3.5 h-3.5" />
            <span>Severity:</span>
            <select
              value={severityFilter}
              onChange={(e) => {
                setSeverityFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-slate-950 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg border border-slate-800"
            >
              <option value="ALL">All Severities</option>
              <option value="CRITICAL">Critical</option>
              <option value="WARNING">Warning</option>
              <option value="INFO">Info</option>
            </select>
          </div>

          <div className="flex items-center space-x-1.5 text-xs font-mono text-slate-400">
            <span>Type:</span>
            <select
              value={typeFilter}
              onChange={(e) => {
                setTypeFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-slate-950 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg border border-slate-800"
            >
              <option value="ALL">All Types</option>
              <option value="NO_HELMET">No Helmet</option>
              <option value="NO_VEST">No Vest</option>
              <option value="FALL_DETECTED">Fall Detected</option>
              <option value="ZONE_INTRUSION">Zone Intrusion</option>
            </select>
          </div>
        </div>
      </div>

      {/* Incidents Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-4 py-3">Camera</th>
                <th className="px-4 py-3">Severity</th>
                <th className="px-4 py-3">Violation Type</th>
                <th className="px-4 py-3">Target ID</th>
                <th className="px-4 py-3">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-slate-500">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-cyan-400" />
                    <span>Loading incidents from database...</span>
                  </td>
                </tr>
              ) : incidents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-slate-500">
                    <ShieldAlert className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                    <p className="text-sm font-semibold text-slate-400">No Incidents Found</p>
                    <p className="text-xs text-slate-600 mt-1">
                      No violations matching the current filters were recorded in the database.
                    </p>
                  </td>
                </tr>
              ) : (
                incidents.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition">
                    <td className="px-4 py-3 whitespace-nowrap text-slate-400">
                      {new Date(item.timestamp).toLocaleString()}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-medium text-slate-200">
                      {item.cameraName}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.severity === 'CRITICAL'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : item.severity === 'WARNING'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-sky-950 text-sky-300 border border-sky-800'
                        }`}
                      >
                        {item.severity}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-bold text-slate-200">
                      {item.type}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-cyan-400">
                      {item.personTrackId ? `#${item.personTrackId}` : '—'}
                    </td>
                    <td className="px-4 py-3 text-slate-300 max-w-md font-sans">
                      {item.description}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between px-4 py-3 bg-slate-950/80 border-t border-slate-800 text-xs font-mono text-slate-400 gap-3">
          <div>
            Showing{' '}
            <span className="text-slate-200 font-bold">
              {totalCount === 0 ? 0 : (currentPage - 1) * pageSize + 1}
            </span>{' '}
            to{' '}
            <span className="text-slate-200 font-bold">
              {Math.min(totalCount, currentPage * pageSize)}
            </span>{' '}
            of <span className="text-slate-200 font-bold">{totalCount}</span> records
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span>
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
