import React, { useRef, useEffect } from 'react';

export type RobotEmotion =
  | 'HAPPY'
  | 'CURIOUS'
  | 'SURPRISED'
  | 'TALKING'
  | 'LISTENING'
  | 'THINKING'
  | 'SAD'
  | 'ANGRY'
  | 'SLEEPING'
  | 'SEARCHING';

interface LooiRobotCanvasProps {
  emotion: RobotEmotion;
  lookX: number; // -1.0 (left) to 1.0 (right)
  lookY: number; // -1.0 (up) to 1.0 (down)
  mouthAmplitude: number; // 0.0 to 1.0
  className?: string;
  onClick?: () => void;
}

export const LooiRobotCanvas: React.FC<LooiRobotCanvasProps> = ({
  emotion,
  lookX,
  lookY,
  mouthAmplitude,
  className = '',
  onClick,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Smooth interpolation states
  const currentLookXRef = useRef(0);
  const currentLookYRef = useRef(0);
  const blinkProgressRef = useRef(0); // 0 = open, 1 = closed
  const isBlinkingRef = useRef(false);
  const animTimeRef = useRef(0);

  // Automatic blinking timer
  useEffect(() => {
    let blinkTimeout: number;

    const triggerBlink = () => {
      if (!isBlinkingRef.current && emotion !== 'SLEEPING') {
        isBlinkingRef.current = true;
        const startTime = performance.now();
        const duration = 180; // ms

        const animateBlink = (now: number) => {
          const elapsed = now - startTime;
          const progress = Math.min(1, elapsed / duration);
          // Sine curve: 0 -> 1 -> 0
          blinkProgressRef.current = Math.sin(progress * Math.PI);

          if (progress < 1) {
            requestAnimationFrame(animateBlink);
          } else {
            blinkProgressRef.current = 0;
            isBlinkingRef.current = false;
          }
        };
        requestAnimationFrame(animateBlink);
      }

      const nextInterval = 2500 + Math.random() * 3500;
      blinkTimeout = window.setTimeout(triggerBlink, nextInterval);
    };

    blinkTimeout = window.setTimeout(triggerBlink, 2000);
    return () => clearTimeout(blinkTimeout);
  }, [emotion]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      animTimeRef.current += 0.04;
      const t = animTimeRef.current;

      // Resize canvas to match display size cleanly
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const displayWidth = Math.round(rect.width * dpr);
      const displayHeight = Math.round(rect.height * dpr);

      if (canvas.width !== displayWidth || canvas.height !== displayHeight) {
        canvas.width = displayWidth;
        canvas.height = displayHeight;
      }

      ctx.save();
      ctx.scale(dpr, dpr);

      const w = rect.width;
      const h = rect.height;

      // 1. Fill deep glossy robot screen
      ctx.fillStyle = '#080C14';
      ctx.fillRect(0, 0, w, h);

      // Subtle background grid / tech scanlines
      ctx.fillStyle = 'rgba(0, 242, 254, 0.02)';
      for (let y = 0; y < h; y += 4) {
        ctx.fillRect(0, y, w, 1);
      }

      // Smooth gaze tracking filter (EMA low-pass)
      let targetX = lookX;
      let targetY = lookY;

      // If in SEARCHING state, autonomous wandering sweep
      if (emotion === 'SEARCHING') {
        targetX = Math.sin(t * 0.9) * 0.7;
        targetY = Math.cos(t * 0.6) * 0.25;
      }

      currentLookXRef.current += (targetX - currentLookXRef.current) * 0.22;
      currentLookYRef.current += (targetY - currentLookYRef.current) * 0.22;

      const smoothLookX = currentLookXRef.current;
      const smoothLookY = currentLookYRef.current;

      // Breathing bounce
      const bounce = Math.sin(t * 1.5) * 4;
      const cx = w / 2;
      const cy = h / 2 - 15 + bounce;

      // Eye dimensions proportional to canvas
      const eyeSpacing = w * 0.24;
      const eyeRx = w * 0.15;
      const eyeRy = eyeRx * 1.28;

      const leftCx = cx - eyeSpacing;
      const rightCx = cx + eyeSpacing;

      // 2. Blush Cheeks (for Happy or Talking)
      if (emotion === 'HAPPY' || emotion === 'TALKING') {
        const blushR = eyeRx * 0.55;
        const blushGrad = ctx.createRadialGradient(
          leftCx - eyeRx * 0.7,
          cy + eyeRy * 0.85,
          0,
          leftCx - eyeRx * 0.7,
          cy + eyeRy * 0.85,
          blushR
        );
        blushGrad.addColorStop(0, 'rgba(255, 75, 114, 0.35)');
        blushGrad.addColorStop(1, 'rgba(255, 75, 114, 0)');
        ctx.fillStyle = blushGrad;
        ctx.beginPath();
        ctx.arc(leftCx - eyeRx * 0.7, cy + eyeRy * 0.85, blushR, 0, Math.PI * 2);
        ctx.fill();

        const rightBlush = ctx.createRadialGradient(
          rightCx + eyeRx * 0.7,
          cy + eyeRy * 0.85,
          0,
          rightCx + eyeRx * 0.7,
          cy + eyeRy * 0.85,
          blushR
        );
        rightBlush.addColorStop(0, 'rgba(255, 75, 114, 0.35)');
        rightBlush.addColorStop(1, 'rgba(255, 75, 114, 0)');
        ctx.fillStyle = rightBlush;
        ctx.beginPath();
        ctx.arc(rightCx + eyeRx * 0.7, cy + eyeRy * 0.85, blushR, 0, Math.PI * 2);
        ctx.fill();
      }

      // 3. Eyebrows
      drawEyebrows(ctx, leftCx, rightCx, cy - eyeRy * 1.15, eyeRx, emotion);

      // 4. Draw Left and Right Robotic Eyes
      drawEye(ctx, leftCx, cy, eyeRx, eyeRy, smoothLookX, smoothLookY, blinkProgressRef.current, emotion, true);
      drawEye(ctx, rightCx, cy, eyeRx, eyeRy, smoothLookX, smoothLookY, blinkProgressRef.current, emotion, false);

      // 5. Draw Animated Mouth
      drawMouth(ctx, cx, cy + eyeRy * 1.35, eyeRx, emotion, mouthAmplitude, t);

      // 6. Overlays: Thinking orbits or Listening waves
      if (emotion === 'THINKING') {
        drawThinkingOrbits(ctx, cx, cy, eyeSpacing * 1.85, t);
      } else if (emotion === 'LISTENING') {
        drawListeningWaveform(ctx, cx, cy + eyeRy * 1.9, t);
      }

      ctx.restore();
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [emotion, lookX, lookY, mouthAmplitude]);

  return (
    <div className={`relative w-full h-full flex items-center justify-center select-none ${className}`} onClick={onClick}>
      <canvas ref={canvasRef} className="w-full h-full block cursor-pointer" />
    </div>
  );
};

// Helper: draw single robotic eye with glowing bezel, iris, and independent pupil
function drawEye(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  lookX: number,
  lookY: number,
  blinkProgress: number,
  emotion: RobotEmotion,
  isLeft: boolean
) {
  ctx.save();

  // Sleeping state: gentle cute curved eyelids
  if (emotion === 'SLEEPING') {
    ctx.strokeStyle = '#00F2FE';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(cx, cy - ry * 0.1, rx * 0.7, 0.1 * Math.PI, 0.9 * Math.PI, false);
    ctx.stroke();
    ctx.restore();
    return;
  }

  let scaleY = 1.0 - blinkProgress;
  let scaleX = 1.0;

  if (emotion === 'SURPRISED') {
    scaleX = 1.15;
    scaleY = Math.max(scaleY, 1.25 * (1.0 - blinkProgress));
  } else if (emotion === 'SAD') {
    scaleY = Math.max(0.1, scaleY * 0.75);
  } else if (emotion === 'ANGRY') {
    scaleY = Math.max(0.1, scaleY * 0.7);
  }

  // Draw eye outer glow
  ctx.shadowColor = '#00F2FE';
  ctx.shadowBlur = 18;

  // Eye background oval
  ctx.fillStyle = '#00F2FE';
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx * scaleX, ry * scaleY, 0, 0, Math.PI * 2);
  ctx.fill();

  // Outer bezel border
  ctx.shadowBlur = 0;
  ctx.strokeStyle = '#4FACFE';
  ctx.lineWidth = 4;
  ctx.stroke();

  // Clip inside eye for pupil movement
  ctx.save();
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx * scaleX, ry * scaleY, 0, 0, Math.PI * 2);
  ctx.clip();

  // Pupil position tracking
  const maxShiftX = rx * 0.44;
  const maxShiftY = ry * 0.38;
  const pupilCx = cx + lookX * maxShiftX;
  const pupilCy = cy + lookY * maxShiftY;
  const pupilR = rx * 0.45;

  // Dark iris ring
  ctx.fillStyle = '#072C3E';
  ctx.beginPath();
  ctx.arc(pupilCx, pupilCy, pupilR * 1.15, 0, Math.PI * 2);
  ctx.fill();

  // White glowing pupil core
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(pupilCx, pupilCy, pupilR * 0.72, 0, Math.PI * 2);
  ctx.fill();

  // Anime catchlight highlights
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(pupilCx - pupilR * 0.35, pupilCy - pupilR * 0.35, pupilR * 0.28, 0, Math.PI * 2);
  ctx.fill();

  ctx.beginPath();
  ctx.arc(pupilCx + pupilR * 0.36, pupilCy + pupilR * 0.32, pupilR * 0.14, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
  ctx.restore();
}

// Helper: Eyebrows
function drawEyebrows(
  ctx: CanvasRenderingContext2D,
  leftX: number,
  rightX: number,
  y: number,
  rx: number,
  emotion: RobotEmotion
) {
  const browW = rx * 0.95;
  ctx.save();
  ctx.strokeStyle = '#38BDF8';
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';

  let leftTilt = 0;
  let rightTilt = 0;

  if (emotion === 'ANGRY') {
    leftTilt = 16;
    rightTilt = -16;
  } else if (emotion === 'SAD') {
    leftTilt = -14;
    rightTilt = 14;
  } else if (emotion === 'SURPRISED') {
    leftTilt = -8;
    rightTilt = -8;
  } else if (emotion === 'CURIOUS') {
    leftTilt = -12;
    rightTilt = 6;
  }

  // Left Brow
  ctx.beginPath();
  ctx.moveTo(leftX - browW / 2, y + leftTilt);
  ctx.quadraticCurveTo(leftX, y - 6, leftX + browW / 2, y - leftTilt);
  ctx.stroke();

  // Right Brow
  ctx.beginPath();
  ctx.moveTo(rightX - browW / 2, y - rightTilt);
  ctx.quadraticCurveTo(rightX, y - 6, rightX + browW / 2, y + rightTilt);
  ctx.stroke();

  ctx.restore();
}

// Helper: Animated mouth with lip-sync
function drawMouth(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rx: number,
  emotion: RobotEmotion,
  amplitude: number,
  t: number
) {
  ctx.save();
  const mouthW = rx * 0.95;
  ctx.strokeStyle = '#00F2FE';
  ctx.fillStyle = '#00F2FE';
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';

  if (emotion === 'TALKING') {
    // Lip sync driven by audio amplitude
    const openH = 10 + amplitude * 36;
    ctx.shadowColor = '#00F2FE';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.ellipse(cx, cy, mouthW * 0.45, openH * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (emotion === 'HAPPY') {
    ctx.beginPath();
    ctx.moveTo(cx - mouthW * 0.55, cy);
    ctx.quadraticCurveTo(cx, cy + 22, cx + mouthW * 0.55, cy);
    ctx.stroke();
  } else if (emotion === 'SURPRISED') {
    ctx.beginPath();
    ctx.arc(cx, cy + 6, 16, 0, Math.PI * 2);
    ctx.stroke();
  } else if (emotion === 'SAD') {
    ctx.beginPath();
    ctx.moveTo(cx - mouthW * 0.5, cy + 14);
    ctx.quadraticCurveTo(cx, cy - 2, cx + mouthW * 0.5, cy + 14);
    ctx.stroke();
  } else if (emotion === 'ANGRY') {
    ctx.beginPath();
    ctx.moveTo(cx - mouthW * 0.45, cy + 8);
    ctx.lineTo(cx + mouthW * 0.45, cy + 8);
    ctx.stroke();
  } else if (emotion === 'SLEEPING') {
    ctx.beginPath();
    ctx.moveTo(cx - 14, cy + 6);
    ctx.lineTo(cx + 14, cy + 6);
    ctx.stroke();

    // Floating ZZZ
    ctx.font = 'bold 16px monospace';
    ctx.fillStyle = '#38BDF8';
    const zOffset = (t * 20) % 40;
    ctx.fillText('z', cx + 35, cy - 20 - zOffset * 0.5);
    ctx.fillText('Z', cx + 45, cy - 35 - zOffset * 0.7);
  } else {
    // Idle gentle smile
    ctx.beginPath();
    ctx.moveTo(cx - mouthW * 0.4, cy);
    ctx.quadraticCurveTo(cx + 4, cy + 12, cx + mouthW * 0.4, cy + 2);
    ctx.stroke();
  }

  ctx.restore();
}

// Thinking revolving orbit particles
function drawThinkingOrbits(ctx: CanvasRenderingContext2D, cx: number, cy: number, radius: number, t: number) {
  ctx.save();
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
  ctx.lineWidth = 2;
  ctx.setLineDash([6, 6]);
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.stroke();

  const angle = t * 2.8;
  const dotX = cx + Math.cos(angle) * radius;
  const dotY = cy + Math.sin(angle) * radius;

  ctx.shadowColor = '#00F2FE';
  ctx.shadowBlur = 12;
  ctx.fillStyle = '#00F2FE';
  ctx.beginPath();
  ctx.arc(dotX, dotY, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// Listening waveform bars
function drawListeningWaveform(ctx: CanvasRenderingContext2D, cx: number, cy: number, t: number) {
  ctx.save();
  ctx.strokeStyle = '#00F2FE';
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';

  const count = 7;
  const spacing = 14;
  const startX = cx - ((count - 1) * spacing) / 2;

  for (let i = 0; i < count; i++) {
    const x = startX + i * spacing;
    const waveH = 6 + Math.abs(Math.sin(t * 5 + i * 0.8)) * 26;
    ctx.beginPath();
    ctx.moveTo(x, cy - waveH / 2);
    ctx.lineTo(x, cy + waveH / 2);
    ctx.stroke();
  }
  ctx.restore();
}
