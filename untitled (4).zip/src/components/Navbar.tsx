import React from 'react';
import {
  Video,
  ShieldAlert,
  Crosshair,
  FileSpreadsheet,
  Mic,
  Settings,
  Cpu,
  BatteryCharging,
  Zap,
} from 'lucide-react';
import { ModelLoadingStatus } from '../types/vision';

interface NavbarProps {
  activeTab: 'cctv' | 'safety' | 'tracking' | 'history' | 'assistant';
  onSelectTab: (tab: 'cctv' | 'safety' | 'tracking' | 'history' | 'assistant') => void;
  modelStatus: ModelLoadingStatus;
  onlineCamerasCount: number;
  batterySaver: boolean;
  onOpenSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  modelStatus,
  onlineCamerasCount,
  batterySaver,
  onOpenSettings,
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-cyan-600 via-sky-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 ring-1 ring-cyan-400/40">
            <Crosshair className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold text-base tracking-wide bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-300 bg-clip-text text-transparent">
                AI VISION LAB
              </span>
              <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-800/60 text-cyan-300 font-bold">
                v2.5 PRO
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono hidden sm:block">
              Intelligent Vision &amp; Tracking System
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center space-x-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => onSelectTab('cctv')}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'cctv'
                ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Video className="w-4 h-4" />
            <span>CCTV Monitoring</span>
          </button>

          <button
            onClick={() => onSelectTab('safety')}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'safety'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Safety &amp; PPE</span>
          </button>

          <button
            onClick={() => onSelectTab('tracking')}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'tracking'
                ? 'bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Crosshair className="w-4 h-4" />
            <span>ByteTrack</span>
          </button>

          <button
            onClick={() => onSelectTab('history')}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'history'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Incidents &amp; Logs</span>
          </button>

          <button
            onClick={() => onSelectTab('assistant')}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'assistant'
                ? 'bg-purple-500/15 text-purple-400 border border-purple-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>Voice AI</span>
          </button>
        </nav>

        {/* Telemetry & Controls */}
        <div className="flex items-center space-x-3">
          {/* AI Engine Status Badge */}
          <div className="hidden sm:flex items-center space-x-2 px-2.5 py-1 rounded-full text-xs font-mono border border-slate-800 bg-slate-900/60">
            <Cpu className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">AI:</span>
            {modelStatus === 'ready' && (
              <span className="text-emerald-400 flex items-center gap-1 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                ACTIVE
              </span>
            )}
            {modelStatus === 'loading' && (
              <span className="text-amber-400 flex items-center gap-1 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-spin"></span>
                LOADING
              </span>
            )}
            {modelStatus === 'error' && (
              <span className="text-rose-400 flex items-center gap-1 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                OFFLINE
              </span>
            )}
            {modelStatus === 'unloaded' && (
              <span className="text-slate-500 font-medium">STANDBY</span>
            )}
          </div>

          {/* Active Cameras Status */}
          <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-mono border border-slate-800 bg-slate-900/60">
            <span
              className={`w-2 h-2 rounded-full ${
                onlineCamerasCount > 0 ? 'bg-cyan-400 animate-ping' : 'bg-slate-600'
              }`}
            ></span>
            <span className="text-slate-300 font-semibold">{onlineCamerasCount} CAM</span>
          </div>

          {/* Battery Saver Indicator */}
          {batterySaver && (
            <div className="hidden sm:flex items-center space-x-1 px-2 py-1 rounded bg-amber-950/60 border border-amber-800/60 text-amber-300 text-[11px] font-mono">
              <BatteryCharging className="w-3.5 h-3.5" />
              <span>SAVER</span>
            </div>
          )}

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition border border-slate-800"
            title="System Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mobile subnav */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800/80 bg-slate-950 px-2 py-2">
        <button
          onClick={() => onSelectTab('cctv')}
          className={`p-2 rounded flex flex-col items-center text-[10px] ${
            activeTab === 'cctv' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Video className="w-4 h-4 mb-0.5" />
          <span>CCTV</span>
        </button>
        <button
          onClick={() => onSelectTab('safety')}
          className={`p-2 rounded flex flex-col items-center text-[10px] ${
            activeTab === 'safety' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <ShieldAlert className="w-4 h-4 mb-0.5" />
          <span>Safety</span>
        </button>
        <button
          onClick={() => onSelectTab('tracking')}
          className={`p-2 rounded flex flex-col items-center text-[10px] ${
            activeTab === 'tracking' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Crosshair className="w-4 h-4 mb-0.5" />
          <span>Track</span>
        </button>
        <button
          onClick={() => onSelectTab('history')}
          className={`p-2 rounded flex flex-col items-center text-[10px] ${
            activeTab === 'history' ? 'text-emerald-400 font-bold' : 'text-slate-400'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 mb-0.5" />
          <span>Logs</span>
        </button>
        <button
          onClick={() => onSelectTab('assistant')}
          className={`p-2 rounded flex flex-col items-center text-[10px] ${
            activeTab === 'assistant' ? 'text-purple-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Mic className="w-4 h-4 mb-0.5" />
          <span>Voice</span>
        </button>
      </div>
    </header>
  );
};
