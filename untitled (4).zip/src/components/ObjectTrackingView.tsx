import React, { useEffect, useRef, useState } from 'react';
import {
  Crosshair,
  Activity,
  RotateCcw,
  Sliders,
  TrendingUp,
  Camera,
  Layers,
  ArrowRightLeft,
} from 'lucide-react';
import { CameraDevice, ModelLoadingStatus, TrackedTarget, ZoneCrossingStats } from '../types/vision';
import { detectorService } from '../services/detector';
import { byteTracker } from '../services/tracker';
import { cameraService } from '../services/cameraService';
import { settingsService } from '../services/settings';

export const ObjectTrackingView: React.FC = () => {
  const [devices, setDevices] = useState<CameraDevice[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [modelStatus, setModelStatus] = useState<ModelLoadingStatus>('loading');
  const [activeTracks, setActiveTracks] = useState<TrackedTarget[]>([]);
  const [tripwireY, setTripwireY] = useState<number>(0.55); // 55% from top
  const [crossings, setCrossings] = useState<ZoneCrossingStats>({
    inbound: 0,
    outbound: 0,
    totalCrossings: 0,
  });

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameIdRef = useRef<number | null>(null);

  // Track previous Y positions of targets for crossing detection
  const previousYMapRef = useRef<Map<number, number>>(new Map());

  useEffect(() => {
    const unsubDevices = cameraService.onDevicesChange((devs) => {
      setDevices(devs);
      if (!selectedCameraId && devs.length > 0) {
        const online = devs.find((d) => d.status === 'online');
        setSelectedCameraId(online ? online.id : devs[0].id);
      }
    });

    const unsubSettings = settingsService.subscribe((s) => {
      setTripwireY(s.tripwireYPercent);
    });

    const unsubDetector = detectorService.onStatusChange((st) => {
      setModelStatus(st);
    });

    detectorService.loadModel().catch((e) => console.warn('Detector init:', e));

    return () => {
      unsubDevices();
      unsubSettings();
      unsubDetector();
    };
  }, [selectedCameraId]);

  const currentCamera = devices.find((d) => d.id === selectedCameraId);

  useEffect(() => {
    if (videoRef.current) {
      if (currentCamera && currentCamera.stream && currentCamera.status === 'online') {
        if (videoRef.current.srcObject !== currentCamera.stream) {
          videoRef.current.srcObject = currentCamera.stream;
          videoRef.current.play().catch((e) => console.warn('Video play error:', e));
        }
      } else {
        videoRef.current.srcObject = null;
      }
    }
  }, [currentCamera]);

  // Main Tracking Loop
  useEffect(() => {
    let isCancelled = false;
    let lastTime = 0;

    const loop = async () => {
      if (isCancelled) return;

      const video = videoRef.current;
      const canvas = canvasRef.current;
      const now = performance.now();
      const settings = settingsService.getSettings();
      const frameInterval = 1000 / (settings.batterySaver ? 8 : 20);

      if (
        video &&
        canvas &&
        video.readyState >= 2 &&
        video.videoWidth > 0 &&
        video.videoHeight > 0 &&
        modelStatus === 'ready' &&
        now - lastTime >= frameInterval
      ) {
        lastTime = now;

        if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
        }

        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Render video frame
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

          // 1. Detect raw objects
          const rawDetections = await detectorService.detect(canvas, settings.confidenceThreshold);

          // 2. Associate with ByteTrack
          const tracks = byteTracker.update(rawDetections);
          setActiveTracks(tracks);

          // 3. Process Tripwire Line Crossing
          const wirePixelY = canvas.height * tripwireY;
          for (const t of tracks) {
            const centerY = t.bbox[1] + t.bbox[3] / 2;
            const prevY = previousYMapRef.current.get(t.id);

            if (prevY !== undefined) {
              // Crossed downwards (North -> South = Inbound)
              if (prevY < wirePixelY && centerY >= wirePixelY) {
                setCrossings((prev) => ({
                  inbound: prev.inbound + 1,
                  outbound: prev.outbound,
                  totalCrossings: prev.totalCrossings + 1,
                }));
              }
              // Crossed upwards (South -> North = Outbound)
              else if (prevY > wirePixelY && centerY <= wirePixelY) {
                setCrossings((prev) => ({
                  inbound: prev.inbound,
                  outbound: prev.outbound + 1,
                  totalCrossings: prev.totalCrossings + 1,
                }));
              }
            }
            previousYMapRef.current.set(t.id, centerY);
          }

          // 4. Draw Augmented Tracking Graphics
          drawTrackingScene(ctx, tracks, canvas.width, canvas.height, wirePixelY);
        }
      }

      animationFrameIdRef.current = requestAnimationFrame(loop);
    };

    animationFrameIdRef.current = requestAnimationFrame(loop);

    return () => {
      isCancelled = true;
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
    };
  }, [modelStatus, currentCamera, tripwireY]);

  const drawTrackingScene = (
    ctx: CanvasRenderingContext2D,
    tracks: TrackedTarget[],
    width: number,
    height: number,
    wireY: number
  ) => {
    // 1. Draw Tripwire Line
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.setLineDash([8, 6]);
    ctx.beginPath();
    ctx.moveTo(0, wireY);
    ctx.lineTo(width, wireY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Tripwire HUD tag
    ctx.fillStyle = '#0284c7';
    ctx.fillRect(10, wireY - 20, 140, 20);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px monospace';
    ctx.fillText('⚡ TRIPWIRE COUNTING', 16, wireY - 6);

    // 2. Draw Tracked Targets
    for (const t of tracks) {
      const [x, y, w, h] = t.bbox;
      const color = t.color;

      // Draw Trajectory Trail
      if (t.history.length > 1) {
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(t.history[0].x, t.history[0].y);
        for (let i = 1; i < t.history.length; i++) {
          ctx.lineTo(t.history[i].x, t.history[i].y);
        }
        ctx.stroke();
      }

      // Bounding box
      ctx.strokeStyle = color;
      ctx.lineWidth = 2.5;
      ctx.strokeRect(x, y, w, h);

      // Center crosshair
      const cx = x + w / 2;
      const cy = y + h / 2;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(cx, cy, 4, 0, Math.PI * 2);
      ctx.fill();

      // Velocity Vector Arrow
      if (t.velocity.speed > 5) {
        const arrowLen = Math.min(60, t.velocity.speed * 0.2);
        const angle = Math.atan2(t.velocity.vy, t.velocity.vx);
        const endX = cx + Math.cos(angle) * arrowLen;
        const endY = cy + Math.sin(angle) * arrowLen;

        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(endX, endY);
        ctx.stroke();

        // Arrow head
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(endX, endY, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // ID & Speed Badge
      const badgeText = `ID #${t.id} ${t.class.toUpperCase()} | ${Math.round(t.score * 100)}% | ${t.velocity.speed}px/s`;
      ctx.fillStyle = 'rgba(2, 6, 23, 0.85)';
      ctx.fillRect(x, Math.max(0, y - 22), ctx.measureText(badgeText).width + 12, 22);
      ctx.fillStyle = color;
      ctx.font = 'bold 11px monospace';
      ctx.fillText(badgeText, x + 6, Math.max(15, y - 6));
    }
  };

  const handleResetTracker = () => {
    byteTracker.reset();
    previousYMapRef.current.clear();
    setCrossings({ inbound: 0, outbound: 0, totalCrossings: 0 });
    setActiveTracks([]);
  };

  const handleStartCamera = async () => {
    if (selectedCameraId) {
      try {
        await cameraService.startCamera(selectedCameraId);
      } catch (e) {
        console.warn('Failed to start camera:', e);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-bold text-slate-100">ByteTrack Multi-Object Tracking &amp; Kinematics</h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-indigo-950 text-indigo-400 border border-indigo-800/80">
              2-STAGE IOU &amp; OCCLUSION RECOVERY
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time object association, velocity vector projection, and tripwire directional counting.
          </p>
        </div>

        {/* Source Switcher & Reset */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedCameraId}
            onChange={(e) => setSelectedCameraId(e.target.value)}
            className="bg-slate-950 text-slate-200 text-xs font-mono px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.label} {d.status === 'online' ? '(ONLINE)' : '(OFFLINE)'}
              </option>
            ))}
          </select>

          {currentCamera?.status !== 'online' && (
            <button
              onClick={handleStartCamera}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow"
            >
              Start Feed
            </button>
          )}

          <button
            onClick={handleResetTracker}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
            title="Reset ByteTrack Object IDs and Counter"
          >
            <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
            <span>Reset IDs</span>
          </button>
        </div>
      </div>

      {/* Analytics Summary Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Active Targets</span>
          <div className="text-2xl font-black text-cyan-400 mt-1">{activeTracks.length}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Currently in frame</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Inbound Crossings</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">{crossings.inbound}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">North → South flow</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Outbound Crossings</span>
          <div className="text-2xl font-black text-indigo-400 mt-1">{crossings.outbound}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">South → North flow</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Total Tripwire Count</span>
          <div className="text-2xl font-black text-amber-400 mt-1">{crossings.totalCrossings}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Net zone flow</div>
        </div>
      </div>

      {/* Main Tracking Canvas Viewport */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 relative aspect-video bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl flex items-center justify-center">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="absolute inset-0 w-full h-full object-cover"
          />

          <canvas
            ref={canvasRef}
            className="relative w-full h-full object-cover pointer-events-none"
          />

          {currentCamera?.status !== 'online' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/90 text-center p-6 z-20">
              {currentCamera?.status === 'error' ? (
                <>
                  <Camera className="w-10 h-10 text-rose-500 mb-2" />
                  <p className="text-sm font-semibold text-rose-300">Camera Source Error</p>
                  <p className="text-xs text-slate-400 max-w-md mb-4 mt-1">
                    {currentCamera.errorMessage || 'Could not start hardware video source.'}
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      onClick={handleStartCamera}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
                    >
                      Retry Camera
                    </button>
                    <button
                      onClick={async () => {
                        const synth = devices.find((d) => d.isSimulated);
                        if (synth) {
                          setSelectedCameraId(synth.id);
                          await cameraService.startCamera(synth.id);
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow"
                    >
                      Switch to Zone-02 Test Feed
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <Camera className="w-10 h-10 text-slate-600 mb-2" />
                  <p className="text-sm font-semibold text-slate-300">Selected Camera Inactive</p>
                  <p className="text-xs text-slate-500 max-w-sm mb-4">
                    Connect the camera stream to observe ByteTrack continuous tracking and velocity vectors.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      onClick={handleStartCamera}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow"
                    >
                      Start Feed
                    </button>
                    <button
                      onClick={async () => {
                        const synth = devices.find((d) => d.isSimulated);
                        if (synth) {
                          setSelectedCameraId(synth.id);
                          await cameraService.startCamera(synth.id);
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold border border-slate-700 transition"
                    >
                      Use Test CCTV Stream
                    </button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Floating Tripwire Slider */}
          <div className="absolute bottom-3 left-3 right-3 bg-slate-950/80 backdrop-blur p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-4 text-xs font-mono text-slate-300 z-10">
            <div className="flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Tripwire Y-Position: {Math.round(tripwireY * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="0.9"
              step="0.05"
              value={tripwireY}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setTripwireY(val);
                settingsService.updateSettings({ tripwireYPercent: val });
              }}
              className="w-40 sm:w-64 accent-cyan-400 cursor-pointer"
            />
          </div>
        </div>

        {/* Live Active Tracks Table */}
        <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-4 flex flex-col h-[400px] lg:h-auto">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Crosshair className="w-4 h-4 text-indigo-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Active Track Registry
              </h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
              {activeTracks.length} TRACKED
            </span>
          </div>

          <div className="flex-1 overflow-y-auto mt-3 pr-1 space-y-2">
            {activeTracks.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                <Crosshair className="w-8 h-8 text-slate-600 mb-2" />
                <p className="text-xs font-semibold text-slate-400">No Active Objects In Zone</p>
                <p className="text-[11px] text-slate-600 mt-1">
                  Objects detected in video will be assigned unique trajectory IDs without ID switching.
                </p>
              </div>
            ) : (
              activeTracks.map((t) => (
                <div
                  key={t.id}
                  className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between text-xs font-mono"
                >
                  <div className="flex items-center space-x-2.5">
                    <span
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ backgroundColor: t.color }}
                    ></span>
                    <div>
                      <div className="font-bold text-slate-200">
                        Target #{t.id}{' '}
                        <span className="text-[10px] text-slate-400 uppercase font-normal">
                          ({t.class})
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500">
                        Age: {t.age} frames • Conf: {Math.round(t.score * 100)}%
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-cyan-400 font-bold">{t.velocity.speed} px/s</div>
                    <div className="text-[10px] text-slate-500">
                      vx:{Math.round(t.velocity.vx)} vy:{Math.round(t.velocity.vy)}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
