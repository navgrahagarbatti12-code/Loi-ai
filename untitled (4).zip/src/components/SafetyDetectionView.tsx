import React, { useEffect, useRef, useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  HardHat,
  Eye,
  RefreshCw,
  Sparkles,
  Camera,
  Layers,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { CameraDevice, ModelLoadingStatus, SafetyMetrics, SafetyViolation, TrackedTarget } from '../types/vision';
import { detectorService } from '../services/detector';
import { byteTracker } from '../services/tracker';
import { safetyService } from '../services/safetyService';
import { settingsService } from '../services/settings';
import { cameraService } from '../services/cameraService';

export const SafetyDetectionView: React.FC = () => {
  const [devices, setDevices] = useState<CameraDevice[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [modelStatus, setModelStatus] = useState<ModelLoadingStatus>('loading');
  const [metrics, setMetrics] = useState<SafetyMetrics>({
    personsDetected: 0,
    helmetCompliant: 0,
    vestCompliant: 0,
    fallsDetected: 0,
    complianceRate: 100,
    violationsCount: 0,
    isModelLoaded: false,
    modelStatus: 'loading',
  });
  const [recentViolations, setRecentViolations] = useState<SafetyViolation[]>([]);
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResult, setAuditResult] = useState<any | null>(null);
  const [audioAlerts, setAudioAlerts] = useState<boolean>(true);
  const [confidenceThresh, setConfidenceThresh] = useState<number>(0.45);

  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameIdRef = useRef<number | null>(null);

  // Subscribe to devices & settings
  useEffect(() => {
    const unsubDevices = cameraService.onDevicesChange((devs) => {
      setDevices(devs);
      if (!selectedCameraId && devs.length > 0) {
        // Auto-select first online camera or first device
        const online = devs.find((d) => d.status === 'online');
        setSelectedCameraId(online ? online.id : devs[0].id);
      }
    });

    const unsubSettings = settingsService.subscribe((s) => {
      setAudioAlerts(s.audioAlerts);
      setConfidenceThresh(s.confidenceThreshold);
    });

    const unsubDetector = detectorService.onStatusChange((st) => {
      setModelStatus(st);
    });

    // Ensure detector model is loaded
    detectorService.loadModel().catch((err) => {
      console.warn('Detector model load error:', err);
    });

    return () => {
      unsubDevices();
      unsubSettings();
      unsubDetector();
    };
  }, [selectedCameraId]);

  // Handle camera binding to video element
  const currentCamera = devices.find((d) => d.id === selectedCameraId);

  useEffect(() => {
    if (videoRef.current) {
      if (currentCamera && currentCamera.stream && currentCamera.status === 'online') {
        if (videoRef.current.srcObject !== currentCamera.stream) {
          videoRef.current.srcObject = currentCamera.stream;
          videoRef.current.play().catch((e) => console.warn('Video play error:', e));
        }
      } else {
        videoRef.current.srcObject = null;
      }
    }
  }, [currentCamera]);

  // Main Detection & Inspection Loop
  useEffect(() => {
    let isCancelled = false;
    let lastFrameTime = 0;

    const processFrame = async () => {
      if (isCancelled) return;

      const video = videoRef.current;
      const canvas = overlayCanvasRef.current;

      // Throttle inference frame rate based on settings (e.g. 6-15 FPS)
      const now = performance.now();
      const settings = settingsService.getSettings();
      const frameInterval = 1000 / (settings.batterySaver ? 6 : 15);

      if (
        video &&
        canvas &&
        video.readyState >= 2 &&
        video.videoWidth > 0 &&
        video.videoHeight > 0 &&
        modelStatus === 'ready' &&
        now - lastFrameTime >= frameInterval
      ) {
        lastFrameTime = now;

        // Match overlay canvas size to video aspect ratio
        if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
        }

        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Render current video frame to canvas FIRST before any inspection or getImageData calls
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

          // 1. Detect objects (persons, gear)
          const detections = await detectorService.detect(canvas, confidenceThresh);
          const personDetections = detections.filter((d) => d.class === 'person');

          // 2. Track persons with ByteTrack
          const trackedPersons = byteTracker.update(personDetections);

          // 3. Inspect PPE & Posture on the rendered canvas frame
          const cameraLabel = currentCamera?.label || 'Active Surveillance';
          const { metrics: updatedMetrics, currentViolations } = safetyService.inspectFrame(
            canvas,
            trackedPersons,
            cameraLabel
          );

          setMetrics(updatedMetrics);

          if (currentViolations.length > 0) {
            setRecentViolations((prev) => [...currentViolations, ...prev].slice(0, 10));
          }

          // 4. Draw Augmented Reality Safety Overlays on canvas
          drawSafetyOverlays(ctx, trackedPersons, currentViolations);
        }
      }

      animationFrameIdRef.current = requestAnimationFrame(processFrame);
    };

    animationFrameIdRef.current = requestAnimationFrame(processFrame);

    return () => {
      isCancelled = true;
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
    };
  }, [modelStatus, currentCamera, confidenceThresh]);

  // Draw Bounding Boxes and Telemetry on the overlay canvas
  const drawSafetyOverlays = (
    ctx: CanvasRenderingContext2D,
    persons: TrackedTarget[],
    violations: SafetyViolation[]
  ) => {
    for (const p of persons) {
      const [x, y, w, h] = p.bbox;
      const isFallen = violations.some((v) => v.personTrackId === p.id && v.type === 'FALL_DETECTED');
      const missingHelmet = violations.some((v) => v.personTrackId === p.id && v.type === 'NO_HELMET');
      const missingVest = violations.some((v) => v.personTrackId === p.id && v.type === 'NO_VEST');

      let boxColor = '#10b981'; // Green (Compliant)
      if (isFallen) {
        boxColor = '#ef4444'; // Red (Critical Fall)
      } else if (missingHelmet || missingVest) {
        boxColor = '#f59e0b'; // Amber (Non-compliant PPE)
      }

      // Draw bounding box
      ctx.strokeStyle = boxColor;
      ctx.lineWidth = 3;
      ctx.strokeRect(x, y, w, h);

      // Corner accents
      const cornerLen = Math.min(16, w * 0.2, h * 0.2);
      ctx.lineWidth = 4;
      // Top-Left
      ctx.beginPath();
      ctx.moveTo(x, y + cornerLen);
      ctx.lineTo(x, y);
      ctx.lineTo(x + cornerLen, y);
      ctx.stroke();

      // Label background banner
      const bannerHeight = 22;
      ctx.fillStyle = boxColor;
      ctx.fillRect(x, Math.max(0, y - bannerHeight), Math.max(120, w), bannerHeight);

      // Label text
      ctx.fillStyle = '#020617';
      ctx.font = 'bold 12px monospace';
      const labelText = isFallen
        ? `⚠️ FALLEN #${p.id}`
        : `#${p.id} ${missingHelmet ? 'NO-HELMET' : 'HELMET:OK'} ${missingVest ? 'NO-VEST' : 'VEST:OK'}`;
      ctx.fillText(labelText, x + 4, Math.max(15, y - 6));
    }
  };

  // Perform Deep Safety Audit with Gemini 3.8 Flash
  const handleDeepAudit = async () => {
    if (!overlayCanvasRef.current) return;
    setIsAuditing(true);
    setAuditResult(null);

    try {
      const result = await safetyService.performDeepAudit(overlayCanvasRef.current, confidenceThresh);
      setAuditResult(result);
    } catch (err: any) {
      setAuditResult({
        error: true,
        message: err.message || 'Deep AI Audit failed to process frame',
      });
    } finally {
      setIsAuditing(false);
    }
  };

  const handleStartCamera = async () => {
    if (selectedCameraId) {
      try {
        await cameraService.startCamera(selectedCameraId);
      } catch (e) {
        console.warn('Failed to start camera:', e);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Camera Selector & AI Status */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-bold text-slate-100">Intelligent Safety &amp; PPE Compliance</h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-amber-950 text-amber-400 border border-amber-800/80">
              OSHA HARDHAT &amp; VEST INSPECTION
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real trained neural network detection, fall posture kinematics, and verified PPE verification.
          </p>
        </div>

        {/* Source Camera Switcher & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedCameraId}
            onChange={(e) => setSelectedCameraId(e.target.value)}
            className="bg-slate-950 text-slate-200 text-xs font-mono px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.label} {d.status === 'online' ? '(ONLINE)' : '(OFFLINE)'}
              </option>
            ))}
          </select>

          {currentCamera?.status !== 'online' && (
            <button
              onClick={handleStartCamera}
              className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold transition shadow"
            >
              Start Feed
            </button>
          )}

          <button
            onClick={handleDeepAudit}
            disabled={isAuditing || currentCamera?.status !== 'online'}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md transition disabled:opacity-50"
          >
            {isAuditing ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            )}
            <span>{isAuditing ? 'Analyzing...' : 'Deep AI Audit'}</span>
          </button>
        </div>
      </div>

      {/* Model Unavailable Banner */}
      {modelStatus !== 'ready' && (
        <div className="flex items-center justify-between p-4 rounded-xl bg-amber-950/40 border border-amber-800/60 text-amber-300 text-xs font-mono">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 animate-pulse" />
            <span>
              {modelStatus === 'loading'
                ? 'Loading Neural Vision Models (COCO-SSD & Kinematic Fall Classifier)...'
                : modelStatus === 'error'
                ? `Model Initialization Error: ${detectorService.getErrorMessage()}`
                : 'Model in Standby'}
            </span>
          </div>
          {modelStatus === 'error' && (
            <button
              onClick={() => detectorService.loadModel()}
              className="px-2.5 py-1 rounded bg-amber-900/80 hover:bg-amber-800 text-amber-200 text-xs font-medium"
            >
              Retry Load
            </button>
          )}
        </div>
      )}

      {/* Metrics Row (Calculated strictly from real detections) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Personnel In Frame</span>
          <div className="text-2xl font-black text-slate-100 mt-1">{metrics.personsDetected}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Active tracked workers</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Hardhat Compliant</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">
            {metrics.helmetCompliant}
            <span className="text-xs font-normal text-slate-400 ml-1">/ {metrics.personsDetected}</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Verified head protection</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Hi-Vis Vest Compliant</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">
            {metrics.vestCompliant}
            <span className="text-xs font-normal text-slate-400 ml-1">/ {metrics.personsDetected}</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Reflective safety wear</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Compliance Score</span>
          <div
            className={`text-2xl font-black mt-1 ${
              metrics.complianceRate >= 85
                ? 'text-emerald-400'
                : metrics.complianceRate >= 50
                ? 'text-amber-400'
                : 'text-rose-500'
            }`}
          >
            {metrics.complianceRate}%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            {metrics.fallsDetected > 0 ? (
              <span className="text-rose-400 font-bold">⚠️ {metrics.fallsDetected} FALL DETECTED</span>
            ) : (
              'Real detection evidence'
            )}
          </div>
        </div>
      </div>

      {/* Main Viewport & Incidents Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Live Canvas Viewport */}
        <div className="lg:col-span-2 relative aspect-video bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl flex items-center justify-center">
          {/* Hidden base video element */}
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="absolute inset-0 w-full h-full object-cover"
          />

          {/* Interactive AR Overlay Canvas */}
          <canvas
            ref={overlayCanvasRef}
            className="relative w-full h-full object-cover pointer-events-none"
          />

          {/* Inactive state display */}
          {currentCamera?.status !== 'online' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/90 text-center p-6 z-20">
              {currentCamera?.status === 'error' ? (
                <>
                  <AlertTriangle className="w-10 h-10 text-rose-500 mb-2" />
                  <p className="text-sm font-semibold text-rose-300">Camera Source Error</p>
                  <p className="text-xs text-slate-400 max-w-md mb-4 mt-1">
                    {currentCamera.errorMessage || 'Could not start hardware video source.'}
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      onClick={handleStartCamera}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
                    >
                      Retry Camera
                    </button>
                    <button
                      onClick={async () => {
                        const synth = devices.find((d) => d.isSimulated);
                        if (synth) {
                          setSelectedCameraId(synth.id);
                          await cameraService.startCamera(synth.id);
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition shadow"
                    >
                      Switch to Zone-02 Test Feed
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <Camera className="w-10 h-10 text-slate-600 mb-2" />
                  <p className="text-sm font-semibold text-slate-300">Selected Camera Offline</p>
                  <p className="text-xs text-slate-500 max-w-sm mb-4">
                    Connect the camera feed to start real-time PPE &amp; fall detection inference.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      onClick={handleStartCamera}
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition shadow"
                    >
                      Connect {currentCamera?.label || 'Camera'}
                    </button>
                    <button
                      onClick={async () => {
                        const synth = devices.find((d) => d.isSimulated);
                        if (synth) {
                          setSelectedCameraId(synth.id);
                          await cameraService.startCamera(synth.id);
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold border border-slate-700 transition"
                    >
                      Use Test CCTV Stream
                    </button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* HUD Status Bar */}
          <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur px-3 py-1 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-300 flex items-center space-x-2 z-10">
            <span
              className={`w-2 h-2 rounded-full ${
                currentCamera?.status === 'online' ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
              }`}
            ></span>
            <span>PPE ENGINE: {currentCamera?.status === 'online' ? 'INSPECTING' : 'IDLE'}</span>
            <span className="text-slate-600">|</span>
            <span>THRESHOLD: {Math.round(confidenceThresh * 100)}%</span>
          </div>
        </div>

        {/* Live Safety Incidents Feed */}
        <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-4 flex flex-col h-[400px] lg:h-auto">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Safety Incident Ticker
              </h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
              {recentViolations.length} RECORDED
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2.5 mt-3 pr-1">
            {recentViolations.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                <ShieldCheck className="w-8 h-8 text-emerald-500/50 mb-2" />
                <p className="text-xs font-semibold text-slate-400">No Safety Violations Detected</p>
                <p className="text-[11px] text-slate-600 mt-1">
                  All active workers are compliant with OSHA hardhat and high-vis vest regulations.
                </p>
              </div>
            ) : (
              recentViolations.map((v) => (
                <div
                  key={v.id}
                  className={`p-3 rounded-xl border transition ${
                    v.severity === 'CRITICAL'
                      ? 'bg-rose-950/40 border-rose-800/80 text-rose-200'
                      : 'bg-amber-950/40 border-amber-800/80 text-amber-200'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <span className="font-bold flex items-center gap-1">
                      {v.severity === 'CRITICAL' ? '🚨 CRITICAL' : '⚠️ WARNING'}
                    </span>
                    <span className="text-slate-400">{new Date(v.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-xs font-medium text-slate-100 mt-1">{v.description}</p>
                  <div className="text-[10px] text-slate-400 font-mono mt-1 flex justify-between">
                    <span>{v.cameraName}</span>
                    {v.personTrackId && <span>Target #{v.personTrackId}</span>}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Deep Audit Modal */}
      {auditResult && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                <h3 className="text-base font-bold text-slate-100">
                  Gemini 3.8 Flash Deep Safety Audit Report
                </h3>
              </div>
              <button
                onClick={() => setAuditResult(null)}
                className="text-slate-400 hover:text-slate-200 font-bold text-sm px-2 py-1 rounded"
              >
                ✕
              </button>
            </div>

            {auditResult.error ? (
              <div className="p-4 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 text-xs">
                {auditResult.message}
              </div>
            ) : (
              <div className="space-y-4 text-xs font-mono">
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-500">PEOPLE IN FRAME</span>
                    <div className="text-xl font-bold text-slate-100 mt-1">
                      {auditResult.personsCount ?? 0}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-500">RISK LEVEL</span>
                    <div
                      className={`text-xl font-bold mt-1 ${
                        auditResult.riskLevel === 'SAFE'
                          ? 'text-emerald-400'
                          : auditResult.riskLevel === 'WARNING'
                          ? 'text-amber-400'
                          : 'text-rose-500'
                      }`}
                    >
                      {auditResult.riskLevel ?? 'NORMAL'}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-500">COMPLIANCE</span>
                    <div className="text-xl font-bold text-cyan-400 mt-1">
                      {auditResult.compliancePercentage ?? 100}%
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-400 font-bold block mb-1">EXECUTIVE SUMMARY:</span>
                  <p className="text-slate-200 font-sans leading-relaxed">
                    {auditResult.summary || 'Scene appears clear of violations.'}
                  </p>
                </div>

                {auditResult.violations && auditResult.violations.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-slate-400 font-bold block">SPECIFIC OBSERVATIONS:</span>
                    {auditResult.violations.map((v: any, idx: number) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 flex items-start space-x-2"
                      >
                        <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold text-slate-200">[{v.type}]</span>{' '}
                          <span className="text-slate-300">{v.description}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setAuditResult(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                Close Audit Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
