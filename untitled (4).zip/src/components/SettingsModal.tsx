import React, { useState, useEffect } from 'react';
import {
  Settings,
  BatteryCharging,
  Sliders,
  Volume2,
  Languages,
  Video,
  Sparkles,
  Check,
} from 'lucide-react';
import { SystemSettings } from '../types/vision';
import { settingsService } from '../services/settings';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState<SystemSettings>(settingsService.getSettings());
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSettings(settingsService.getSettings());
      setSavedSuccess(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    settingsService.updateSettings(settings);
    setSavedSuccess(true);
    setTimeout(() => {
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-slate-100">System Vision &amp; Hardware Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 text-sm font-bold px-2 py-1 rounded"
          >
            ✕
          </button>
        </div>

        {/* Settings Form */}
        <div className="space-y-5 text-xs font-mono">
          {/* Camera Resolution */}
          <div className="space-y-1.5">
            <label className="text-slate-300 font-bold flex items-center gap-1.5">
              <Video className="w-3.5 h-3.5 text-cyan-400" />
              <span>Camera Stream Resolution (getUserMedia)</span>
            </label>
            <select
              value={settings.resolution}
              onChange={(e) => setSettings({ ...settings, resolution: e.target.value as any })}
              className="w-full bg-slate-950 text-slate-200 px-3 py-2.5 rounded-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            >
              <option value="1280x720">1280x720 HD (Balanced, Recommended)</option>
              <option value="1920x1080">1920x1080 Full HD (High Quality)</option>
              <option value="640x480">640x480 SD (Low Bandwidth)</option>
            </select>
          </div>

          {/* AI Detection Confidence Threshold */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300 font-bold">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-amber-400" />
                <span>Detection Confidence Threshold</span>
              </span>
              <span className="text-amber-400">{Math.round(settings.confidenceThreshold * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="0.85"
              step="0.05"
              value={settings.confidenceThreshold}
              onChange={(e) =>
                setSettings({ ...settings, confidenceThreshold: parseFloat(e.target.value) })
              }
              className="w-full accent-amber-400 cursor-pointer"
            />
            <p className="text-[10px] text-slate-500 font-sans">
              Lower thresholds detect distant/partial objects; higher thresholds prevent false positives.
            </p>
          </div>

          {/* Battery Saver Mode */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="space-y-0.5">
              <div className="text-slate-200 font-bold flex items-center gap-1.5">
                <BatteryCharging className="w-4 h-4 text-emerald-400" />
                <span>Battery Saver / Hardware Throttle</span>
              </div>
              <p className="text-[10px] text-slate-500 font-sans">
                Throttles inference to 6 FPS to prevent CPU overheating and conserve power.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.batterySaver}
                onChange={(e) => setSettings({ ...settings, batterySaver: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Audio Alerts */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="space-y-0.5">
              <div className="text-slate-200 font-bold flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>Industrial Audio Alerts</span>
              </div>
              <p className="text-[10px] text-slate-500 font-sans">
                Web Audio synthesizer warning beeps on detected falls or missing PPE.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.audioAlerts}
                onChange={(e) => setSettings({ ...settings, audioAlerts: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-600"></div>
            </label>
          </div>

          {/* Voice Assistant Language */}
          <div className="space-y-1.5">
            <label className="text-slate-300 font-bold flex items-center gap-1.5">
              <Languages className="w-3.5 h-3.5 text-purple-400" />
              <span>Voice Assistant Language</span>
            </label>
            <select
              value={settings.language}
              onChange={(e) => setSettings({ ...settings, language: e.target.value as any })}
              className="w-full bg-slate-950 text-slate-200 px-3 py-2.5 rounded-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
            >
              <option value="en-US">English (en-US)</option>
              <option value="hi-IN">हिन्दी - Hindi (hi-IN)</option>
              <option value="mr-IN">मराठी - Marathi (mr-IN)</option>
            </select>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center space-x-1.5 px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 transition"
          >
            {savedSuccess && <Check className="w-4 h-4" />}
            <span>{savedSuccess ? 'Saved!' : 'Save & Persist'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
