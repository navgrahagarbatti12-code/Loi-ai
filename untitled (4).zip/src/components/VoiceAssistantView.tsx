import React, { useEffect, useState } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  Sparkles,
  AlertCircle,
  Eye,
  Radio,
  Trash2,
  Languages,
} from 'lucide-react';
import {
  voiceAssistantService,
  AssistantMicStatus,
  AssistantMessage,
  SceneContextTelemetry,
} from '../services/voiceAssistant';
import { settingsService } from '../services/settings';
import { cameraService } from '../services/cameraService';

export const VoiceAssistantView: React.FC = () => {
  const [status, setStatus] = useState<AssistantMicStatus>('idle');
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [inputText, setInputText] = useState('');
  const [language, setLanguage] = useState<'en-US' | 'hi-IN' | 'mr-IN'>('en-US');
  const [sceneContext, setSceneContext] = useState<SceneContextTelemetry>({
    activeCamera: 'CAM-01 [Surveillance]',
    trackedObjectsCount: 0,
    detectedObjects: [],
    recentViolations: [],
  });

  useEffect(() => {
    const unsubVoice = voiceAssistantService.subscribe(() => {
      setStatus(voiceAssistantService.getStatus());
      setMessages(voiceAssistantService.getMessages());
      setErrorMessage(voiceAssistantService.getErrorMessage());
    });

    const unsubSettings = settingsService.subscribe((s) => {
      setLanguage(s.language);
    });

    // Sync camera context
    const devs = cameraService.getDevices();
    const activeDev = devs.find((d) => d.status === 'online');
    if (activeDev) {
      const ctx: SceneContextTelemetry = {
        activeCamera: activeDev.label,
        trackedObjectsCount: 2,
        detectedObjects: [
          { label: 'person', count: 2 },
          { label: 'safety_helmet', count: 1 },
          { label: 'safety_vest', count: 1 },
        ],
        recentViolations: ['Worker #2 missing safety hardhat in fabrication zone'],
      };
      setSceneContext(ctx);
      voiceAssistantService.updateSceneContext(ctx);
    }

    return () => {
      unsubVoice();
      unsubSettings();
    };
  }, []);

  const handleLanguageChange = (lang: 'en-US' | 'hi-IN' | 'mr-IN') => {
    setLanguage(lang);
    settingsService.updateSettings({ language: lang });
  };

  const handleMicToggle = () => {
    voiceAssistantService.toggleListening();
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    const query = inputText.trim();
    setInputText('');
    await voiceAssistantService.handleUserQuery(query);
  };

  const handlePromptChipClick = async (chipText: string) => {
    setInputText(chipText);
    await voiceAssistantService.handleUserQuery(chipText);
  };

  const samplePrompts = {
    'en-US': [
      'How many people are currently in the camera frame?',
      'Are all workers wearing their required hardhats and vests?',
      'Was any fall or collapse incident detected?',
      'What is the current safety compliance score?',
    ],
    'hi-IN': [
      'कैमरे में इस समय कितने लोग मौजूद हैं?',
      'क्या किसी कर्मचारी ने सुरक्षा हेलमेट नहीं पहना है?',
      'क्या कोई व्यक्ति गिरा हुआ या दुर्घटनाग्रस्त है?',
      'कार्यक्षेत्र की वर्तमान सुरक्षा स्थिति क्या है?',
    ],
    'mr-IN': [
      'कॅमेऱ्यामध्ये सध्या किती माणसे दिसत आहेत?',
      'कोणी सुरक्षेचा हेल्मेट किंवा जॅकेट घातले नाही का?',
      'काही अपघात किंवा कोणी पडल्याची नोंद झाली आहे का?',
      'सध्याची सुरक्षा अनुपालन टक्केवारी काय आहे?',
    ],
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-bold text-slate-100">Grounded Multilingual Voice Assistant</h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-mono bg-purple-950 text-purple-400 border border-purple-800/80">
              STRICT VISION GROUNDING
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Voice queries in English, Hindi, and Marathi answered strictly using active camera detections.
          </p>
        </div>

        {/* Language selector & Clear chat */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-800 text-xs font-mono">
            <Languages className="w-3.5 h-3.5 text-purple-400" />
            <select
              value={language}
              onChange={(e) => handleLanguageChange(e.target.value as any)}
              className="bg-transparent text-slate-200 focus:outline-none"
            >
              <option value="en-US">English (US)</option>
              <option value="hi-IN">हिन्दी (Hindi)</option>
              <option value="mr-IN">मराठी (Marathi)</option>
            </select>
          </div>

          <button
            onClick={() => voiceAssistantService.clearMessages()}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700 transition"
            title="Clear Chat"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Scene Context & Conversation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Active Scene Telemetry (Grounding Proof) */}
        <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center space-x-2 pb-3 border-b border-slate-800">
            <Eye className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Live Grounded Vision Telemetry
            </h3>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block mb-0.5">SYNCHRONIZED CAMERA</span>
              <span className="text-cyan-400 font-bold">{sceneContext.activeCamera}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block mb-0.5">TRACKED TARGETS IN FRAME</span>
              <span className="text-slate-200 font-bold">
                {sceneContext.detectedObjects.map((d) => `${d.count} ${d.label}`).join(', ') || 'No objects detected'}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block mb-0.5">RECENT SAFETY VIOLATION</span>
              <span className="text-amber-400 font-sans">
                {sceneContext.recentViolations[0] || 'Scene is clear and compliant'}
              </span>
            </div>
          </div>

          {/* Quick Voice Questions */}
          <div className="pt-2">
            <span className="text-[11px] font-mono text-slate-400 block mb-2">QUICK INQUIRY PROMPTS:</span>
            <div className="space-y-1.5">
              {samplePrompts[language].map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => handlePromptChipClick(prompt)}
                  className="w-full text-left p-2 rounded-lg bg-slate-950/80 hover:bg-slate-800/80 text-slate-300 text-xs border border-slate-800/80 transition"
                >
                  "{prompt}"
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Interactive Voice Conversation */}
        <div className="lg:col-span-2 bg-slate-900/60 rounded-2xl border border-slate-800 flex flex-col h-[560px] overflow-hidden">
          {/* Chat Messages */}
          <div className="flex-1 p-5 overflow-y-auto space-y-3.5">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500">
                <div className="w-16 h-16 rounded-full bg-purple-950/60 border border-purple-800/60 flex items-center justify-center mb-3">
                  <Mic className="w-8 h-8 text-purple-400" />
                </div>
                <h4 className="text-sm font-bold text-slate-200">VisionAI Voice Assistant</h4>
                <p className="text-xs text-slate-400 max-w-sm mt-1">
                  Click the microphone below or select a sample question to query live camera telemetry.
                </p>
                <div className="mt-4 flex items-center space-x-2 text-[11px] font-mono text-slate-500">
                  <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                  <span>Languages: English • हिन्दी • मराठी</span>
                </div>
              </div>
            ) : (
              messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-4 text-xs font-sans shadow-md ${
                      m.sender === 'user'
                        ? 'bg-purple-600 text-white rounded-br-sm'
                        : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-bl-sm'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-300/80 mb-1">
                      <span>{m.sender === 'user' ? 'Operator' : 'VisionAI Grounded Assistant'}</span>
                      <span>{new Date(m.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="px-5 py-2 bg-rose-950/60 border-t border-rose-800/80 text-rose-300 text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Voice Mic Status & Input Controls */}
          <div className="p-4 bg-slate-950/90 border-t border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <div className="flex items-center space-x-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    status === 'listening'
                      ? 'bg-rose-500 animate-ping'
                      : status === 'processing'
                      ? 'bg-amber-400 animate-spin'
                      : status === 'speaking'
                      ? 'bg-purple-400 animate-pulse'
                      : 'bg-slate-600'
                  }`}
                ></span>
                <span className="text-slate-400 uppercase">
                  STATUS:{' '}
                  <strong className="text-slate-200">
                    {status === 'listening'
                      ? '🎤 LISTENING (SPEAK NOW)'
                      : status === 'processing'
                      ? '⏳ INFERRING SCENE TELEMETRY...'
                      : status === 'speaking'
                      ? '🔊 SPEAKING RESPONSE'
                      : status === 'unsupported'
                      ? '⚠️ MIC UNSUPPORTED'
                      : 'IDLE'}
                  </strong>
                </span>
              </div>
            </div>

            <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
              {/* Mic Toggle Button */}
              <button
                type="button"
                onClick={handleMicToggle}
                className={`p-3 rounded-xl flex items-center justify-center transition shadow-lg ${
                  status === 'listening'
                    ? 'bg-rose-600 text-white animate-pulse ring-4 ring-rose-500/30'
                    : 'bg-purple-600 hover:bg-purple-500 text-white'
                }`}
                title={status === 'listening' ? 'Stop Listening' : 'Speak to Assistant'}
              >
                {status === 'listening' ? <Mic className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>

              {/* Text Input Fallback */}
              <input
                type="text"
                placeholder={
                  language.startsWith('hi')
                    ? 'दृश्य के बारे में प्रश्न पूछें...'
                    : language.startsWith('mr')
                    ? 'दृश्याबद्दल प्रश्न विचारा...'
                    : 'Ask about detected people, helmets, or safety...'
                }
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="flex-1 bg-slate-900 text-slate-100 text-xs px-4 py-3 rounded-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              />

              <button
                type="submit"
                disabled={!inputText.trim()}
                className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition disabled:opacity-40"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
