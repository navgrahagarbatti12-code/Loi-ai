import JSZip from 'jszip';

export interface AndroidFileRecord {
  path: string;
  content: string;
  language: string;
  encoding?: 'utf8' | 'base64';
}

export const ANDROID_PROJECT_FILES: AndroidFileRecord[] = [
  {
    path: 'build.gradle.kts',
    language: 'kotlin',
    content: `// Top-level build file for LOOI AI Native Android Companion
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.ksp) apply false
}`,
  },
  {
    path: 'settings.gradle.kts',
    language: 'kotlin',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "LOOI AI"
include(":app")`,
  },
  {
    path: 'gradle.properties',
    language: 'properties',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official`,
  },
  {
    path: 'app/build.gradle.kts',
    language: 'kotlin',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.looi.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.looi.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // CameraX
    val cameraxVersion = "1.3.3"
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")

    // ML Kit Face & Object Tracking
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.mlkit:object-detection:17.0.2")

    // Room Database
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // Coroutines & OkHttp
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.code.gson:gson:2.10.1")
}`,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.looi.ai">

    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <uses-feature android:name="android.hardware.camera" android:required="true" />
    <uses-feature android:name="android.hardware.camera.front" android:required="true" />

    <application
        android:name=".LooiApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/Theme.LooiAI"
        android:hardwareAccelerated="true">

        <activity
            android:name=".ui.MainActivity"
            android:exported="true"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".ui.ConversationActivity"
            android:exported="false"
            android:screenOrientation="portrait" />

        <activity
            android:name=".ui.SettingsActivity"
            android:exported="false"
            android:screenOrientation="portrait" />
    </application>
</manifest>`,
  },
  {
    path: 'app/src/main/java/com/looi/ai/avatar/RobotFaceCanvasView.kt',
    language: 'kotlin',
    content: `package com.looi.ai.avatar

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import com.looi.ai.utils.SmoothingFilter
import kotlin.math.*

class RobotFaceCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var currentEmotion: RobotEmotion = RobotEmotion.HAPPY
        set(value) {
            field = value
            invalidate()
        }

    private var targetLookX = 0f
    private var targetLookY = 0f
    private var currentLookX = 0f
    private var currentLookY = 0f

    private val lookXFilter = SmoothingFilter(0.2f)
    private val lookYFilter = SmoothingFilter(0.2f)
    private var blinkProgress = 0f
    private var isBlinking = false

    var mouthAmplitude: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            postInvalidateOnAnimation()
        }

    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F2FE")
        style = Paint.Style.FILL
    }
    private val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val darkBackgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#080C14")
        style = Paint.Style.FILL
    }
    private val mouthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F2FE")
        style = Paint.Style.STROKE
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
    }

    init {
        val ticker = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 16
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                currentLookX = lookXFilter.filter(targetLookX)
                currentLookY = lookYFilter.filter(targetLookY)
                postInvalidateOnAnimation()
            }
        }
        ticker.start()
    }

    fun setLookTarget(x: Float, y: Float) {
        targetLookX = x.coerceIn(-1f, 1f)
        targetLookY = y.coerceIn(-1f, 1f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        canvas.drawRect(0f, 0f, w, h, darkBackgroundPaint)
        val eyeSpacing = w * 0.25f
        val eyeRadius = w * 0.15f
        val cx = w / 2f
        val cy = h / 2f

        // Draw left and right eye with pupil shift
        drawSingleEye(canvas, cx - eyeSpacing, cy, eyeRadius, eyeRadius * 1.25f, currentLookX, currentLookY)
        drawSingleEye(canvas, cx + eyeSpacing, cy, eyeRadius, eyeRadius * 1.25f, currentLookX, currentLookY)

        // Draw mouth with lip sync
        val mouthY = cy + eyeRadius * 1.4f
        val openH = 10f + mouthAmplitude * 35f
        canvas.drawOval(RectF(cx - 35f, mouthY - openH/2, cx + 35f, mouthY + openH/2), eyePaint)
    }

    private fun drawSingleEye(canvas: Canvas, x: Float, y: Float, rx: Float, ry: Float, lx: Float, ly: Float) {
        val eyeRect = RectF(x - rx, y - ry, x + rx, y + ry)
        canvas.drawOval(eyeRect, eyePaint)

        canvas.save()
        val path = Path().apply { addOval(eyeRect, Path.Direction.CW) }
        canvas.clipPath(path)

        val px = x + lx * rx * 0.45f
        val py = y + ly * ry * 0.4f
        canvas.drawCircle(px, py, rx * 0.45f, pupilPaint)
        canvas.restore()
    }
}`,
  },
  {
    path: 'app/src/main/java/com/looi/ai/camera/CameraXManager.kt',
    language: 'kotlin',
    content: `package com.looi.ai.camera

import android.content.Context
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.Executors

class CameraXManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val previewView: PreviewView
) {
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    fun startCamera(analyzer: ImageAnalysis.Analyzer, onError: (Exception) -> Unit) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { it.setAnalyzer(cameraExecutor, analyzer) }

                val cameraSelector = CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                    .build()

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview, imageAnalysis)
            } catch (e: Exception) {
                onError(e)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun release() {
        cameraExecutor.shutdown()
    }
}`,
  },
  {
    path: 'app/src/main/java/com/looi/ai/vision/FaceTrackingAnalyzer.kt',
    language: 'kotlin',
    content: `package com.looi.ai.vision

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.looi.ai.avatar.RobotEmotion

class FaceTrackingAnalyzer(
    private val onTracked: (x: Float, y: Float, emotion: RobotEmotion) -> Unit
) : ImageAnalysis.Analyzer {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .build()
    )

    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        val w = image.width.toFloat()
        val h = image.height.toFloat()

        detector.process(image)
            .addOnSuccessListener { faces ->
                if (faces.isNotEmpty()) {
                    val face = faces[0]
                    val rawX = ((face.boundingBox.centerX() / w) - 0.5f) * -2f
                    val rawY = ((face.boundingBox.centerY() / h) - 0.5f) * 2f
                    val smile = face.smilingProbability ?: 0f
                    val emotion = if (smile > 0.6f) RobotEmotion.HAPPY else RobotEmotion.CURIOUS
                    onTracked(rawX, rawY, emotion)
                } else {
                    onTracked(0f, 0f, RobotEmotion.SEARCHING)
                }
            }
            .addOnCompleteListener { imageProxy.close() }
    }
}`,
  },
  {
    path: 'README.md',
    language: 'markdown',
    content: `# LOOI AI – Native Android Companion Project
Open this folder in Android Studio (Iguana / Ladybug or newer).
Connect your phone with USB Debugging enabled and press Run ▶!
Build APK via: ./gradlew assembleDebug`,
  },
];

export async function fetchCompleteAndroidFiles(): Promise<AndroidFileRecord[]> {
  try {
    const res = await fetch('/api/android/files');
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data?.files) && data.files.length > 0) {
        return data.files;
      }
    }
  } catch {
    // Fall back to embedded snapshot if offline
  }
  return ANDROID_PROJECT_FILES;
}

export async function downloadAndroidStudioZip(): Promise<void> {
  const zip = new JSZip();

  const folder = zip.folder('looi-ai-android');
  if (!folder) throw new Error('Could not create folder in zip');

  const files = await fetchCompleteAndroidFiles();
  for (const file of files) {
    if (file.encoding === 'base64') {
      folder.file(file.path, file.content, { base64: true });
    } else if (file.path === 'gradlew') {
      folder.file(file.path, file.content, { unixPermissions: '755' });
    } else {
      folder.file(file.path, file.content);
    }
  }

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'LOOI-AI-Android-Studio-Project.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
