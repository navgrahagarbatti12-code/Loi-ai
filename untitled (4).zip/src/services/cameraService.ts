import { CameraDevice } from '../types/vision';
import { settingsService } from './settings';

class CameraService {
  private static instance: CameraService;
  private activeStreams: Map<string, MediaStream> = new Map();
  private syntheticAnimIds: Map<string, number> = new Map();
  private devices: CameraDevice[] = [];
  private listeners: Array<(devices: CameraDevice[]) => void> = [];

  private constructor() {
    if (typeof window !== 'undefined' && navigator.mediaDevices) {
      navigator.mediaDevices.addEventListener('devicechange', () => {
        this.refreshDevices();
      });
    }
  }

  public static getInstance(): CameraService {
    if (!CameraService.instance) {
      CameraService.instance = new CameraService();
    }
    return CameraService.instance;
  }

  public onDevicesChange(callback: (devices: CameraDevice[]) => void): () => void {
    this.listeners.push(callback);
    callback(this.getDevices());
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  public getDevices(): CameraDevice[] {
    return [...this.devices];
  }

  private notify(): void {
    const list = this.getDevices();
    this.listeners.forEach((cb) => {
      try {
        cb(list);
      } catch (e) {
        console.error('Error in camera change listener:', e);
      }
    });
  }

  // Discover real connected video input devices
  public async refreshDevices(): Promise<CameraDevice[]> {
    if (typeof window === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      this.devices = [];
      this.notify();
      return [];
    }

    try {
      const allDevices = await navigator.mediaDevices.enumerateDevices();
      const videoInputs = allDevices.filter((d) => d.kind === 'videoinput');

      // Preserve existing stream references if device was already active
      const updatedDevices: CameraDevice[] = videoInputs.map((d, index) => {
        const id = d.deviceId || `cam_${index + 1}`;
        const existing = this.devices.find((prev) => prev.id === id);
        const activeStream = this.activeStreams.get(id);

        const isOnline = Boolean(
          activeStream &&
          activeStream.active &&
          activeStream.getVideoTracks().some((t) => t.readyState === 'live')
        );

        return {
          id,
          deviceId: d.deviceId,
          label: d.label || `Camera ${index + 1} (${d.deviceId ? d.deviceId.slice(0, 8) : 'Default'})`,
          status: isOnline ? 'online' : (existing?.status === 'connecting' ? 'connecting' : 'offline'),
          stream: (isOnline && activeStream) ? activeStream : null,
          resolution: settingsService.getSettings().resolution,
          isSimulated: false,
        };
      });

      // Add a dedicated synthetic CCTV feed for testing multi-cam monitoring grids
      const syntheticId = 'cctv_synthetic_feed';
      const syntheticStream = this.activeStreams.get(syntheticId);
      const isSynthOnline = Boolean(
        syntheticStream &&
        syntheticStream.active &&
        syntheticStream.getVideoTracks().some((t) => t.readyState === 'live')
      );

      updatedDevices.push({
        id: syntheticId,
        deviceId: 'simulated_cctv_01',
        label: 'Zone-02 Perimeter CCTV (Test Feed)',
        status: isSynthOnline ? 'online' : 'offline',
        stream: (isSynthOnline && syntheticStream) ? syntheticStream : null,
        resolution: '1280x720',
        isSimulated: true,
      });

      this.devices = updatedDevices;
      this.notify();
      return this.devices;
    } catch (err: any) {
      console.error('Failed to enumerate media devices:', err);
      return this.devices;
    }
  }

  // Connect a specific camera device
  public async startCamera(cameraId: string): Promise<MediaStream> {
    const device = this.devices.find((d) => d.id === cameraId);
    if (!device) {
      throw new Error(`Device with ID ${cameraId} not found`);
    }

    // Stop any existing stream for this device first
    this.stopCamera(cameraId);

    // Stop any other active physical hardware streams to release exclusive webcam hardware lock
    for (const [id] of this.activeStreams.entries()) {
      const otherDev = this.devices.find((d) => d.id === id);
      if (otherDev && !otherDev.isSimulated) {
        this.stopCamera(id);
      }
    }

    // Update status to connecting
    device.status = 'connecting';
    this.notify();

    // Check if device is simulated CCTV test stream
    if (device.isSimulated) {
      try {
        const stream = this.createSyntheticCCTVStream(cameraId);
        this.activeStreams.set(cameraId, stream);
        device.stream = stream;
        device.status = 'online';
        this.notify();
        return stream;
      } catch (e: any) {
        device.status = 'error';
        device.errorMessage = e.message || 'Synthetic camera generation failed';
        this.notify();
        throw e;
      }
    }

    // Connect to real hardware camera with progressive fallback
    const settings = settingsService.getSettings();
    const [idealWidth, idealHeight] = settings.resolution === '1920x1080'
      ? [1920, 1080]
      : settings.resolution === '640x480'
      ? [640, 480]
      : [1280, 720];

    // Wait 60ms to ensure camera hardware driver fully releases from previous track
    await new Promise((resolve) => setTimeout(resolve, 60));

    // Progressive constraints: never use { exact: deviceId } which causes 'Could not start video source'
    const candidateConstraints: MediaStreamConstraints[] = [
      // 1. Ideal deviceId with requested resolution
      {
        audio: false,
        video: {
          deviceId: device.deviceId ? { ideal: device.deviceId } : undefined,
          width: { ideal: idealWidth },
          height: { ideal: idealHeight },
          frameRate: { ideal: settings.batterySaver ? 15 : 30 },
        },
      },
      // 2. Ideal deviceId with relaxed resolution
      {
        audio: false,
        video: device.deviceId ? { deviceId: { ideal: device.deviceId } } : true,
      },
      // 3. Fallback to generic system camera
      {
        audio: false,
        video: true,
      },
    ];

    let stream: MediaStream | null = null;
    let lastError: any = null;

    for (const constraints of candidateConstraints) {
      try {
        stream = await navigator.mediaDevices.getUserMedia(constraints);
        if (stream && stream.active && stream.getVideoTracks().length > 0) {
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn('getUserMedia attempt failed, attempting fallback constraint:', constraints, err);
      }
    }

    if (!stream) {
      const err = lastError || new Error('Could not start video source');
      console.error(`Error connecting to camera ${cameraId}:`, err);
      let errorMsg = 'Failed to access camera';

      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        errorMsg = 'Camera permission denied. Please allow camera access in browser.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        errorMsg = 'Selected camera hardware was not found.';
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError' || err.message?.includes('Could not start video source')) {
        errorMsg = 'Camera is in use by another application/tab or blocked by the operating system. Close other apps using camera or use the Zone-02 Test Feed.';
      } else if (err.name === 'OverconstrainedError') {
        errorMsg = 'Camera does not support requested resolution.';
      }

      device.status = 'error';
      device.errorMessage = errorMsg;
      device.stream = null;
      this.notify();
      throw new Error(errorMsg);
    }

    try {
      this.activeStreams.set(cameraId, stream);
      device.stream = stream;
      device.status = 'online';
      device.errorMessage = undefined;

      // Listen for track ended (e.g. user unplugged or system revoked access)
      stream.getVideoTracks().forEach((track) => {
        track.onended = () => {
          this.stopCamera(cameraId);
        };
      });

      this.notify();
      return stream;
    } catch (bindErr: any) {
      device.status = 'error';
      device.errorMessage = bindErr.message || 'Stream binding error';
      this.notify();
      throw bindErr;
    }
  }

  // Proper stream cleanup: stop all tracks and release resources
  public stopCamera(cameraId: string): void {
    const stream = this.activeStreams.get(cameraId);
    if (stream) {
      stream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (e) {
          console.warn('Error stopping media track:', e);
        }
      });
      this.activeStreams.delete(cameraId);
    }

    const animId = this.syntheticAnimIds.get(cameraId);
    if (animId) {
      cancelAnimationFrame(animId);
      this.syntheticAnimIds.delete(cameraId);
    }

    const device = this.devices.find((d) => d.id === cameraId);
    if (device) {
      device.status = 'offline';
      device.stream = null;
      device.errorMessage = undefined;
    }

    this.notify();
  }

  // Stop all camera streams (e.g. app unmount or navigation switch)
  public stopAll(): void {
    for (const id of Array.from(this.activeStreams.keys())) {
      this.stopCamera(id);
    }
  }

  // Generate a valid synthetic CCTV video stream using canvas
  private createSyntheticCCTVStream(cameraId: string): MediaStream {
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext('2d')!;

    let frame = 0;
    let personX = 200;
    let personVx = 2.5;

    const renderSynthetic = () => {
      frame++;
      // Industrial surveillance scene background
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Floor grid lines
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      for (let y = 300; y < canvas.height; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Moving worker simulation
      personX += personVx;
      if (personX > canvas.width - 250 || personX < 150) {
        personVx = -personVx;
      }

      const pw = 80;
      const ph = 180;
      const py = 360;

      // Person body
      ctx.fillStyle = '#334155';
      ctx.fillRect(personX, py, pw, ph);

      // Fluorescent Safety Vest (Hi-Vis Yellow)
      ctx.fillStyle = '#eab308';
      ctx.fillRect(personX + 5, py + 40, pw - 10, 70);

      // Reflective vest stripes
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(personX + 10, py + 65, pw - 20, 10);

      // Safety Hardhat (White)
      ctx.fillStyle = '#f1f5f9';
      ctx.beginPath();
      ctx.arc(personX + pw / 2, py + 15, 24, Math.PI, 0);
      ctx.fill();

      // Industrial Danger Zone boundary
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
      ctx.lineWidth = 3;
      ctx.setLineDash([8, 8]);
      ctx.strokeRect(700, 320, 400, 280);
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
      ctx.fillRect(700, 320, 400, 280);
      ctx.fillStyle = '#ef4444';
      ctx.font = 'bold 14px monospace';
      ctx.fillText('RESTRICTED HEAVY MACHINERY ZONE', 720, 350);

      // CCTV HUD overlay
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(0, 0, canvas.width, 36);

      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 15px monospace';
      ctx.fillText('● REC  CAM-02 [PERIMETER LOADING BAY]', 20, 24);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '14px monospace';
      const timeStr = new Date().toISOString().replace('T', ' ').slice(0, 19);
      ctx.fillText(`FPS: 30.0  |  1080p  |  ${timeStr}`, canvas.width - 380, 24);

      const id = requestAnimationFrame(renderSynthetic);
      this.syntheticAnimIds.set(cameraId, id);
    };

    renderSynthetic();
    return canvas.captureStream(30);
  }
}

export const cameraService = CameraService.getInstance();
