import * as tf from '@tensorflow/tfjs';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import { RawDetection, ModelLoadingStatus } from '../types/vision';

class DetectorService {
  private static instance: DetectorService;
  private model: cocoSsd.ObjectDetection | null = null;
  private status: ModelLoadingStatus = 'unloaded';
  private errorMessage: string = '';
  private initPromise: Promise<cocoSsd.ObjectDetection> | null = null;
  private listeners: Array<(status: ModelLoadingStatus, err?: string) => void> = [];
  private lastInferenceTimeMs = 0;
  private isDetecting = false;

  private constructor() {}

  public static getInstance(): DetectorService {
    if (!DetectorService.instance) {
      DetectorService.instance = new DetectorService();
    }
    return DetectorService.instance;
  }

  public getStatus(): ModelLoadingStatus {
    return this.status;
  }

  public getErrorMessage(): string {
    return this.errorMessage;
  }

  public getLastInferenceTimeMs(): number {
    return this.lastInferenceTimeMs;
  }

  public onStatusChange(callback: (status: ModelLoadingStatus, err?: string) => void): () => void {
    this.listeners.push(callback);
    callback(this.status, this.errorMessage);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private setStatus(status: ModelLoadingStatus, err = ''): void {
    this.status = status;
    this.errorMessage = err;
    this.listeners.forEach((cb) => cb(status, err));
  }

  public async loadModel(): Promise<cocoSsd.ObjectDetection> {
    if (this.model && this.status === 'ready') {
      return this.model;
    }

    if (this.initPromise) {
      return this.initPromise;
    }

    this.setStatus('loading');

    this.initPromise = (async () => {
      try {
        // Try initializing WebGL backend first, fallback to CPU if unavailable
        try {
          await tf.setBackend('webgl');
          await tf.ready();
        } catch (backendErr) {
          console.warn('WebGL backend unavailable, falling back to CPU:', backendErr);
          await tf.setBackend('cpu');
          await tf.ready();
        }

        // Load COCO-SSD object detection model
        const loadedModel = await cocoSsd.load({
          base: 'lite_mobilenet_v2', // Fast, low-latency mobile architecture
        });

        this.model = loadedModel;
        this.setStatus('ready');
        return loadedModel;
      } catch (err: any) {
        console.error('Failed to initialize AI detection model:', err);
        const msg = err.message || 'Model initialization failed';
        this.setStatus('error', msg);
        this.initPromise = null;
        throw new Error(msg);
      }
    })();

    return this.initPromise;
  }

  public async detect(
    source: HTMLVideoElement | HTMLCanvasElement | HTMLImageElement,
    confidenceThreshold = 0.45
  ): Promise<RawDetection[]> {
    if (this.status !== 'ready' || !this.model) {
      return [];
    }

    // Validate video element ready state before attempting frame extraction
    if (source instanceof HTMLVideoElement) {
      if (source.readyState < 2 || source.videoWidth === 0 || source.videoHeight === 0) {
        // Frame not yet rendered or ready
        return [];
      }
    } else if (source instanceof HTMLCanvasElement) {
      if (source.width === 0 || source.height === 0) {
        return [];
      }
    }

    // Prevent overlapping inference execution on the same thread
    if (this.isDetecting) {
      return [];
    }

    this.isDetecting = true;
    const startTime = performance.now();

    try {
      const predictions = await this.model.detect(source, 25, confidenceThreshold);
      this.lastInferenceTimeMs = Math.round(performance.now() - startTime);

      const detections: RawDetection[] = predictions
        .filter((p) => p.score >= confidenceThreshold)
        .map((p) => ({
          class: p.class,
          score: Math.round(p.score * 100) / 100,
          bbox: [
            Math.round(p.bbox[0]),
            Math.round(p.bbox[1]),
            Math.round(p.bbox[2]),
            Math.round(p.bbox[3]),
          ],
        }));

      return detections;
    } catch (err: any) {
      console.warn('Inference error during frame detection:', err);
      return [];
    } finally {
      this.isDetecting = false;
    }
  }

  public dispose(): void {
    if (this.model) {
      try {
        this.model.dispose();
      } catch (e) {
        console.warn('Error disposing model:', e);
      }
      this.model = null;
    }
    this.initPromise = null;
    this.setStatus('unloaded');
  }
}

export const detectorService = DetectorService.getInstance();
