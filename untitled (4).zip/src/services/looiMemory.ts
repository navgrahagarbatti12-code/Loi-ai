import { ChatMessage } from './looiVoice';

const MEMORY_STORAGE_KEY = 'looi_ai_companion_memory';
const PREFS_STORAGE_KEY = 'looi_ai_companion_preferences';

export interface LooiPreferences {
  companionName: string;
  language: string; // 'hi-IN' | 'en-IN'
  mirrorCamera: boolean;
  voicePitch: number;
  autoGreeting: boolean;
  detectObjects: boolean;
}

const DEFAULT_PREFS: LooiPreferences = {
  companionName: 'LOOI',
  language: 'hi-IN',
  mirrorCamera: true,
  voicePitch: 1.35,
  autoGreeting: true,
  detectObjects: true,
};

export class LooiMemoryService {
  getMessages(): ChatMessage[] {
    try {
      const raw = localStorage.getItem(MEMORY_STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn('Failed to load memory:', e);
    }
    return [
      {
        id: 'init-1',
        sender: 'LOOI',
        text: 'Arey hello dost! Main hoon LOOI, aapka cute robot friend! Aaj hum kya naya explore karein?',
        emotion: 'HAPPY',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  }

  saveMessage(msg: ChatMessage): void {
    const list = this.getMessages();
    list.push(msg);
    // Keep last 100 messages
    if (list.length > 100) list.shift();
    try {
      localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(list));
    } catch (e) {
      console.warn('Failed to save memory:', e);
    }
  }

  clearMemory(): void {
    try {
      localStorage.removeItem(MEMORY_STORAGE_KEY);
    } catch (e) {
      console.warn('Failed to clear memory:', e);
    }
  }

  getRecentContext(): string {
    const list = this.getMessages().slice(-6);
    return list.map((m) => `${m.sender}: ${m.text}`).join('\n');
  }

  getPreferences(): LooiPreferences {
    try {
      const raw = localStorage.getItem(PREFS_STORAGE_KEY);
      if (raw) return { ...DEFAULT_PREFS, ...JSON.parse(raw) };
    } catch (e) {
      console.warn('Failed to load prefs:', e);
    }
    return DEFAULT_PREFS;
  }

  savePreferences(prefs: Partial<LooiPreferences>): LooiPreferences {
    const current = this.getPreferences();
    const updated = { ...current, ...prefs };
    try {
      localStorage.setItem(PREFS_STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save prefs:', e);
    }
    return updated;
  }
}

export const looiMemoryService = new LooiMemoryService();
