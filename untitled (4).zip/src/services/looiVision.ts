import * as cocoSsd from '@tensorflow-models/coco-ssd';
import '@tensorflow/tfjs';
import { RobotEmotion } from '../components/LooiRobotCanvas';

export interface FaceTrackingData {
  hasFace: boolean;
  lookX: number; // -1 to 1
  lookY: number; // -1 to 1
  faceBox?: { x: number; y: number; width: number; height: number };
  smileProbability: number;
  inferredEmotion: RobotEmotion;
  trackedTargetLabel?: string;
}

export interface DetectedVisualObject {
  label: string;
  confidence: number;
  bbox: [number, number, number, number]; // [x, y, width, height]
}

export class LooiVisionService {
  private videoElement: HTMLVideoElement | null = null;
  private stream: MediaStream | null = null;
  private isProcessing = false;
  private objectModel: cocoSsd.ObjectDetection | null = null;
  private isModelLoading = false;

  private onFaceUpdateCallback?: (data: FaceTrackingData) => void;
  private onObjectsUpdateCallback?: (objects: DetectedVisualObject[]) => void;

  // Smoothing filters for jitter-free gaze
  private smoothX = 0;
  private smoothY = 0;
  private consecutiveLostFrames = 0;

  async initObjectModel(): Promise<void> {
    if (this.objectModel || this.isModelLoading) return;
    this.isModelLoading = true;
    try {
      this.objectModel = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
      console.log('COCO-SSD on-device vision model loaded successfully for LOOI AI');
    } catch (err) {
      console.warn('COCO-SSD load warning:', err);
    } finally {
      this.isModelLoading = false;
    }
  }

  async startCamera(
    videoElement: HTMLVideoElement,
    onFaceUpdate: (data: FaceTrackingData) => void,
    onObjectsUpdate: (objects: DetectedVisualObject[]) => void
  ): Promise<boolean> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return false;
    }

    this.videoElement = videoElement;
    this.onFaceUpdateCallback = onFaceUpdate;
    this.onObjectsUpdateCallback = onObjectsUpdate;

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
        audio: false,
      });

      this.videoElement.srcObject = this.stream;
      await this.videoElement.play();

      this.isProcessing = true;
      this.processVideoLoop();
      // Load COCO-SSD in background after camera stream is active
      this.initObjectModel();
      return true;
    } catch (error: any) {
      const name = error?.name || '';
      if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || name === 'NotFoundError') {
        console.info('Camera permission not granted or unavailable; running LOOI in voice-only mode.');
      } else {
        console.info('Camera unavailable:', error?.message || name);
      }
      return false;
    }
  }

  stopCamera(): void {
    this.isProcessing = false;
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }
    if (this.videoElement) {
      this.videoElement.srcObject = null;
    }
  }

  captureCurrentFrameBase64(): string | null {
    if (!this.isProcessing || !this.videoElement || this.videoElement.readyState < 2) {
      return null;
    }
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 192;
      canvas.height = 144;
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;
      ctx.drawImage(this.videoElement, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.4);
      return dataUrl.replace(/^data:image\/\w+;base64,/, '');
    } catch {
      return null;
    }
  }

  private processVideoLoop = async (): Promise<void> => {
    if (!this.isProcessing || !this.videoElement) return;

    if (this.videoElement.readyState >= 2 && !this.videoElement.paused) {
      try {
        await this.detectFrame();
      } catch (e) {
        console.warn('Frame detection step error:', e);
      }
    }

    if (this.isProcessing) {
      requestAnimationFrame(this.processVideoLoop);
    }
  };

  private lastDetectTime = 0;
  private isDetecting = false;
  private cachedObjects: DetectedVisualObject[] = [];

  private async detectFrame(): Promise<void> {
    if (!this.videoElement) return;

    const video = this.videoElement;
    const vw = video.videoWidth || 640;
    const vh = video.videoHeight || 480;
    const now = performance.now();

    // Run ML inference every 250ms (~4 Hz) without overlapping calls so UI & voice stay silky smooth
    if (this.objectModel && !this.isDetecting && now - this.lastDetectTime >= 250) {
      this.isDetecting = true;
      this.lastDetectTime = now;
      try {
        const predictions = await this.objectModel.detect(video, 10, 0.35);
        this.cachedObjects = predictions.map((p) => ({
          label: p.class,
          confidence: p.score,
          bbox: p.bbox,
        }));
        this.onObjectsUpdateCallback?.(this.cachedObjects);
      } catch {
        // Ignored frame error
      } finally {
        this.isDetecting = false;
      }
    }

    // 1. Prioritize following a recognized non-person object (e.g. phone, bottle, cup, laptop)
    //    so when user shows an object, LOOI's eyes actively lock onto and follow it!
    const nonPersonObjects = this.cachedObjects.filter(
      (o) => o.label !== 'person' && o.confidence >= 0.45
    );
    const prominentObject = nonPersonObjects.sort(
      (a, b) => b.bbox[2] * b.bbox[3] - a.bbox[2] * a.bbox[3]
    )[0];

    const personObj = this.cachedObjects.find((o) => o.label === 'person');
    const targetObj = prominentObject || personObj;

    if (targetObj) {
      this.consecutiveLostFrames = 0;
      const [bx, by, bw, bh] = targetObj.bbox;
      const isObjectTarget = targetObj.label !== 'person';

      // Center of object, or upper third for person face
      const targetCx = bx + bw / 2;
      const targetCy = isObjectTarget ? by + bh / 2 : by + bh * 0.35;

      // Mirrored coordinates for front camera
      const rawLookX = ((targetCx / vw) - 0.5) * -2.2;
      const rawLookY = ((targetCy / vh) - 0.5) * 2.0;

      // Low-pass EMA filter for fluid, non-jittery pupil motion
      this.smoothX += (rawLookX - this.smoothX) * 0.30;
      this.smoothY += (rawLookY - this.smoothY) * 0.30;

      const clampedX = Math.max(-1, Math.min(1, this.smoothX));
      const clampedY = Math.max(-1, Math.min(1, this.smoothY));

      let emotion: RobotEmotion = isObjectTarget ? 'CURIOUS' : 'HAPPY';
      if (Math.abs(clampedX) > 0.65) {
        emotion = 'CURIOUS';
      }

      this.onFaceUpdateCallback?.({
        hasFace: true,
        lookX: clampedX,
        lookY: clampedY,
        faceBox: { x: bx, y: by, width: bw, height: bh },
        smileProbability: isObjectTarget ? 0.6 : 0.85,
        inferredEmotion: emotion,
        trackedTargetLabel: targetObj.label,
      });
    } else {
      this.consecutiveLostFrames++;
      if (this.consecutiveLostFrames > 12) {
        this.onFaceUpdateCallback?.({
          hasFace: false,
          lookX: 0,
          lookY: 0,
          smileProbability: 0,
          inferredEmotion: 'SEARCHING',
        });
      }
    }
  }
}

export const looiVisionService = new LooiVisionService();
