import { RobotEmotion } from '../components/LooiRobotCanvas';

export interface ChatMessage {
  id: string;
  sender: 'USER' | 'LOOI';
  text: string;
  emotion?: RobotEmotion;
  timestamp: string;
}

export class LooiVoiceService {
  private continuousEnabled = false;
  private isPausedForSpeech = false;
  private isSpeakingNow = false;
  private onAudioTurnCallback?: (audioBase64: string, mimeType: string) => void;
  private speakSafetyTimer: number | null = null;
  private selectedVoice: SpeechSynthesisVoice | null = null;
  private lastSpokenText = '';
  private lastSpeakEndedAt = 0;

  // Silent MediaRecorder + VAD state (zero Android/Chrome SpeechRecognizer beeps!)
  private micStream: MediaStream | null = null;
  private vadAudioCtx: AudioContext | null = null;
  private vadAnalyser: AnalyserNode | null = null;
  private vadInterval: number | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: BlobPart[] = [];
  private isRecordingSpeech = false;
  private speechStartedAt = 0;
  private lastLoudAt = 0;

  // Output Audio & Lip Sync
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private currentAudioElement: HTMLAudioElement | null = null;
  private lipSyncAnimId: number | null = null;
  private ttsCooldownUntil = 0;

  private onAmplitudeUpdate?: (amplitude: number) => void;
  private onStateChange?: (state: 'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING') => void;

  init(
    onAmplitude: (amplitude: number) => void,
    onState: (state: 'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING') => void
  ) {
    this.onAmplitudeUpdate = onAmplitude;
    this.onStateChange = onState;

    this.cachePreferredVoice();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = () => {
        this.cachePreferredVoice();
      };
    }
  }

  private cachePreferredVoice() {
    if (!('speechSynthesis' in window)) return;
    const voices = window.speechSynthesis.getVoices();
    if (!voices.length) return;

    this.selectedVoice =
      voices.find((v) => v.name.includes('Google') && v.lang.startsWith('hi')) ||
      voices.find((v) => v.name.includes('Natural') && v.lang.startsWith('hi')) ||
      voices.find((v) => v.lang === 'hi-IN') ||
      voices.find((v) => v.lang.startsWith('hi')) ||
      voices.find((v) => v.name.includes('Google') && v.lang.includes('IN')) ||
      voices.find((v) => v.lang.includes('IN')) ||
      voices.find((v) => v.lang.startsWith('en')) ||
      voices[0];
  }

  primeAudioOutput() {
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.resume();
      } catch {
        // Ignore
      }
    }
    try {
      if (!this.audioContext) {
        this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      if (this.audioContext.state === 'suspended') {
        this.audioContext.resume();
      }
    } catch {
      // Ignore
    }
  }

  /**
   * Starts 100% silent continuous listening using MediaRecorder + AudioContext VAD.
   * Never triggers Android/Chrome SpeechRecognizer start/stop beeps!
   */
  async startContinuousListening(
    onAudioTurn: (audioBase64: string, mimeType: string) => void
  ): Promise<boolean> {
    this.onAudioTurnCallback = onAudioTurn;

    if (!navigator.mediaDevices?.getUserMedia) return false;

    try {
      if (!this.micStream) {
        this.micStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
          video: false,
        });
      }

      if (!this.vadAudioCtx) {
        this.vadAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      if (this.vadAudioCtx.state === 'suspended') {
        await this.vadAudioCtx.resume();
      }

      if (!this.vadAnalyser) {
        const source = this.vadAudioCtx.createMediaStreamSource(this.micStream);
        this.vadAnalyser = this.vadAudioCtx.createAnalyser();
        this.vadAnalyser.fftSize = 512;
        source.connect(this.vadAnalyser);
      }

      this.continuousEnabled = true;
      this.startVadLoop();
      if (!this.isPausedForSpeech && !this.isSpeakingNow) {
        this.onStateChange?.('LISTENING');
      }
      return true;
    } catch {
      return false;
    }
  }

  private startVadLoop() {
    if (this.vadInterval !== null) {
      clearInterval(this.vadInterval);
    }

    const bufferLength = this.vadAnalyser?.fftSize || 512;
    const dataArray = new Uint8Array(bufferLength);
    let consecutiveLoudFrames = 0;

    this.vadInterval = window.setInterval(() => {
      if (!this.continuousEnabled || !this.vadAnalyser) return;

      // Ignore mic while LOOI is speaking, thinking, or in short post-speech echo window
      if (
        this.isPausedForSpeech ||
        this.isSpeakingNow ||
        Date.now() - this.lastSpeakEndedAt < 450
      ) {
        if (this.isRecordingSpeech) {
          this.cancelActiveRecording();
        }
        consecutiveLoudFrames = 0;
        return;
      }

      this.vadAnalyser.getByteTimeDomainData(dataArray);
      let sumSquares = 0;
      for (let i = 0; i < dataArray.length; i++) {
        const normalized = (dataArray[i] - 128) / 128;
        sumSquares += normalized * normalized;
      }
      const rms = Math.sqrt(sumSquares / dataArray.length);
      const now = Date.now();

      if (!this.isRecordingSpeech) {
        if (rms > 0.018) {
          consecutiveLoudFrames = 0;
          this.beginSpeechRecording();
        }
      } else {
        if (rms > 0.014) {
          this.lastLoudAt = now;
        }
        const speechDuration = now - this.speechStartedAt;
        const silenceDuration = now - this.lastLoudAt;

        // Fast 420ms silence commit for snappy responses (max 9s turn)
        if (silenceDuration >= 420 || speechDuration >= 9000) {
          this.finishSpeechRecording(speechDuration >= 280);
        }
      }
    }, 50);
  }

  private beginSpeechRecording() {
    if (!this.micStream || this.isRecordingSpeech) return;

    const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
      ? 'audio/webm;codecs=opus'
      : MediaRecorder.isTypeSupported('audio/webm')
      ? 'audio/webm'
      : 'audio/mp4';

    try {
      this.audioChunks = [];
      this.mediaRecorder = new MediaRecorder(this.micStream, {
        mimeType,
        audioBitsPerSecond: 24000,
      });
      this.isRecordingSpeech = true;
      this.speechStartedAt = Date.now();
      this.lastLoudAt = Date.now();

      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          this.audioChunks.push(e.data);
        }
      };

      this.mediaRecorder.start(100);
    } catch {
      this.isRecordingSpeech = false;
    }
  }

  private cancelActiveRecording() {
    this.isRecordingSpeech = false;
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      try {
        this.mediaRecorder.onstop = null;
        this.mediaRecorder.stop();
      } catch {
        // Ignore
      }
    }
    this.audioChunks = [];
  }

  private finishSpeechRecording(shouldProcess: boolean) {
    if (!this.mediaRecorder || !this.isRecordingSpeech) return;
    this.isRecordingSpeech = false;

    const recorder = this.mediaRecorder;
    const mimeType = recorder.mimeType || 'audio/webm';

    if (!shouldProcess) {
      this.cancelActiveRecording();
      return;
    }

    recorder.onstop = async () => {
      if (!this.continuousEnabled || this.isPausedForSpeech || this.isSpeakingNow) {
        this.audioChunks = [];
        return;
      }

      const blob = new Blob(this.audioChunks, { type: mimeType });
      this.audioChunks = [];
      if (blob.size < 1500) return; // Ignore tiny blips

      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        const base64 = result?.split(',')[1];
        if (base64 && this.onAudioTurnCallback) {
          this.pauseForSpeech();
          this.onStateChange?.('THINKING');
          this.onAudioTurnCallback(base64, mimeType);
        }
      };
      reader.readAsDataURL(blob);
    };

    try {
      if (recorder.state !== 'inactive') {
        recorder.stop();
      }
    } catch {
      this.audioChunks = [];
    }
  }

  pauseForSpeech() {
    this.isPausedForSpeech = true;
    if (this.isRecordingSpeech) {
      this.cancelActiveRecording();
    }
  }

  resumeAfterSpeech() {
    this.lastSpeakEndedAt = Date.now();
    window.setTimeout(() => {
      this.isPausedForSpeech = false;
      if (this.continuousEnabled && !this.isSpeakingNow) {
        this.onStateChange?.('LISTENING');
      }
    }, 450);
  }

  stopListening() {
    this.continuousEnabled = false;
    this.isPausedForSpeech = false;
    if (this.vadInterval !== null) {
      clearInterval(this.vadInterval);
      this.vadInterval = null;
    }
    this.cancelActiveRecording();
    if (this.micStream) {
      this.micStream.getTracks().forEach((t) => t.stop());
      this.micStream = null;
    }
    this.vadAnalyser = null;
    if (!this.isSpeakingNow) {
      this.onStateChange?.('IDLE');
    }
  }

  stopSpeaking() {
    this.isSpeakingNow = false;
    if (this.speakSafetyTimer) {
      clearTimeout(this.speakSafetyTimer);
      this.speakSafetyTimer = null;
    }
    if (this.lipSyncAnimId) {
      cancelAnimationFrame(this.lipSyncAnimId);
      this.lipSyncAnimId = null;
    }
    if (this.currentAudioElement) {
      try {
        this.currentAudioElement.pause();
        this.currentAudioElement.currentTime = 0;
      } catch {
        // Ignore
      }
      this.currentAudioElement = null;
    }
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // Ignore
      }
    }
    this.onAmplitudeUpdate?.(0);
    this.onStateChange?.('IDLE');
  }

  async sendLooiAudioTurn(
    audioBase64: string,
    mimeType: string,
    detectedEmotion: string,
    detectedObjects: string[],
    historyContext: string,
    imageBase64: string | null = null
  ): Promise<{ silence: boolean; reply: string; emotion: RobotEmotion }> {
    this.onStateChange?.('THINKING');

    try {
      const res = await fetch('/api/looi/voice-turn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioBase64,
          mimeType,
          detectedEmotion,
          detectedObjects,
          historyContext,
          imageBase64,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || !contentType.includes('application/json')) {
        return { silence: true, reply: '', emotion: 'HAPPY' };
      }

      const data = await res.json();
      if (data.silence || !data.reply) {
        return { silence: true, reply: '', emotion: 'HAPPY' };
      }
      return {
        silence: false,
        reply: data.reply,
        emotion: data.detectedEmotion || 'HAPPY',
      };
    } catch {
      return { silence: true, reply: '', emotion: 'HAPPY' };
    }
  }

  async sendLooiMessage(
    userMessage: string,
    detectedEmotion: string,
    detectedObjects: string[],
    historyContext: string,
    imageBase64: string | null = null
  ): Promise<{ reply: string; emotion: RobotEmotion }> {
    this.onStateChange?.('THINKING');

    try {
      const res = await fetch('/api/looi/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          language: 'hi-IN',
          detectedEmotion,
          detectedObjects,
          historyContext,
          imageBase64,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || !contentType.includes('application/json')) {
        throw new Error(`Unexpected response (${res.status}) from /api/looi/chat`);
      }

      const data = await res.json();
      const reply = data.reply || 'Arey dost! Main hamesha aapke saath hoon!';
      return {
        reply,
        emotion: data.detectedEmotion || 'HAPPY',
      };
    } catch (err) {
      console.warn('Looi chat fallback triggered:', err);
      return {
        reply: 'Arey dost, network thoda dheema hai, par main aapki smile dekh raha hoon!',
        emotion: 'HAPPY',
      };
    }
  }

  async speak(text: string, onFinish?: () => void) {
    this.pauseForSpeech();
    this.isSpeakingNow = true;
    this.lastSpokenText = text;
    this.onStateChange?.('SPEAKING');

    const done = () => {
      this.isSpeakingNow = false;
      this.lastSpeakEndedAt = Date.now();
      onFinish?.();
    };

    // Instant 0ms natural voice output without extra 3-4s TTS network round-trip
    this.speakWithSpeechSynthesis(text, done);
  }

  private async playAudioWav(base64Wav: string, onFinish?: () => void) {
    try {
      if (!this.audioContext) {
        this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      if (this.audioContext.state === 'suspended') {
        await this.audioContext.resume();
      }

      const audioUrl = `data:audio/wav;base64,${base64Wav}`;
      const audio = new Audio(audioUrl);
      this.currentAudioElement = audio;

      const source = this.audioContext.createMediaElementSource(audio);
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 128;
      source.connect(this.analyser);
      this.analyser.connect(this.audioContext.destination);

      const dataArray = new Uint8Array(this.analyser.frequencyBinCount);

      const updateLipSync = () => {
        if (this.analyser && !audio.paused && !audio.ended) {
          this.analyser.getByteFrequencyData(dataArray);
          let sum = 0;
          for (let i = 2; i < 16; i++) {
            sum += dataArray[i];
          }
          const avg = sum / 14;
          const normalized = Math.min(1, (avg / 160) * 1.5);
          this.onAmplitudeUpdate?.(normalized);
          this.lipSyncAnimId = requestAnimationFrame(updateLipSync);
        } else {
          this.onAmplitudeUpdate?.(0);
        }
      };

      audio.onplay = () => updateLipSync();
      audio.onended = () => {
        if (this.lipSyncAnimId) cancelAnimationFrame(this.lipSyncAnimId);
        this.onAmplitudeUpdate?.(0);
        this.onStateChange?.('IDLE');
        onFinish?.();
      };
      audio.onerror = () => {
        this.onAmplitudeUpdate?.(0);
        this.onStateChange?.('IDLE');
        onFinish?.();
      };

      await audio.play();
    } catch {
      this.speakWithSpeechSynthesis(this.lastSpokenText, onFinish);
    }
  }

  private speakWithSpeechSynthesis(text: string, onFinish?: () => void) {
    if (!('speechSynthesis' in window)) {
      this.onStateChange?.('IDLE');
      onFinish?.();
      return;
    }

    if (this.speakSafetyTimer) {
      clearTimeout(this.speakSafetyTimer);
      this.speakSafetyTimer = null;
    }

    const cleanText = text.replace(/[*#_`~]/g, '').trim();
    if (!cleanText) {
      this.onStateChange?.('IDLE');
      onFinish?.();
      return;
    }

    const startUtterance = () => {
      try {
        window.speechSynthesis.resume();
      } catch {
        // Ignore
      }

      const utterance = new SpeechSynthesisUtterance(cleanText);

      if (!this.selectedVoice) {
        this.cachePreferredVoice();
      }
      if (this.selectedVoice) {
        utterance.voice = this.selectedVoice;
        utterance.lang = this.selectedVoice.lang;
      } else {
        utterance.lang = 'hi-IN';
      }

      utterance.pitch = 1.0;
      utterance.rate = 1.02;

      let simInterval: number | null = null;
      let finished = false;

      const cleanup = () => {
        if (finished) return;
        finished = true;
        if (simInterval !== null) {
          clearInterval(simInterval);
          simInterval = null;
        }
        if (this.speakSafetyTimer) {
          clearTimeout(this.speakSafetyTimer);
          this.speakSafetyTimer = null;
        }
        this.onAmplitudeUpdate?.(0);
        this.onStateChange?.('IDLE');
        onFinish?.();
      };

      utterance.onstart = () => {
        this.onStateChange?.('SPEAKING');
        if (!simInterval) {
          simInterval = window.setInterval(() => {
            const amp = 0.35 + Math.random() * 0.65;
            this.onAmplitudeUpdate?.(amp);
          }, 100);
        }
      };

      utterance.onboundary = () => {
        this.onAmplitudeUpdate?.(0.85);
      };

      utterance.onend = cleanup;
      utterance.onerror = cleanup;

      const estimatedMs = Math.max(3000, cleanText.length * 90 + 2500);
      this.speakSafetyTimer = window.setTimeout(cleanup, estimatedMs);

      window.speechSynthesis.speak(utterance);
    };

    if (window.speechSynthesis.speaking || window.speechSynthesis.pending) {
      window.speechSynthesis.cancel();
      window.setTimeout(startUtterance, 50);
    } else {
      startUtterance();
    }
  }
}

export const looiVoiceService = new LooiVoiceService();
