import { SafetyMetrics, SafetyViolation, TrackedTarget } from '../types/vision';
import { storageService } from './storage';
import { settingsService } from './settings';

export class SafetyService {
  private static instance: SafetyService;
  private audioCtx: AudioContext | null = null;
  private lastAlertTime = 0;

  private constructor() {}

  public static getInstance(): SafetyService {
    if (!SafetyService.instance) {
      SafetyService.instance = new SafetyService();
    }
    return SafetyService.instance;
  }

  // Play industrial warning beep using Web Audio API without external audio files
  public playAlertSound(type: 'CRITICAL' | 'WARNING'): void {
    const settings = settingsService.getSettings();
    if (!settings.audioAlerts) return;

    const now = Date.now();
    if (now - this.lastAlertTime < 2500) return; // Debounce audio alerts
    this.lastAlertTime = now;

    try {
      if (!this.audioCtx) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          this.audioCtx = new AudioContextClass();
        }
      }

      if (this.audioCtx && this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }

      if (this.audioCtx) {
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();

        osc.type = type === 'CRITICAL' ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(type === 'CRITICAL' ? 880 : 587, this.audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(type === 'CRITICAL' ? 440 : 293, this.audioCtx.currentTime + 0.35);

        gain.gain.setValueAtTime(0.3, this.audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, this.audioCtx.currentTime + 0.35);

        osc.connect(gain);
        gain.connect(this.audioCtx.destination);

        osc.start();
        osc.stop(this.audioCtx.currentTime + 0.35);
      }
    } catch (e) {
      console.warn('Audio alert playback error:', e);
    }
  }

  // Inspect person targets from live video frame canvas
  public inspectFrame(
    canvas: HTMLCanvasElement,
    personTargets: TrackedTarget[],
    cameraName: string
  ): {
    metrics: SafetyMetrics;
    currentViolations: SafetyViolation[];
  } {
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const violations: SafetyViolation[] = [];

    if (!ctx || personTargets.length === 0 || canvas.width === 0 || canvas.height === 0) {
      return {
        metrics: {
          personsDetected: personTargets.length,
          helmetCompliant: 0,
          vestCompliant: 0,
          fallsDetected: 0,
          complianceRate: personTargets.length === 0 ? 100 : 0,
          violationsCount: 0,
          isModelLoaded: true,
          modelStatus: 'ready',
        },
        currentViolations: [],
      };
    }

    let helmetCompliant = 0;
    let vestCompliant = 0;
    let fallsDetected = 0;

    for (const person of personTargets) {
      const [bx, by, bw, bh] = person.bbox;

      // 1. Fall Detection via Aspect Ratio & Velocity Analysis
      // When a human collapses, the bounding box changes from tall (w/h < 0.6) to wide/horizontal (w/h >= 1.15)
      const aspectRatio = bw / Math.max(1, bh);
      const isHorizontalLying = aspectRatio >= 1.15 && bh > 30;
      const isSuddenDrop = person.velocity.vy > 180 && aspectRatio > 0.85;

      if (isHorizontalLying || isSuddenDrop) {
        fallsDetected++;
        const violation: SafetyViolation = {
          id: `fall_${person.id}_${Date.now()}`,
          timestamp: Date.now(),
          type: 'FALL_DETECTED',
          severity: 'CRITICAL',
          description: `Worker #${person.id} detected in prone/fallen posture (aspect ratio ${aspectRatio.toFixed(2)})`,
          personTrackId: person.id,
          bbox: person.bbox,
          cameraName,
        };
        violations.push(violation);
        storageService.logIncident(violation);
        this.playAlertSound('CRITICAL');
        continue; // Skip further PPE check for fallen individual
      }

      // Ensure bounding box coordinates are within canvas dimensions
      const safeX = Math.max(0, Math.min(canvas.width - 1, Math.floor(bx)));
      const safeY = Math.max(0, Math.min(canvas.height - 1, Math.floor(by)));
      const safeW = Math.max(1, Math.min(canvas.width - safeX, Math.floor(bw)));
      const safeH = Math.max(1, Math.min(canvas.height - safeY, Math.floor(bh)));

      // 2. PPE Inspection: Head Area (Top 22% of bounding box)
      const headHeight = Math.max(4, Math.floor(safeH * 0.22));
      let hasHelmet = false;
      let hasVest = false;

      try {
        const headImageData = ctx.getImageData(safeX, safeY, safeW, headHeight);
        const headPixels = headImageData.data;
        let ppeHeadColorCount = 0;
        let totalHeadSampled = 0;

        for (let i = 0; i < headPixels.length; i += 16) {
          const r = headPixels[i];
          const g = headPixels[i + 1];
          const b = headPixels[i + 2];
          totalHeadSampled++;

          // Industrial Hardhat Colors:
          // Bright White: high luminance with low saturation difference
          const isWhiteHardhat = r > 180 && g > 180 && b > 180 && Math.abs(r - g) < 20 && Math.abs(g - b) < 20;
          // Safety Yellow/Orange Hardhat: High red, moderate-to-high green, low blue
          const isYellowOrangeHardhat = r > 140 && g > 90 && b < 90 && (r + g) > 260;
          // Blue Hardhat (Site Engineers):
          const isBlueHardhat = b > 130 && b > r + 30 && b > g + 20;

          if (isWhiteHardhat || isYellowOrangeHardhat || isBlueHardhat) {
            ppeHeadColorCount++;
          }
        }

        const headPpeRatio = totalHeadSampled > 0 ? ppeHeadColorCount / totalHeadSampled : 0;
        // Require at least 18% of head zone to match hardhat material
        if (headPpeRatio >= 0.18) {
          hasHelmet = true;
          helmetCompliant++;
        } else {
          const violation: SafetyViolation = {
            id: `helmet_${person.id}_${Date.now()}`,
            timestamp: Date.now(),
            type: 'NO_HELMET',
            severity: 'WARNING',
            description: `Worker #${person.id} missing mandatory safety hardhat`,
            personTrackId: person.id,
            bbox: person.bbox,
            cameraName,
          };
          violations.push(violation);
          storageService.logIncident(violation);
          this.playAlertSound('WARNING');
        }

        // 3. PPE Inspection: Torso Area (Middle 45% of bounding box)
        const torsoY = Math.min(canvas.height - 1, safeY + headHeight);
        const torsoHeight = Math.max(6, Math.min(canvas.height - torsoY, Math.floor(safeH * 0.45)));
        const torsoImageData = ctx.getImageData(safeX, torsoY, safeW, torsoHeight);
        const torsoPixels = torsoImageData.data;
        let ppeVestColorCount = 0;
        let totalTorsoSampled = 0;

        for (let i = 0; i < torsoPixels.length; i += 16) {
          const r = torsoPixels[i];
          const g = torsoPixels[i + 1];
          const b = torsoPixels[i + 2];
          totalTorsoSampled++;

          // High-Visibility Vest Colors:
          // Fluorescent Lime/Neon Green: high green, high red, lower blue
          const isNeonGreenVest = g > 130 && r > 100 && b < 100 && g > b + 40;
          // Fluorescent Hi-Vis Orange: high red, moderate green, low blue
          const isHiVisOrangeVest = r > 150 && g > 60 && g < 160 && b < 70 && (r - b) > 80;

          if (isNeonGreenVest || isHiVisOrangeVest) {
            ppeVestColorCount++;
          }
        }

        const torsoPpeRatio = totalTorsoSampled > 0 ? ppeVestColorCount / totalTorsoSampled : 0;
        if (torsoPpeRatio >= 0.20) {
          hasVest = true;
          vestCompliant++;
        } else {
          const violation: SafetyViolation = {
            id: `vest_${person.id}_${Date.now()}`,
            timestamp: Date.now(),
            type: 'NO_VEST',
            severity: 'WARNING',
            description: `Worker #${person.id} missing high-visibility safety vest`,
            personTrackId: person.id,
            bbox: person.bbox,
            cameraName,
          };
          violations.push(violation);
          storageService.logIncident(violation);
        }
      } catch (err) {
        // In case canvas reading encounters security or boundary issues
        console.warn('Canvas pixel extraction issue:', err);
      }
    }

    const totalPersonnel = personTargets.length;
    const totalChecks = totalPersonnel * 2; // Helmet + Vest
    const passedChecks = helmetCompliant + vestCompliant;
    const complianceRate = totalChecks > 0 ? Math.round((passedChecks / totalChecks) * 100) : 100;

    return {
      metrics: {
        personsDetected: totalPersonnel,
        helmetCompliant,
        vestCompliant,
        fallsDetected,
        complianceRate,
        violationsCount: violations.length,
        isModelLoaded: true,
        modelStatus: 'ready',
      },
      currentViolations: violations,
    };
  }

  // Deep Safety Audit using backend Gemini Vision endpoint
  public async performDeepAudit(
    canvas: HTMLCanvasElement,
    confidenceThreshold = 0.5
  ): Promise<any> {
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    const response = await fetch('/api/safety-audit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        image: dataUrl,
        confidenceThreshold,
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Server safety audit failed');
    }

    const result = await response.json();
    return result.data;
  }
}

export const safetyService = SafetyService.getInstance();
