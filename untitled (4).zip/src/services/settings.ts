import { SystemSettings } from '../types/vision';

const SETTINGS_STORAGE_KEY = 'ai_vision_lab_settings_v1';

export const DEFAULT_SETTINGS: SystemSettings = {
  resolution: '1280x720',
  confidenceThreshold: 0.45,
  iouThreshold: 0.4,
  trackingMaxLostFrames: 30,
  batterySaver: false,
  targetFps: 24,
  language: 'en-US',
  audioAlerts: true,
  tripwireYPercent: 0.5,
  enableDeepAudit: true,
};

export class SettingsService {
  private static instance: SettingsService;
  private currentSettings: SystemSettings;
  private listeners: Array<(settings: SystemSettings) => void> = [];

  private constructor() {
    this.currentSettings = this.loadFromStorage();
  }

  public static getInstance(): SettingsService {
    if (!SettingsService.instance) {
      SettingsService.instance = new SettingsService();
    }
    return SettingsService.instance;
  }

  private loadFromStorage(): SystemSettings {
    try {
      const stored = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return {
          ...DEFAULT_SETTINGS,
          ...parsed,
          // Battery saver enforces lower target FPS when active
          targetFps: parsed.batterySaver ? 6 : (parsed.targetFps || DEFAULT_SETTINGS.targetFps),
        };
      }
    } catch (e) {
      console.warn('Failed to parse settings from localStorage, using defaults', e);
    }
    return { ...DEFAULT_SETTINGS };
  }

  public getSettings(): SystemSettings {
    return { ...this.currentSettings };
  }

  public updateSettings(partial: Partial<SystemSettings>): SystemSettings {
    this.currentSettings = {
      ...this.currentSettings,
      ...partial,
      // If battery saver is toggled on, automatically throttle targetFps to 6; if off and was 6, restore to 24
      targetFps: partial.batterySaver !== undefined
        ? (partial.batterySaver ? 6 : (this.currentSettings.targetFps === 6 ? 24 : this.currentSettings.targetFps))
        : (partial.targetFps ?? this.currentSettings.targetFps),
    };

    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(this.currentSettings));
    } catch (e) {
      console.error('Failed to save settings to localStorage:', e);
    }

    this.notify();
    return this.getSettings();
  }

  public subscribe(callback: (settings: SystemSettings) => void): () => void {
    this.listeners.push(callback);
    callback(this.getSettings());
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private notify(): void {
    const s = this.getSettings();
    this.listeners.forEach((callback) => {
      try {
        callback(s);
      } catch (err) {
        console.error('Error in settings listener:', err);
      }
    });
  }
}

export const settingsService = SettingsService.getInstance();
