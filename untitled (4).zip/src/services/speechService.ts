export { voiceAssistantService as speechService, voiceAssistantService } from './voiceAssistant';
export type { AssistantMicStatus, AssistantMessage, SceneContextTelemetry } from './voiceAssistant';
