import { SafetyViolation } from '../types/vision';
import { jsPDF } from 'jspdf';

const DB_NAME = 'AIVisionLab_DB';
const DB_VERSION = 1;
const STORE_NAME = 'incidents';

export interface IncidentFilterOptions {
  page: number;
  pageSize: number;
  severity?: string;
  type?: string;
  search?: string;
}

export interface PagedIncidentsResult {
  items: SafetyViolation[];
  total: number;
  totalPages: number;
  currentPage: number;
}

export interface DatabaseSummaryMetrics {
  totalIncidents: number;
  criticalCount: number;
  warningCount: number;
  infoCount: number;
  noHelmetCount: number;
  noVestCount: number;
  fallCount: number;
  intrusionCount: number;
}

class StorageService {
  private static instance: StorageService;
  private db: IDBDatabase | null = null;
  private initPromise: Promise<void> | null = null;
  private memoryFallback: SafetyViolation[] = [];
  private isIndexedDBAvailable = true;
  // Recent violations cache for deduplication (key: type_trackId or type_desc, value: timestamp)
  private recentViolationsMap = new Map<string, number>();

  private constructor() {
    this.initPromise = this.initDB();
  }

  public static getInstance(): StorageService {
    if (!StorageService.instance) {
      StorageService.instance = new StorageService();
    }
    return StorageService.instance;
  }

  private async initDB(): Promise<void> {
    if (typeof window === 'undefined' || !window.indexedDB) {
      this.isIndexedDBAvailable = false;
      return;
    }

    return new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
            store.createIndex('timestamp', 'timestamp', { unique: false });
            store.createIndex('type', 'type', { unique: false });
            store.createIndex('severity', 'severity', { unique: false });
          }
        };

        request.onsuccess = () => {
          this.db = request.result;
          resolve();
        };

        request.onerror = (e) => {
          console.warn('IndexedDB open error, falling back to in-memory store:', e);
          this.isIndexedDBAvailable = false;
          resolve();
        };
      } catch (err) {
        console.warn('IndexedDB initialization failed:', err);
        this.isIndexedDBAvailable = false;
        resolve();
      }
    });
  }

  private async ensureReady(): Promise<void> {
    if (this.initPromise) {
      await this.initPromise;
    }
  }

  public async logIncident(incident: Omit<SafetyViolation, 'id' | 'timestamp'> & { id?: string; timestamp?: number }): Promise<SafetyViolation | null> {
    await this.ensureReady();

    const timestamp = incident.timestamp || Date.now();
    const id = incident.id || `inc_${timestamp}_${Math.random().toString(36).substring(2, 7)}`;
    const fullIncident: SafetyViolation = {
      ...incident,
      id,
      timestamp,
    };

    // Deduplication check: prevent logging the same violation type for the same target or camera within 4 seconds
    const dedupKey = `${fullIncident.type}_${fullIncident.personTrackId ?? 'global'}_${fullIncident.cameraName}`;
    const lastLogged = this.recentViolationsMap.get(dedupKey);
    if (lastLogged && timestamp - lastLogged < 4000) {
      // Duplicate within debounce window - ignore
      return null;
    }
    this.recentViolationsMap.set(dedupKey, timestamp);

    // Prune debounce map to prevent memory leak
    if (this.recentViolationsMap.size > 200) {
      const now = Date.now();
      for (const [key, time] of this.recentViolationsMap.entries()) {
        if (now - time > 10000) {
          this.recentViolationsMap.delete(key);
        }
      }
    }

    if (!this.isIndexedDBAvailable || !this.db) {
      this.memoryFallback.unshift(fullIncident);
      return fullIncident;
    }

    return new Promise((resolve) => {
      try {
        const tx = this.db!.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const addReq = store.add(fullIncident);

        addReq.onsuccess = () => resolve(fullIncident);
        addReq.onerror = () => {
          // Fallback to memory on transaction error
          this.memoryFallback.unshift(fullIncident);
          resolve(fullIncident);
        };
      } catch (err) {
        console.warn('Error saving incident to IndexedDB:', err);
        this.memoryFallback.unshift(fullIncident);
        resolve(fullIncident);
      }
    });
  }

  public async getAllIncidents(): Promise<SafetyViolation[]> {
    await this.ensureReady();

    if (!this.isIndexedDBAvailable || !this.db) {
      return [...this.memoryFallback].sort((a, b) => b.timestamp - a.timestamp);
    }

    return new Promise((resolve) => {
      try {
        const tx = this.db!.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const index = store.index('timestamp');
        const req = index.openCursor(null, 'prev');
        const results: SafetyViolation[] = [];

        req.onsuccess = (e) => {
          const cursor = (e.target as IDBRequest).result as IDBCursorWithValue;
          if (cursor) {
            results.push(cursor.value);
            cursor.continue();
          } else {
            resolve(results);
          }
        };

        req.onerror = () => {
          resolve([...this.memoryFallback].sort((a, b) => b.timestamp - a.timestamp));
        };
      } catch (err) {
        console.warn('Error reading from IndexedDB:', err);
        resolve([...this.memoryFallback].sort((a, b) => b.timestamp - a.timestamp));
      }
    });
  }

  public async getPagedIncidents(options: IncidentFilterOptions): Promise<PagedIncidentsResult> {
    const all = await this.getAllIncidents();

    let filtered = all;
    if (options.severity && options.severity !== 'ALL') {
      filtered = filtered.filter((i) => i.severity === options.severity);
    }
    if (options.type && options.type !== 'ALL') {
      filtered = filtered.filter((i) => i.type === options.type);
    }
    if (options.search && options.search.trim() !== '') {
      const q = options.search.toLowerCase();
      filtered = filtered.filter(
        (i) =>
          i.description.toLowerCase().includes(q) ||
          i.cameraName.toLowerCase().includes(q) ||
          i.type.toLowerCase().includes(q)
      );
    }

    const total = filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / options.pageSize));
    const page = Math.min(Math.max(1, options.page), totalPages);
    const startIndex = (page - 1) * options.pageSize;
    const items = filtered.slice(startIndex, startIndex + options.pageSize);

    return {
      items,
      total,
      totalPages,
      currentPage: page,
    };
  }

  public async getSummaryMetrics(): Promise<DatabaseSummaryMetrics> {
    const all = await this.getAllIncidents();
    const metrics: DatabaseSummaryMetrics = {
      totalIncidents: all.length,
      criticalCount: 0,
      warningCount: 0,
      infoCount: 0,
      noHelmetCount: 0,
      noVestCount: 0,
      fallCount: 0,
      intrusionCount: 0,
    };

    all.forEach((item) => {
      if (item.severity === 'CRITICAL') metrics.criticalCount++;
      else if (item.severity === 'WARNING') metrics.warningCount++;
      else metrics.infoCount++;

      if (item.type === 'NO_HELMET') metrics.noHelmetCount++;
      else if (item.type === 'NO_VEST') metrics.noVestCount++;
      else if (item.type === 'FALL_DETECTED') metrics.fallCount++;
      else if (item.type === 'ZONE_INTRUSION') metrics.intrusionCount++;
    });

    return metrics;
  }

  public async clearAll(): Promise<void> {
    await this.ensureReady();
    this.memoryFallback = [];
    this.recentViolationsMap.clear();

    if (this.isIndexedDBAvailable && this.db) {
      try {
        const tx = this.db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).clear();
      } catch (err) {
        console.warn('Error clearing IndexedDB:', err);
      }
    }
  }

  // Export to CSV
  public async exportCSV(): Promise<void> {
    const records = await this.getAllIncidents();
    if (records.length === 0) {
      throw new Error('No incident records to export');
    }

    const headers = ['ID', 'Date & Time', 'Camera', 'Type', 'Severity', 'Track ID', 'Description'];
    const rows = records.map((r) => [
      `"${r.id}"`,
      `"${new Date(r.timestamp).toLocaleString()}"`,
      `"${r.cameraName.replace(/"/g, '""')}"`,
      `"${r.type}"`,
      `"${r.severity}"`,
      `"${r.personTrackId !== undefined ? `#${r.personTrackId}` : 'N/A'}"`,
      `"${r.description.replace(/"/g, '""')}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AI_Vision_Lab_Incidents_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Export to PDF using jsPDF
  public async exportPDF(): Promise<void> {
    const records = await this.getAllIncidents();
    if (records.length === 0) {
      throw new Error('No incident records to export');
    }

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: 'a4',
    });

    // Dark sleek theme styling on PDF
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(0, 0, 842, 60, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(56, 189, 248); // sky-400
    doc.text('AI VISION LAB – SAFETY INCIDENT AUDIT REPORT', 40, 36);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text(`Generated: ${new Date().toLocaleString()} | Total Records: ${records.length}`, 40, 52);

    // Table Header
    let y = 90;
    doc.setFillColor(30, 41, 59);
    doc.rect(40, y - 14, 762, 22, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(255, 255, 255);
    doc.text('Timestamp', 48, y);
    doc.text('Camera', 180, y);
    doc.text('Type', 290, y);
    doc.text('Severity', 410, y);
    doc.text('Track ID', 490, y);
    doc.text('Violation Description', 560, y);

    y += 18;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);

    // Render table rows
    records.slice(0, 50).forEach((r, idx) => {
      if (y > 540) {
        doc.addPage();
        y = 40;
      }

      if (idx % 2 === 1) {
        doc.setFillColor(241, 245, 249);
        doc.rect(40, y - 11, 762, 16, 'F');
      }

      doc.setTextColor(51, 65, 85);
      doc.text(new Date(r.timestamp).toLocaleTimeString(), 48, y);
      doc.text(r.cameraName.slice(0, 18), 180, y);

      // Color code violation types
      doc.text(r.type, 290, y);

      // Severity badge
      if (r.severity === 'CRITICAL') {
        doc.setTextColor(220, 38, 38);
      } else if (r.severity === 'WARNING') {
        doc.setTextColor(217, 119, 6);
      } else {
        doc.setTextColor(37, 99, 235);
      }
      doc.text(r.severity, 410, y);

      doc.setTextColor(51, 65, 85);
      doc.text(r.personTrackId !== undefined ? `#${r.personTrackId}` : 'N/A', 490, y);
      doc.text(r.description.slice(0, 45), 560, y);

      y += 17;
    });

    if (records.length > 50) {
      y += 10;
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(100, 116, 139);
      doc.text(`* Displaying first 50 of ${records.length} total records. Use CSV export for full dataset.`, 40, y);
    }

    doc.save(`AI_Vision_Lab_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
  }
}

export const storageService = StorageService.getInstance();
