import { BoundingBox, RawDetection, TrackedTarget, TrackPoint } from '../types/vision';

// Helper: Calculate Intersection over Union (IoU) between two bounding boxes
export function calculateIoU(boxA: BoundingBox, boxB: BoundingBox): number {
  const [ax, ay, aw, ah] = boxA;
  const [bx, by, bw, bh] = boxB;

  const x1 = Math.max(ax, bx);
  const y1 = Math.max(ay, by);
  const x2 = Math.min(ax + aw, bx + bw);
  const y2 = Math.min(ay + ah, by + bh);

  const intersectionW = Math.max(0, x2 - x1);
  const intersectionH = Math.max(0, y2 - y1);
  const intersectionArea = intersectionW * intersectionH;

  const areaA = aw * ah;
  const areaB = bw * bh;
  const unionArea = areaA + areaB - intersectionArea;

  if (unionArea <= 0) return 0;
  return intersectionArea / unionArea;
}

// Generate deterministic vibrant HSL color for track IDs
function generateTrackColor(id: number): string {
  const hue = (id * 137.508) % 360; // Golden ratio color spacing
  return `hsl(${Math.round(hue)}, 90%, 60%)`;
}

export class ByteTracker {
  private nextId = 1;
  private tracks: TrackedTarget[] = [];
  private highThreshold: number;
  private lowThreshold: number;
  private matchThreshold: number;
  private maxLostFrames: number;
  private lastTimestamp: number = performance.now();

  constructor(
    highThreshold = 0.45,
    matchThreshold = 0.35,
    maxLostFrames = 30
  ) {
    this.highThreshold = highThreshold;
    this.lowThreshold = 0.15;
    this.matchThreshold = matchThreshold;
    this.maxLostFrames = maxLostFrames;
  }

  public setParameters(params: {
    highThreshold?: number;
    matchThreshold?: number;
    maxLostFrames?: number;
  }): void {
    if (params.highThreshold !== undefined) this.highThreshold = params.highThreshold;
    if (params.matchThreshold !== undefined) this.matchThreshold = params.matchThreshold;
    if (params.maxLostFrames !== undefined) this.maxLostFrames = params.maxLostFrames;
  }

  // Predict new positions of existing tracks using linear velocity
  private predictTracks(dtSeconds: number): void {
    for (const track of this.tracks) {
      if (track.state !== 'removed') {
        const [x, y, w, h] = track.bbox;
        // Extrapolate bounding box center
        const newX = x + track.velocity.vx * dtSeconds;
        const newY = y + track.velocity.vy * dtSeconds;
        track.bbox = [newX, newY, w, h];
      }
    }
  }

  // Two-stage association algorithm (ByteTrack)
  public update(detections: RawDetection[]): TrackedTarget[] {
    const now = performance.now();
    const dtSeconds = Math.max(0.016, (now - this.lastTimestamp) / 1000);
    this.lastTimestamp = now;

    // Step 1: Predict positions of existing active/lost tracks
    this.predictTracks(dtSeconds);

    // Step 2: Partition detections into high-score and low-score pools
    const highDetections: RawDetection[] = [];
    const lowDetections: RawDetection[] = [];

    for (const det of detections) {
      if (det.score >= this.highThreshold) {
        highDetections.push(det);
      } else if (det.score >= this.lowThreshold) {
        lowDetections.push(det);
      }
    }

    // Active + Lost candidate tracks for matching
    const activeCandidates = this.tracks.filter((t) => t.state !== 'removed');

    // First Association: Match highDetections with activeCandidates using IoU
    const {
      matched: matched1,
      unmatchedTracks: unmatchedTracks1,
      unmatchedDetections: unmatchedHighDets,
    } = this.associate(activeCandidates, highDetections, this.matchThreshold);

    // Update matched tracks from stage 1
    for (const [track, det] of matched1) {
      this.updateTrackWithDetection(track, det, dtSeconds);
    }

    // Second Association: Match remaining unmatched tracks with lowDetections to recover occluded targets
    const {
      matched: matched2,
      unmatchedTracks: remainingLostTracks,
    } = this.associate(unmatchedTracks1, lowDetections, 0.25);

    // Update matched tracks from stage 2 (low-confidence recovery)
    for (const [track, det] of matched2) {
      this.updateTrackWithDetection(track, det, dtSeconds);
    }

    // Step 4: Mark remaining unmatched tracks as lost or expire them
    for (const track of remainingLostTracks) {
      track.timeSinceUpdate++;
      if (track.timeSinceUpdate > this.maxLostFrames) {
        track.state = 'removed';
      } else {
        track.state = 'lost';
      }
    }

    // Step 5: Initialize new tracks for unmatched high-confidence detections
    for (const det of unmatchedHighDets) {
      const newTrack: TrackedTarget = {
        id: this.nextId++,
        class: det.class,
        bbox: det.bbox,
        score: det.score,
        velocity: { vx: 0, vy: 0, speed: 0 },
        history: [{
          x: det.bbox[0] + det.bbox[2] / 2,
          y: det.bbox[1] + det.bbox[3] / 2,
          timestamp: Date.now(),
        }],
        state: 'active',
        age: 1,
        timeSinceUpdate: 0,
        firstSeen: Date.now(),
        lastSeen: Date.now(),
        color: generateTrackColor(this.nextId - 1),
      };
      this.tracks.push(newTrack);
    }

    // Filter out removed tracks to avoid memory leaks
    this.tracks = this.tracks.filter((t) => t.state !== 'removed');

    // Return current active or briefly lost tracks for visualization
    return this.tracks.filter((t) => t.state === 'active');
  }

  private associate(
    tracks: TrackedTarget[],
    detections: RawDetection[],
    threshold: number
  ): {
    matched: Array<[TrackedTarget, RawDetection]>;
    unmatchedTracks: TrackedTarget[];
    unmatchedDetections: RawDetection[];
  } {
    if (tracks.length === 0 || detections.length === 0) {
      return {
        matched: [],
        unmatchedTracks: [...tracks],
        unmatchedDetections: [...detections],
      };
    }

    // Calculate IoU cost matrix
    const matches: Array<[TrackedTarget, RawDetection]> = [];
    const usedTrackIndices = new Set<number>();
    const usedDetectionIndices = new Set<number>();

    // Pairwise IoU list
    const pairs: Array<{ trackIdx: number; detIdx: number; iou: number }> = [];
    for (let t = 0; t < tracks.length; t++) {
      for (let d = 0; d < detections.length; d++) {
        // Enforce class consistency (e.g. person matches person)
        if (tracks[t].class === detections[d].class) {
          const iou = calculateIoU(tracks[t].bbox, detections[d].bbox);
          if (iou >= threshold) {
            pairs.push({ trackIdx: t, detIdx: d, iou });
          }
        }
      }
    }

    // Sort pairs descending by IoU (greedy maximum matching)
    pairs.sort((a, b) => b.iou - a.iou);

    for (const pair of pairs) {
      if (!usedTrackIndices.has(pair.trackIdx) && !usedDetectionIndices.has(pair.detIdx)) {
        usedTrackIndices.add(pair.trackIdx);
        usedDetectionIndices.add(pair.detIdx);
        matches.push([tracks[pair.trackIdx], detections[pair.detIdx]]);
      }
    }

    const unmatchedTracks = tracks.filter((_, idx) => !usedTrackIndices.has(idx));
    const unmatchedDetections = detections.filter((_, idx) => !usedDetectionIndices.has(idx));

    return { matched: matches, unmatchedTracks, unmatchedDetections };
  }

  private updateTrackWithDetection(
    track: TrackedTarget,
    det: RawDetection,
    dtSeconds: number
  ): void {
    const oldCx = track.bbox[0] + track.bbox[2] / 2;
    const oldCy = track.bbox[1] + track.bbox[3] / 2;

    const newCx = det.bbox[0] + det.bbox[2] / 2;
    const newCy = det.bbox[1] + det.bbox[3] / 2;

    // Instant velocity in pixels per second
    const rawVx = (newCx - oldCx) / dtSeconds;
    const rawVy = (newCy - oldCy) / dtSeconds;

    // Exponential moving average filter for velocity smoothing
    const alpha = 0.35;
    const vx = track.velocity.vx * (1 - alpha) + rawVx * alpha;
    const vy = track.velocity.vy * (1 - alpha) + rawVy * alpha;
    const speed = Math.round(Math.sqrt(vx * vx + vy * vy));

    track.bbox = det.bbox;
    track.score = det.score;
    track.velocity = { vx, vy, speed };
    track.state = 'active';
    track.timeSinceUpdate = 0;
    track.age++;
    track.lastSeen = Date.now();

    // Append to trajectory history (limited to 35 points to conserve memory)
    track.history.push({ x: newCx, y: newCy, timestamp: Date.now() });
    if (track.history.length > 35) {
      track.history.shift();
    }
  }

  public reset(): void {
    this.tracks = [];
    this.nextId = 1;
    this.lastTimestamp = performance.now();
  }
}

export const byteTracker = new ByteTracker();
