import { settingsService } from './settings';

export type AssistantMicStatus = 'idle' | 'listening' | 'processing' | 'speaking' | 'error' | 'unsupported';

export interface SceneContextTelemetry {
  activeCamera: string;
  trackedObjectsCount: number;
  detectedObjects: Array<{ label: string; count: number }>;
  recentViolations: string[];
}

export interface AssistantMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: number;
}

class VoiceAssistantService {
  private static instance: VoiceAssistantService;
  private recognition: any = null;
  private status: AssistantMicStatus = 'idle';
  private errorMessage = '';
  private messages: AssistantMessage[] = [];
  private listeners: Array<() => void> = [];
  private lastFinalTranscript = '';
  private lastTranscriptTime = 0;
  private currentSceneContext: SceneContextTelemetry | null = null;

  private constructor() {
    this.initSpeechRecognition();
  }

  public static getInstance(): VoiceAssistantService {
    if (!VoiceAssistantService.instance) {
      VoiceAssistantService.instance = new VoiceAssistantService();
    }
    return VoiceAssistantService.instance;
  }

  private initSpeechRecognition(): void {
    if (typeof window === 'undefined') return;

    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      this.status = 'unsupported';
      this.errorMessage = 'Speech Recognition is not supported by your browser.';
      return;
    }

    try {
      this.recognition = new SpeechRecognitionClass();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.maxAlternatives = 1;

      this.recognition.onstart = () => {
        this.status = 'listening';
        this.errorMessage = '';
        this.notify();
      };

      this.recognition.onresult = async (event: any) => {
        const transcript = event.results?.[0]?.[0]?.transcript?.trim();
        if (!transcript) return;

        // Prevent repeated speech recognition events
        const now = Date.now();
        if (transcript === this.lastFinalTranscript && now - this.lastTranscriptTime < 3000) {
          return;
        }
        this.lastFinalTranscript = transcript;
        this.lastTranscriptTime = now;

        await this.handleUserQuery(transcript);
      };

      this.recognition.onerror = (event: any) => {
        console.warn('Speech recognition event error:', event.error);
        if (event.error === 'no-speech') {
          // Graceful recovery when silence is heard
          this.status = 'idle';
        } else if (event.error === 'not-allowed') {
          this.status = 'error';
          this.errorMessage = 'Microphone permission denied. Please allow microphone in browser.';
        } else if (event.error === 'network') {
          this.status = 'error';
          this.errorMessage = 'Network error during voice recognition.';
        } else {
          this.status = 'error';
          this.errorMessage = `Voice recognition error: ${event.error}`;
        }
        this.notify();
      };

      this.recognition.onend = () => {
        if (this.status === 'listening') {
          this.status = 'idle';
          this.notify();
        }
      };
    } catch (e: any) {
      console.warn('Speech recognition init error:', e);
      this.status = 'unsupported';
      this.errorMessage = e.message || 'Speech recognition failed to initialize';
    }
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    callback();
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private notify(): void {
    this.listeners.forEach((cb) => {
      try {
        cb();
      } catch (e) {
        console.error('Error in voice assistant listener:', e);
      }
    });
  }

  public getStatus(): AssistantMicStatus {
    return this.status;
  }

  public getErrorMessage(): string {
    return this.errorMessage;
  }

  public getMessages(): AssistantMessage[] {
    return [...this.messages];
  }

  public updateSceneContext(context: SceneContextTelemetry): void {
    this.currentSceneContext = context;
  }

  public toggleListening(): void {
    if (this.status === 'listening') {
      this.stopListening();
    } else {
      this.startListening();
    }
  }

  public startListening(): void {
    if (!this.recognition) {
      this.initSpeechRecognition();
    }

    if (!this.recognition) {
      this.status = 'unsupported';
      this.notify();
      return;
    }

    const lang = settingsService.getSettings().language;
    this.recognition.lang = lang;

    try {
      this.recognition.start();
    } catch (err: any) {
      console.warn('Error starting speech recognition:', err);
      // If already started, stop and restart
      try {
        this.recognition.stop();
        setTimeout(() => {
          this.recognition.start();
        }, 150);
      } catch (restartErr) {
        this.status = 'error';
        this.errorMessage = 'Could not access microphone';
        this.notify();
      }
    }
  }

  public stopListening(): void {
    if (this.recognition && this.status === 'listening') {
      try {
        this.recognition.stop();
      } catch (e) {
        console.warn('Error stopping speech recognition:', e);
      }
    }
    this.status = 'idle';
    this.notify();
  }

  // Handle user voice or text query
  public async handleUserQuery(queryText: string): Promise<string> {
    const userMsg: AssistantMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: queryText,
      timestamp: Date.now(),
    };
    this.messages.push(userMsg);
    this.status = 'processing';
    this.notify();

    const lang = settingsService.getSettings().language;

    try {
      const response = await fetch('/api/assistant/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: queryText,
          language: lang,
          sceneContext: this.currentSceneContext,
        }),
      });

      if (!response.ok) {
        const errJson = await response.json();
        throw new Error(errJson.error || 'Server assistant error');
      }

      const resData = await response.json();
      const reply = resData.reply || 'No information available for this request.';

      const assistantMsg: AssistantMessage = {
        id: `ast_${Date.now()}`,
        sender: 'assistant',
        text: reply,
        timestamp: Date.now(),
      };
      this.messages.push(assistantMsg);
      this.status = 'idle';
      this.notify();

      // Speak answer using Web Speech Synthesis
      this.speakText(reply, lang);
      return reply;
    } catch (err: any) {
      console.error('Assistant error:', err);
      const fallbackReply = lang.startsWith('hi')
        ? 'क्षमा करें, इस समय दृश्य जानकारी उपलब्ध नहीं है।'
        : lang.startsWith('mr')
        ? 'माफ करा, या वेळी दृश्य माहिती उपलब्ध नाही.'
        : `Scene telemetry currently unavailable: ${err.message || 'Check camera stream'}`;

      const assistantMsg: AssistantMessage = {
        id: `ast_err_${Date.now()}`,
        sender: 'assistant',
        text: fallbackReply,
        timestamp: Date.now(),
      };
      this.messages.push(assistantMsg);
      this.status = 'idle';
      this.notify();
      this.speakText(fallbackReply, lang);
      return fallbackReply;
    }
  }

  public speakText(text: string, lang = 'en-US'): void {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    try {
      window.speechSynthesis.cancel(); // Stop any pending speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 1.0;

      // Select matching voice if available
      const voices = window.speechSynthesis.getVoices();
      const matchedVoice = voices.find((v) => v.lang.startsWith(lang.slice(0, 2)));
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      utterance.onstart = () => {
        this.status = 'speaking';
        this.notify();
      };

      utterance.onend = () => {
        this.status = 'idle';
        this.notify();
      };

      utterance.onerror = () => {
        this.status = 'idle';
        this.notify();
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
      this.status = 'idle';
      this.notify();
    }
  }

  public clearMessages(): void {
    this.messages = [];
    this.notify();
  }
}

export const voiceAssistantService = VoiceAssistantService.getInstance();
