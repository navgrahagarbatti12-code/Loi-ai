export type ModelLoadingStatus = 'unloaded' | 'loading' | 'ready' | 'error' | 'unavailable';

export interface CameraDevice {
  id: string;
  label: string;
  deviceId: string;
  status: 'online' | 'offline' | 'connecting' | 'error';
  errorMessage?: string;
  stream: MediaStream | null;
  resolution: string;
  isSimulated?: boolean;
}

export type BoundingBox = [x: number, y: number, width: number, height: number];

export interface RawDetection {
  class: string;
  score: number;
  bbox: BoundingBox;
}

export interface TrackPoint {
  x: number;
  y: number;
  timestamp: number;
}

export interface TrackedTarget {
  id: number;
  class: string;
  bbox: BoundingBox;
  score: number;
  velocity: {
    vx: number; // pixels per second
    vy: number;
    speed: number;
  };
  history: TrackPoint[];
  state: 'active' | 'lost' | 'removed';
  age: number; // total frames active
  timeSinceUpdate: number; // frames since last match
  firstSeen: number;
  lastSeen: number;
  color: string;
}

export interface SafetyViolation {
  id: string;
  timestamp: number;
  type: 'NO_HELMET' | 'NO_VEST' | 'FALL_DETECTED' | 'ZONE_INTRUSION' | 'HAZARDOUS_PROXIMITY';
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  description: string;
  personTrackId?: number;
  bbox?: BoundingBox;
  snapshotUrl?: string;
  cameraName: string;
}

export interface SafetyMetrics {
  personsDetected: number;
  helmetCompliant: number;
  vestCompliant: number;
  fallsDetected: number;
  complianceRate: number;
  violationsCount: number;
  isModelLoaded: boolean;
  modelStatus: ModelLoadingStatus;
}

export interface SystemSettings {
  resolution: '640x480' | '1280x720' | '1920x1080';
  confidenceThreshold: number;
  iouThreshold: number;
  trackingMaxLostFrames: number;
  batterySaver: boolean;
  targetFps: number;
  language: 'en-US' | 'hi-IN' | 'mr-IN';
  audioAlerts: boolean;
  tripwireYPercent: number; // 0.1 to 0.9
  enableDeepAudit: boolean;
}

export interface ZoneCrossingStats {
  inbound: number;
  outbound: number;
  totalCrossings: number;
}
