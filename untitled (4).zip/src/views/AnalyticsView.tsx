export { ObjectTrackingView as AnalyticsView } from '../components/ObjectTrackingView';
export { ObjectTrackingView as default } from '../components/ObjectTrackingView';
