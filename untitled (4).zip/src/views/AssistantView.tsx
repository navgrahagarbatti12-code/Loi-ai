export { VoiceAssistantView as AssistantView } from '../components/VoiceAssistantView';
export { VoiceAssistantView as default } from '../components/VoiceAssistantView';
