export { CCTVMonitoringView } from '../components/CCTVMonitoringView';
export { CCTVMonitoringView as default } from '../components/CCTVMonitoringView';
