export { HistoryAnalyticsView as HistoryView } from '../components/HistoryAnalyticsView';
export { HistoryAnalyticsView as default } from '../components/HistoryAnalyticsView';
