export { SafetyDetectionView } from '../components/SafetyDetectionView';
export { SafetyDetectionView as default } from '../components/SafetyDetectionView';
